package com.yaozj.menu;

/** author: yaozj date: Created in 2020/9/12 22:40 description: */
public class Test {
  public static void main(String[] args) {
    //    Random r = new Random();
    //    for (int i = 10; i < 20; i++) {
    //      double v1 = r.nextDouble() * i;
    //      double v2 = r.nextDouble() * i;
    //      BigDecimal a1 = new BigDecimal(v1);
    //      BigDecimal a2 = new BigDecimal(v2);
    //      BigDecimal multiply = a1.multiply(a2);
    //      BigDecimal bigDecimal = multiply.setScale(2, BigDecimal.ROUND_HALF_UP);
    //      System.out.println(multiply + "=" + bigDecimal);
    //      System.out.println("===============");
    //    }
    //    BigDecimal a1 = new BigDecimal(0);
    //    for (int i = 1; i < 10; i++) {
    //      a1 = a1.add(new BigDecimal(i));
    //    }
    //    System.out.println(a1);

    javax.swing.filechooser.FileSystemView fsv =
        javax.swing.filechooser.FileSystemView.getFileSystemView();
    //    System.out.println("桌面路径：" + fsv.getHomeDirectory().toString());
    System.out.println("桌面路径：" + fsv.getHomeDirectory().getPath());
  }
}
