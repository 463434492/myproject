package com.yaozj.menu.poi;

import org.apache.poi.hssf.usermodel.HSSFHeader;
import org.apache.poi.ss.usermodel.*;

/** author: yaozj date: Created in 2020/9/14 21:25 description: */
public class ExcelCommon {

  /**
   * 设置页眉页脚
   *
   * @param sheet
   */
  public static void setHeaderAndFooter(Sheet sheet) {
    // 页眉中间
    Header header = sheet.getHeader();
    header.setCenter(HSSFHeader.fontSize((short) 22) + "********批发");
    // 页脚右侧
    sheet.getFooter().setRight("手机：************  手机：************");
    // 页脚左侧
    sheet.getFooter().setLeft("地址：***************");
  }

  /**
   * 页标题的样式
   *
   * @param workbook
   * @return
   */
  public static CellStyle getTitleStyle(Workbook workbook) {
    CellStyle style = workbook.createCellStyle();
    // 对齐方式设置
    style.setAlignment(HorizontalAlignment.CENTER);
    style.setVerticalAlignment(VerticalAlignment.CENTER);
    // 粗体字设置
    Font font = workbook.createFont();
    font.setFontName("宋体");
    font.setColor(Font.COLOR_NORMAL);
    font.setFontHeightInPoints((short) 18);
    style.setFont(font);
    return style;
  }

  public static CellStyle cell(Workbook workbook) {
    CellStyle style = workbook.createCellStyle();
    // 对齐方式设置
    style.setVerticalAlignment(VerticalAlignment.CENTER);
    // 粗体字设置
    Font font = workbook.createFont();
    font.setFontName("宋体");
    font.setColor(Font.COLOR_NORMAL);
    font.setFontHeightInPoints((short) 12);
    style.setFont(font);
    return style;
  }
}
