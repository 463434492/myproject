package com.yaozj.menu.poi;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.yaozj.menu.domain.Orders;
import org.apache.poi.ss.usermodel.Workbook;

import javax.swing.filechooser.FileSystemView;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/** author: yaozj date: Created in 2020/9/13 20:53 description: */
public class MainTest {
  public static void main(String[] args) throws IOException {
    ArrayList<Map> dataList = Lists.newArrayList();
    for (int i = 0; i < 300; i++) {
      HashMap<String, String> data = Maps.newHashMap();
      data.put("name", "name" + (i + 1));
      data.put("value", "value" + (i + 1));
      dataList.add(data);
    }

    Orders orders = new Orders();
    orders.setName("张三");
    orders.setSolarCalendar(new Date());
    orders.setPhoneNo("18888888888");
    orders.setAddr("**省**市**市**镇**村**号");
    orders.setLunarCalendar("庚子年八月初九");

    FileSystemView fsv = FileSystemView.getFileSystemView();
    String filePath_fh = fsv.getHomeDirectory() + "\\发货.xlsx";
    String filePath_js = fsv.getHomeDirectory() + "\\结算.xlsx";

    FileOutputStream fout_fh = new FileOutputStream(new File(filePath_fh));
    FileOutputStream fout_js = new FileOutputStream(new File(filePath_js));

    ExcelWriter2 excelWriter_js = new ExcelWriter2(ExcelBaseInfo.getSettlementExcelInfo());
    Workbook workbook_js = excelWriter_js.exportData(dataList, orders);
    ExcelWriter2 excelWriter_fh = new ExcelWriter2(ExcelBaseInfo.getDeliverExcelInfo());
    Workbook workbook_fh = excelWriter_fh.exportData(dataList, orders);

    workbook_js.write(fout_js);
    workbook_fh.write(fout_fh);

    fout_fh.close();
    fout_js.close();

    //    FileSystemView fsv = FileSystemView.getFileSystemView();
    //    String filePath_fh = fsv.getHomeDirectory() + "\\测试.xlsx";
    //    File file = new File(filePath);
    //    FileOutputStream fout = new FileOutputStream(file);
    //    Workbook workbook = ExcelWriter.exportData(dataList);
    //    workbook.write(fout);
    //    fout.close();
  }
}
