package com.yaozj.menu.poi;

import com.yaozj.menu.domain.Orders;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

/** author: yaozj date: Created in 2020/9/13 19:06 description: */
public class ExcelWriter {
  private static List<String> CELL_HEADS; // 列头
  private static List<String> CELL_HEADS2; // 列头

  // 每页商品的列
  private static int pageColNum = 9;
  // 每页商品的列
  private static int commodityColumnNum = 2;
  // 第一页开始行
  private static int startRowIdx = 8;
  // 每页10行
  private static int pagelenth = 41;

  static {
    // 类装载时就载入指定好的列头信息，如有需要，可以考虑做成动态生成的列头
    CELL_HEADS = new ArrayList<>();
    CELL_HEADS.add("品名");
    CELL_HEADS.add("数量");
    CELL_HEADS.add("");
    CELL_HEADS.add("品名");
    CELL_HEADS.add("数量");
    CELL_HEADS.add("");
    CELL_HEADS.add("品名");
    CELL_HEADS.add("数量");

    CELL_HEADS2 = new ArrayList<>();
    CELL_HEADS2.add("品名");
    CELL_HEADS2.add("数量");
    CELL_HEADS2.add("价格(元)");
    CELL_HEADS2.add("小计(元)");
    CELL_HEADS2.add("");
    CELL_HEADS2.add("品名");
    CELL_HEADS2.add("数量");
    CELL_HEADS2.add("价格(元)");
    CELL_HEADS2.add("小计(元)");
  }

  private static void setCell(
      Workbook workbook, Sheet sheet, int commodityIdx, Map<String, String> data) {
    int columnNo = 0;
    int rowNo = 0;
    // 每列能放的条数
    int columnTotal = pagelenth - startRowIdx + 1;
    // 第一页能放的总条数
    int firstPageTotal = columnTotal * commodityColumnNum;
    // 当前下标 < 第一页最后商品的下标（说明是第一页）
    if ((commodityIdx + 1) <= firstPageTotal) {
      columnNo = commodityIdx / columnTotal;
      rowNo = (commodityIdx % columnTotal) + (startRowIdx - 1);
    } else {
      // （当前商品的下标 - 第一页的商品总数）/ 除了第一页外其他每页的条数
      int pageNo = (commodityIdx - firstPageTotal) / ((pagelenth - 1) * commodityColumnNum);
      // 当前商品的下标 - 页码 * (当前页每列显示的商品数【有一行显示头所以-1】 * 总列数) - 第一页的总商品数量
      int currentNum =
          commodityIdx - pageNo * ((pagelenth - 1) * commodityColumnNum) - firstPageTotal;
      // 当前列号 = 当前页的下标（1开始） / 每页列的条数
      columnNo = currentNum / (pagelenth - 1);
      // 有一行头，所以一列放的商品只能pagelenth - 1
      rowNo = currentNum % (pagelenth - 1) + pagelenth * (pageNo + 1);
      if (rowNo % pagelenth == 0) {
        // 添加头
        setCellHeader(workbook, sheet, rowNo);
      }
      // 因为有一列是头名，所以要+1
      rowNo += 1;
    }
    Row row = sheet.getRow(rowNo);
    if (row == null) {
      row = sheet.createRow(rowNo);
      row.setHeight((short) 400);
    }

    if (pageColNum == 8) {
      int columnIdx = columnNo * 3;
      row.createCell(columnIdx).setCellValue(data.get("name"));
      row.createCell(columnIdx + 1).setCellValue(data.get("value"));
      // 设置样式
      row.getCell(columnIdx).setCellStyle(ExcelCommon.cell(workbook));
      row.getCell(columnIdx + 1).setCellStyle(ExcelCommon.cell(workbook));
    } else {
      int columnIdx = columnNo * 5;
      row.createCell(columnIdx).setCellValue(data.get("name"));
      row.createCell(columnIdx + 1).setCellValue(data.get("value"));
      row.createCell(columnIdx + 2).setCellValue(data.get("name"));
      row.createCell(columnIdx + 3).setCellValue(data.get("value"));
      // 设置样式
      row.getCell(columnIdx).setCellStyle(ExcelCommon.cell(workbook));
      row.getCell(columnIdx + 1).setCellStyle(ExcelCommon.cell(workbook));
      row.getCell(columnIdx + 2).setCellStyle(ExcelCommon.cell(workbook));
      row.getCell(columnIdx + 3).setCellStyle(ExcelCommon.cell(workbook));
    }
  }

  /**
   * 生成Excel并写入数据信息
   *
   * @param dataList 数据列表
   * @return 写入数据后的工作簿对象
   */
  public static Workbook exportData(List<Map> dataList) {
    // 生成xlsx的Excel
    Workbook workbook = new SXSSFWorkbook();
    Sheet sheet = buildDataSheet(workbook);

    Orders orders = new Orders();
    orders.setName("张三");
    orders.setSolarCalendar(new Date());
    orders.setPhoneNo("18888888888");
    orders.setAddr("**省**市**市**镇**村**号");
    orders.setLunarCalendar("庚子年八月初九");

    buildOrderInfo(workbook, sheet, orders, "发货单");
    for (int i = 0; i < dataList.size(); i++) {
      Map map = dataList.get(i);
      setCell(workbook, sheet, i, map);
    }

    return workbook;
  }

  // 设置用户信息
  private static void buildOrderInfo(Workbook workbook, Sheet sheet, Orders orders, String title) {
    int pageLastColIdx = pageColNum - 1;
    // 合并列 前一个的结束列下标
    int lastColIdx1 = 0;
    int firstColIdx2 = 0;
    int halfColNum = 0;
    int secKeyIdx = 0;
    int secValIdx = 0;
    if (pageColNum % 2 == 0) {
      // 8列
      halfColNum = pageColNum / 2;
      lastColIdx1 = halfColNum - 1;
      firstColIdx2 = halfColNum + 1;
    } else {
      // 9列
      halfColNum = pageColNum / 2 + 1;
      lastColIdx1 = halfColNum - 2;
      firstColIdx2 = halfColNum + 1;
    }
    secKeyIdx = halfColNum;
    secValIdx = secKeyIdx + 1;

    // 页头
    int pageTitleRowNo = 0;
    Row pageTitleRow = sheet.createRow(pageTitleRowNo);
    pageTitleRow.setHeight((short) 400);
    int pageTitleRowNo2 = pageTitleRowNo + 1;
    Row pageTitleRow2 = sheet.createRow(pageTitleRowNo2);
    pageTitleRow2.setHeight((short) 400);
    CellRangeAddress pageTitle =
        new CellRangeAddress(pageTitleRowNo, pageTitleRowNo + 1, 0, pageLastColIdx);
    sheet.addMergedRegion(pageTitle);
    pageTitleRow.createCell(0).setCellValue(title);
    pageTitleRow.getCell(0).setCellStyle(ExcelCommon.getTitleStyle(workbook));

    // 姓名电话
    int nameAndPhoneRowNo = pageTitleRowNo2 + 1;
    Row nameAndPhone = sheet.createRow(nameAndPhoneRowNo);
    nameAndPhone.setHeight((short) 400);
    for (int i = 0; i < pageColNum; i++) {
      Cell cell = nameAndPhone.createCell(i);
      cell.setCellStyle(ExcelCommon.cell(workbook));
    }
    CellRangeAddress nameCell =
        new CellRangeAddress(nameAndPhoneRowNo, nameAndPhoneRowNo, 1, lastColIdx1);
    CellRangeAddress phoneCell =
        new CellRangeAddress(nameAndPhoneRowNo, nameAndPhoneRowNo, firstColIdx2, pageColNum - 1);
    sheet.addMergedRegion(nameCell);
    sheet.addMergedRegion(phoneCell);
    nameAndPhone.getCell(0).setCellValue("姓名：");
    nameAndPhone.getCell(1).setCellValue(orders.getName());
    nameAndPhone.getCell(secKeyIdx).setCellValue("电话：");
    nameAndPhone.getCell(secValIdx).setCellValue(orders.getPhoneNo());

    // 日历行
    int calendarRowNo = nameAndPhoneRowNo + 1;
    Row calendar = sheet.createRow(calendarRowNo);
    calendar.setHeight((short) 400);
    for (int i = 0; i < pageColNum; i++) {
      calendar.createCell(i);
    }
    CellRangeAddress solar = new CellRangeAddress(calendarRowNo, calendarRowNo, 1, lastColIdx1);
    CellRangeAddress lunar =
        new CellRangeAddress(calendarRowNo, calendarRowNo, firstColIdx2, pageColNum - 1);
    sheet.addMergedRegion(solar);
    sheet.addMergedRegion(lunar);
    calendar.getCell(0).setCellValue("阳历：");
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
    String solarStr = simpleDateFormat.format(orders.getSolarCalendar());
    calendar.getCell(1).setCellValue(solarStr);
    calendar.getCell(secKeyIdx).setCellValue("阴历：");
    calendar.getCell(secValIdx).setCellValue(orders.getLunarCalendar());

    // 地址行
    int addrRowNo = calendarRowNo + 1;
    Row addrRow = sheet.createRow(addrRowNo);
    addrRow.setHeight((short) 400);
    for (int i = 0; i < pageColNum; i++) {
      addrRow.createCell(i);
    }
    CellRangeAddress addr = new CellRangeAddress(addrRowNo, addrRowNo, 1, pageLastColIdx);
    sheet.addMergedRegion(addr);
    addrRow.getCell(0).setCellValue("地址：");
    addrRow.getCell(1).setCellValue(orders.getAddr());

    int nullRowNo = addrRowNo + 1;
    Row nullRow = sheet.createRow(nullRowNo);
    nullRow.setHeight((short) 400);
    // 设置头
    setCellHeader(workbook, sheet, nullRowNo + 1);
  }

  /**
   * 生成sheet表，并写入第一行数据（列头）
   *
   * @param workbook 工作簿对象
   * @return 已经写入列头的Sheet
   */
  private static Sheet buildDataSheet(Workbook workbook) {
    Sheet sheet = workbook.createSheet(); // 创建sheet
    // 设置页眉页脚
    ExcelCommon.setHeaderAndFooter(sheet);
    return sheet;
  }

  private static void setCellHeader(Workbook workbook, Sheet sheet, int rowNum) {
    Row addrRow = sheet.createRow(rowNum);
    addrRow.setHeight((short) 400);
    if (pageColNum == 8) {
      for (int i = 0; i < CELL_HEADS.size(); i++) {
        Cell cell = addrRow.createCell(i);
        cell.setCellValue(CELL_HEADS.get(i));
        cell.setCellStyle(ExcelCommon.cell(workbook));
        sheet.setColumnWidth(i, 2700);
      }
    } else {
      for (int i = 0; i < CELL_HEADS2.size(); i++) {
        Cell cell = addrRow.createCell(i);
        cell.setCellValue(CELL_HEADS2.get(i));
        cell.setCellStyle(ExcelCommon.cell(workbook));
        if (i == 4) {
          sheet.setColumnWidth(i, 800);
        } else {
          sheet.setColumnWidth(i, 2600);
        }
      }
    }
  }
}
