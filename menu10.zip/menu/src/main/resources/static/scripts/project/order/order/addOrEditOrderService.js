define(['/scripts/public/util.js'], function (util) {
    var api = {
        getPageInfo: '/order/pageInfo',
        getOrderByOrderNo: '/order/getOrderByOrderNo',
        saveOrEditOrder: '/order/saveOrEditOrder',
        saveOrderDetail: '/order/saveOrderDetail',
        exportOrderDetail: '/order/exportOrderDetail',
        getUnits: '/unit/getUnits',
        getPinyin: '/commodity/getPinyin',
        saveCommodity: '/commodity/saveCommodity',
        delCommodity: '/commodity/delCommodity',
        editCommodity: '/commodity/editCommodity',
    };
    var doAjax = function (url, opt, errorMsg) {
        util.doAjax(url, opt.data, opt.ajaxOpt, null)
            .done(function (resp) {
                if (!resp) {
                    $.error('加载数据失败');
                    return false;
                }
                if (!resp.success) {
                    $.error(resp.messages || errorMsg || '加载数据失败');
                    return false;
                }
                if (opt.callback && typeof opt.callback === 'function') {
                    opt.callback(resp);
                }
            })
            .fail(function () {
                $.warn(errorMsg || '操作失败');
            });
    };
    var postJson = function (url, data, success, fail) {
        util.postJson(url, data, success, fail);
    };
    return {
        api: api,
        postJson: postJson,
        getPageInfo: function (opt) {
            doAjax(api.getPageInfo, opt);
        },
        getOrderByOrderNo: function (opt) {
            doAjax(api.getOrderByOrderNo, opt);
        },
        saveOrEditOrder: function (opt) {
            doAjax(api.saveOrEditOrder, opt);
        },
        saveOrderDetail: function (opt) {
            doAjax(api.saveOrderDetail, opt);
        },
        exportOrderDetail: function (opt) {
            doAjax(api.exportOrderDetail, opt);
        },
        getUnits: function (opt) {
            doAjax(api.getUnits, opt);
        },
        getPinyin: function (opt) {
            doAjax(api.getPinyin, opt);
        },
        saveCommodity: function (opt) {
            doAjax(api.saveCommodity, opt);
        },
        delCommodity: function (opt) {
            doAjax(api.delCommodity, opt);
        },
        editCommodity: function (opt) {
            doAjax(api.editCommodity, opt);
        },
        init: function () {
            var self = this;
            // 是否已经进入下一个input，table中的input防止change事件和keyup事件冲突
            // 0：没进进入下一个input，1：进入下一个input
            self.gotoInputFlag = 0;
            // 当前table每行有几个input框
            self.rowInputNum = 2;
            self.goNextInputInfo = {};
            self.curTableInfo = {};
            self.curZtreeInfo = {};
            self.unitMap = {};
            self.unitNameMap = {};
        },
        /**
         * 初始化单位名称
         */
        initUnit: function () {
            var self = this;
            self.getUnits({
                ajaxOpt: {async: false},
                callback: function (resp) {
                    var unitarr = resp.result;
                    var result = ""
                    $.each(unitarr, function (idx, val) {
                        result += '<option value="' + val.id + '">' + val.name + '</option>';
                        self.unitNameMap[val.id] = val.name;
                    });
                    $.each(unitarr, function (idx, val) {
                        self.unitMap[val.id] = result.replace('value="' + val.id + '"', 'value="' + val.id + '" selected="selected"');

                    });
                }
            });
        },
        getOrderTableColumns: function () {
            var self = this;
            return [
                {
                    mData: 'id',
                    sTitle: '订单商品Id',
                    defaultContent: '',
                    bSortable: false,
                    visible: false,
                    mRender: function (data) {
                        return data || '';
                    }
                },
                {
                    mData: 'commodityId',
                    sTitle: '商品ID',
                    defaultContent: '',
                    bSortable: false,
                    visible: false,
                    mRender: function (data) {
                        return data || '';
                    }
                },
                {
                    mData: 'initial',
                    sTitle: '首字母',
                    defaultContent: '',
                    bSortable: false,
                    visible: false,
                    mRender: function (data) {
                        return data || '';
                    }
                },
                {
                    mData: 'no',
                    sTitle: '编号',
                    sWidth: '5%',
                    defaultContent: '',
                    bSortable: true,
                    mRender: function (data, type, row, meta) {
                        return Number(row.no);
                    }
                },
                {
                    mData: 'commodityName',
                    sTitle: '商品名称',
                    sWidth: '20%',
                    defaultContent: '',
                    bSortable: true,
                    mRender: function (data) {
                        return data || '';
                    }
                },
                {
                    mData: 'weight',
                    sTitle: '数量',
                    sWidth: '15%',
                    defaultContent: '',
                    bSortable: false,
                    mRender: function (data, type, row, meta) {
                        var rowNum = Number(row.no);
                        return '<div class="control-group"><div class="controls">' +
                            '<input type="text" input-idx="1" maxlength="7" column-name="weight" name="' + rowNum + '_' + row.commodityId + '_weight" class="controls-text right" validate="{meteringNum:true}" value="' + (data || "0") + '">' +
                            '</div></div>';
                    }
                },
                {
                    mData: 'price',
                    sTitle: '价格',
                    sWidth: '15%',
                    defaultContent: '',
                    bSortable: false,
                    mRender: function (data, type, row, meta) {
                        var rowNum = Number(row.no);
                        return '<div class="control-group"><div class="controls">' +
                            '<input type="text" maxlength="7" input-idx="0" column-name="price" name="' + rowNum + '_' + row.commodityId + '_price" class="controls-text right" validate="{meteringNum:true}" value="' + (data || "0") + '">' +
                            '</div></div>';
                    }
                },
                {
                    mData: 'unitId',
                    sTitle: '单位',
                    sWidth: '15%',
                    defaultContent: '',
                    bSortable: false,
                    mRender: function (data, type, row, meta) {
                        var rowNum = Number(row.no);
                        data = Number(data);
                        var unitStr = self.unitMap[data];
                        unitStr = !$.trim(unitStr) && $.trim(self.unitMap[0]) ? self.unitMap[0] : unitStr;
                        return '<select class="controls-text" column-name="unitId" name="' + rowNum + '_' + row.commodityId + '_unit">' +
                            unitStr +
                            '</select>';
                    }
                },
                {
                    mData: 'operate',
                    sTitle: '操作',
                    sWidth: '10%',
                    defaultContent: '',
                    bSortable: false,
                    mRender: function (data, type, row, meta) {
                        return '<a class="btn-fa" action-name="删除已选商品" data-toggle="tooltips" data-placement="top" data-title="删除" href="javascript:void(0);" class="delChooseCommodity" id="' + row.commodityId + '"><i class="fa fa-trash-o"></i></a>';
                    }
                }
            ];
        },
    };
});
