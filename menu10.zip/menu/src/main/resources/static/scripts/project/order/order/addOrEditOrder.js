define(['/scripts/project/order/order/addOrEditOrderService.js', '/scripts/public/util.js'], function (service, util) {
    return {
        init: function () {
            var self = this;
            service.init();
            service.initUnit();
            self.bindEvent();
            self.initPage();
        },
        /**
         * 绑定事件
         */
        bindEvent: function () {
            var self = this;
            // 搜索树绑定事件
            $("[action-name='筛选zTree']")
                .on('input', function (e) {
                    if ($(this).prop('comStart')) {
                        // 中文输入过程中不截断
                        return;
                    }
                    self.searchTree(service.curZtreeInfo.treeId, $(e.currentTarget).val());
                })
                .on('compositionstart', function () {
                    $(this).prop('comStart', true);
                })
                .on('compositionend', function (e) {
                    $(this).prop('comStart', false);
                    self.searchTree(service.curZtreeInfo.treeId, $(e.currentTarget).val());
                });
            // dataTable相关的事件
            $("[data-module='addOrEditOrder']")
                .on('focus', '.chooseCommodityForm input', function (e) {
                    $(e.currentTarget).select();
                    return false;
                })
                .on('keyup', '.chooseCommodityForm input', function (e) {
                    console.log("keyup:" + e.keyCode);
                    self.tableInputKeyup(e);
                    return false;
                })
                .on('change', '.chooseCommodityForm input', function (e) {
                    console.log('change');
                    self.tableInputChange(e);
                    return false;
                })
                .on('input', '.chooseCommodityForm input', function (e) {
                    if ($(this).prop('comStart')) {
                        // 中文输入过程中不截断
                        return;
                    }
                    self.checkInputVal(e);
                    return false;
                })
                .on('compositionstart', '.chooseCommodityForm input', function () {
                    $(this).prop('comStart', true);
                    return false;
                })
                .on('compositionend', '.chooseCommodityForm input', function (e) {
                    $(this).prop('comStart', false);
                    self.checkInputVal(e);
                    return false;
                })
                .on('change', '.chooseCommodityForm table select', function (e) {
                    //更新dataTable中的数据
                    self.updateTableRowData(e);
                    // 校验表单
                    $.formValidate(service.curTableInfo.tableObj.parents('form'));
                    return false;
                })
                .on('keyup change', "[action-name='筛选Table']", function (e) {
                    self.searchTable(service.curTableInfo.tableObj, $(e.currentTarget).val());
                    return false;
                })
                .on('click', "[action-name='删除已选商品']", function (e) {
                    var $row = service.curTableInfo.tableObj.DataTable().row($(e.currentTarget).parents('tr'));
                    var rowData = $row.data();
                    $row.remove().draw(false);
                    // 级联ztree反选
                    var treeObj = $.fn.zTree.getZTreeObj(service.curZtreeInfo.treeId);
                    var node = treeObj.getNodeByParam('id', rowData.commodityId, null);
                    treeObj.checkNode(node, false, false, false);
                    false;
                });
            $("[data-module='addOrEditOrder']")
                .on('click', '.orderTab li', function (e) {
                    //tab切换订单还是补单
                    self.switchTab(e);
                    return false;
                })
                .on('click', '#saveOrder', function (e) {
                    // 1.校验
                    if (!self.checkOrderInfo()) {
                        return;
                    }
                    self.saveOrderInfo();
                    self.saveOrderDetail();
                    return false;
                })
                .on('click', '#deliverGoods', function (e) {
                    // 1.校验
                    if (!self.checkOrderInfo()) {
                        return;
                    }
                    self.saveOrderInfo();
                    self.saveOrderDetail(0);
                    return false;
                })
                .on('click', '#settlement', function (e) {
                    // 1.校验
                    if (!self.checkOrderInfo()) {
                        return;
                    }
                    self.saveOrderInfo();
                    self.saveOrderDetail(1);
                    return false;
                })
                .on('click', '#ztreeNavbar li', function (e) {
                    var html = $(e.currentTarget).find('a').html();
                    var treeObj = $.fn.zTree.getZTreeObj(service.curZtreeInfo.treeId);
                    var node = treeObj.getNodeByParam('id', $.trim(html), null);
                    if (node.pId === '0' && node.open) {
                        treeObj.selectNode(node);
                        return false;
                    }
                    treeObj.expandAll(false);
                    treeObj.selectNode(node);
                    treeObj.expandNode(node, true, false, true);
                    return false;
                })
                .on('click', '.J_dataBlock .animation-reverse', function (e) {
                    var $this = $(this).parents('.J_dataBlock');
                    //当前按钮
                    var $theBtn = $(this);
                    // 展开/收起动作
                    $this.find('.J_dataContent').slideToggle();
                    //判断按钮当前状态并添加class样式
                    if ($theBtn.hasClass('reverse')) {
                        $theBtn.removeClass('reverse');
                        self.tableDomAnimate(-100);
                    } else {
                        $theBtn.addClass('reverse');
                        self.tableDomAnimate(100);
                    }
                    return;
                })
                .on('click', '[action-name="新增商品"]', function (e) {
                    self.hideRMenu();
                    self.addCommodity();
                    return false;
                })
                .on('click', '[action-name="删除商品"]', function (e) {
                    self.hideRMenu();
                    self.delCommodity();
                    return false;
                })
                .on('click', '[action-name="编辑商品"]', function (e) {
                    self.hideRMenu();
                    self.editCommodity();
                    return false;
                });
            $('body')
                .on('input', '#commodityName', function (e) {
                    if ($(this).prop('comStart')) {
                        // 中文输入过程中不截断
                        return;
                    }
                    self.getPinyin(e);
                })
                .on('compositionstart', '#commodityName', function () {
                    $(this).prop('comStart', true);
                })
                .on('compositionend', '#commodityName', function (e) {
                    $(this).prop('comStart', false);
                    self.getPinyin(e);
                });
        },

        /**
         * 校验input框输入的内容，只能输入>0的两位小数
         * @param e
         */
        checkInputVal: function (e) {
            e.target.value = e.target.value.replace(/[^\d.]/g, ""); //清除"数字"和"."以外的字符
            e.target.value = e.target.value.replace(/^\./g, ""); //验证第一个字符是数字而不是.
            e.target.value = e.target.value.replace(/\.{2,}/g, "."); //只保留第一个. 清除多余的.
            e.target.value = e.target.value.replace(".", "$#$").replace(/\./g, "").replace("$#$", ".");//只允许输入一个小数点
            e.target.value = e.target.value.replace(/^(\-)*(\d+)\.(\d\d).*$/, '$1$2.$3'); //只能输入两个小数
        },

        /**
         * 保存订单详情
         */
        saveOrderDetail: function (exportType) {
            var self = this;
            var orderData = $("#orderTable").DataTable().rows().data();
            var supplementData = $("#supplementTable").DataTable().rows().data();
            var orderSubmitData = [];
            var supplementSubmitData = [];
            $.each(orderData, function (idx, val) {
                orderSubmitData.push(val);
            });
            $.each(supplementData, function (idx, val) {
                supplementSubmitData.push(val);
            });
            var data = {
                orderNo: $.trim($('#orderOrderNo').val()),
                orderData: orderSubmitData,
                supplementData: supplementSubmitData
            };
            service.postJson(service.api.saveOrderDetail, data, function (res) {
                $("#orderTotal").val(res.result);
                if (!$.trim(exportType)) {
                    $.msg("保存成功!");
                } else {
                    self.exportExcel(exportType);
                }
            }, function (res) {
                $.msg("保存失败...");
            });
        },

        /**
         * 导出excel
         * @param exportType 0:发货单,1:结算单
         */
        exportExcel: function (exportType) {
            var self = this;
            service.exportOrderDetail({
                data: {exportType: exportType, orderNo: $.trim($('#orderOrderNo').val())},
                callback: function (resp) {
                    if (resp.result) {
                        if (exportType === 0) {
                            $.msg("生成发货单成功！");
                        } else {
                            $.msg("生成结算单成功！");
                        }
                    }
                },
            });
        },

        /**
         * 校验订单信息
         * treu:校验成功
         * false：校验失败
         * @returns {boolean}
         */
        checkOrderInfo: function () {
            var solarVal = $('#solar').val();
            var solarFlag = false;
            if (!$.trim(solarVal)) {
                solarFlag = true;
                if (!$('#solar').hasClass('error')) {
                    $('#solar').addClass('error');
                }
            }
            var validate = $.formValidate($('#orderInfoForm'));
            if (!validate || solarFlag) {
                $.msg("请检查客户信息，是否填写正确！");
                return false;
            }
            return true;
        },

        /**
         * 保存订单信息
         */
        saveOrderInfo: function () {
            var data = {
                id: $('#orderId').val(),
                orderNo: $('#orderOrderNo').val(),
                name: $('#orderName').val(),
                addr: $('#orderAddr').val(),
                phoneNo: $('#orderPhoneNo').val(),
                lunarCalendar: $('#lunar').val(),
                solarCalendarLong: new Date($('#solar').val()).getTime(),
            };
            service.saveOrEditOrder({
                data: data,
                ajaxOpt: {async: false},
                callback: function (resp) {
                    var orderNo = resp.result;
                    $('#orderOrderNo').val(orderNo);
                }
            });
        },

        /**
         * 添加商品
         */
        addCommodity: function () {
            var self = this;
            self.addOrEditCommodity({
                title: '新增商品',
                doAction: function (confirmData) {
                    service.saveCommodity({
                        data: confirmData,
                        callback: function (resp) {
                            if (resp.result) {
                                self.addNodeAction('orderZtree', resp.result);
                                self.addNodeAction('supplementZtree', resp.result);
                                // 将当前ztree新增的节点移动到可视区
                                var curTree = $.fn.zTree.getZTreeObj(service.curZtreeInfo.treeId);
                                var newNode = curTree.getNodeByParam('id', resp.result.id, null);
                                curTree.selectNode(newNode);
                            }
                        },
                    });
                },
            });
        },

        /**
         * ztree添加节点
         * @param treeId
         * @param node
         */
        addNodeAction: function (treeId, node) {
            var self = this;
            var treeObj = $.fn.zTree.getZTreeObj(treeId);
            treeObj.expandAll(false);
            var parentNode = treeObj.getNodeByParam('id', node.pId, null);
            if (!parentNode) {
                var parentNodeData = {
                    // initial: node.initial.substring(0, 1),
                    name: node.pId,
                    id: node.pId,
                    pId: '0',
                    chkDisabled: true,
                };
                treeObj.addNodes(null, parentNodeData);
                parentNode = treeObj.getNodeByParam('id', node.pId, null);
            }
            treeObj.addNodes(parentNode, node);
        },

        /**
         * 删除商品
         */
        delCommodity: function () {
            var self = this;
            var treeObj = $.fn.zTree.getZTreeObj(service.curZtreeInfo.treeId);
            var nodes = treeObj.getSelectedNodes();
            if (!nodes || !nodes[0]) {
                $.msg('没有发现要删除的商品！');
                return;
            }
            var delNodeData = nodes[0].data;
            delNodeData['pId'] = nodes[0].pId;
            $.confirm('确定要删除：' + delNodeData.name + '?', {
                yesCallBack: function () {
                    service.delCommodity({
                        data: {commodityId: delNodeData.id},
                        callback: function (resp) {
                            // 确认表中没有需要删除的商品
                            if (self.commodityIsSelected($('#orderTable'), delNodeData) || self.commodityIsSelected($('#supplementTable'), delNodeData)) {
                                return;
                            }
                            self.delNodeAction('orderZtree', delNodeData);
                            self.delNodeAction('supplementZtree', delNodeData);
                        },
                    });
                },
            });
        },

        /**
         * 删除ztree节点
         * @param treeId
         * @param delNodeData
         */
        delNodeAction: function (treeId, delNodeData) {
            var treeObj = $.fn.zTree.getZTreeObj(treeId);
            var delNode = treeObj.getNodeByParam('id', delNodeData.id, null);
            treeObj.removeNode(delNode);
            var parentNode = treeObj.getNodeByParam('id', delNodeData.pId, null);
            if (parentNode.children.length === 0) {
                treeObj.removeNode(parentNode);
            }
        },

        /**
         * 编辑商品
         */
        editCommodity: function () {
            var self = this;
            var treeObj = $.fn.zTree.getZTreeObj(service.curZtreeInfo.treeId);
            var nodes = treeObj.getSelectedNodes();
            if (!nodes || !nodes[0]) {
                $.msg('没有发现要删除的商品！');
                return;
            }

            var editNodeData = nodes[0].data;
            editNodeData['unitStr'] = service.unitMap[editNodeData.unitId];

            // 确认表中没有需要编辑的商品
            if (self.commodityIsSelected($('#orderTable'), editNodeData) || self.commodityIsSelected($('#supplementTable'), editNodeData)) {
                return;
            }
            self.addOrEditCommodity({
                data: editNodeData,
                title: '修改商品',
                doAction: function (confirmData) {
                    console.log(confirmData);
                    service.editCommodity({
                        data: confirmData,
                        callback: function (resp) {
                            if (resp.result) {
                                self.editNodeAction('orderZtree', resp.result);
                                self.editNodeAction('supplementZtree', resp.result);
                            }
                        },
                    });
                },
            });
        },

        /**
         * ztree编辑节点
         * @param treeId
         * @param node
         */
        editNodeAction: function (treeId, newNode) {
            var self = this;
            var treeObj = $.fn.zTree.getZTreeObj(treeId);
            var oldNode = treeObj.getNodeByParam('id', newNode.data.id, null);
            var pId = newNode.initial.substring(0, 1);
            // 还在原来的父节点下
            if (oldNode.pId === pId) {
                oldNode.data = newNode.data;
                oldNode.initial = newNode.initial;
                treeObj.editName(oldNode);
                treeObj.cancelEditName(newNode.name);
            } else {
                var parentNode = treeObj.getNodeByParam('id', pId, null);
                // 父节点不存在
                if (!parentNode) {
                    var parentNodeData = {
                        name: pId,
                        id: pId,
                        pId: '0',
                        chkDisabled: true,
                    };
                    treeObj.addNodes(null, parentNodeData);
                    parentNode = treeObj.getNodeByParam('id', pId, null);
                }
                treeObj.expandAll(false);
                treeObj.addNodes(parentNode, newNode);
                treeObj.removeNode(oldNode);
            }
        },

        /**
         * 判断商品在不在table中
         * @param tableObj
         * @param nodeData
         * @returns {boolean}
         */
        commodityIsSelected: function (tableObj, nodeData) {
            var tabDatas = tableObj.DataTable().rows().data();
            var flag = false;
            $.each(tabDatas, function (idx, val) {
                if (val.commodityId === nodeData.id) {
                    flag = true;
                    var attr = tableObj.attr('name');
                    $.warn('请先删除《' + attr + '》表中的' + val.commodityName + '，编号：' + val.no);
                    return false;
                }
            });
            return flag;
        },
        /**
         * 获取拼音
         * @param e
         */
        getPinyin: function (e) {
            service.getPinyin({
                ajaxOpt: {showSubmittingTip: false},
                data: {commodityName: $(e.currentTarget).val()},
                callback: function (resp) {
                    $('#commodityPinyin').val(resp.result.pinyin);
                    $('#commodityInitial').val(resp.result.shortPinyin);
                    $.formValidate($('#addOrEditCommodityForm'));
                },
            });
        },
        /**
         * 添加商品
         * @returns {boolean}
         */
        addOrEditCommodity: function (opt) {
            var self = this;
            var templateHtmlTpl = util.getTemPlates('tpl/addOrEditCommodityTpl.html');
            var confirmTpl = util.getTemPlates('tpl/addOrEditCommodityConfirmTpl.html');
            if (!templateHtmlTpl || !confirmTpl) {
                $.msg('未获取到表单模板！', {
                    interval: 1500,
                });
                return false;
            }
            if (!opt.data) {
                opt.data = {name: '', initial: '', unitStr: service.unitMap[1]};
            }
            $.dialog(templateHtmlTpl.render(opt.data), {
                title: opt.title,
                width: 550,
                buttons: {
                    确定: function () {
                        var validate = $.formValidate($('#addOrEditCommodityForm'));
                        if (!validate) {
                            return;
                        }
                        var initial = $('#commodityInitial').val().trim();
                        var unitId = Number($('#commodityUnitId').val().trim());
                        var confirmData = {
                            name: $('#commodityName').val().trim(),
                            initial: initial,
                            unitName: service.unitNameMap[unitId],
                            unitId: unitId,
                            parentName: initial.substring(0, 1).toUpperCase(),
                        };
                        if ($.trim(opt.data.id)) {
                            confirmData['id'] = opt.data.id;
                            confirmData['status'] = opt.data.status;
                        }
                        $.confirm(confirmTpl.render(confirmData), {
                            yesCallBack: function () {
                                opt.doAction(confirmData);
                                $('#addOrEditCommodityForm').dialog('destroy');
                            },
                        });
                    },
                    取消: function () {
                        $('#addOrEditCommodityForm').dialog('destroy');
                    },
                },
                open: function (event, ui) {
                    $.formValidate($('#addOrEditCommodityForm'));
                },
            });
        },

        /**
         * table中的input的Keyup事件
         * 上下左右移动光标的
         */
        tableInputKeyup: function (e) {
            var self = this;
            var keyCode = e.keyCode;
            if (service.gotoInputFlag === 1 || (keyCode !== 999 && keyCode !== 13 && keyCode !== 37 && keyCode !== 38 && keyCode !== 39 && keyCode !== 40)) {
                // 将进入下一个input的标记清除
                service.gotoInputFlag = 0;
                return false;
            }
            // 回车（13），右键（39）进入后一个input
            var goStep = 1;
            if (keyCode === 38) {
                // 上键（38）向前走n个input
                goStep = -1 * service.rowInputNum;
            } else if (keyCode === 37) {
                // 左键（37）向前走1个input
                goStep = -1;
            } else if (keyCode === 40) {
                // 下键（40）向前走1个input
                goStep = service.rowInputNum;
            }
            // 记录下当前的input下标和gostep
            var curInputIdx_part = self.getCurInputIdx($(e.currentTarget)).curInputIdx_part;
            service.goNextInputInfo = {curInputIdx_part: curInputIdx_part, goStep: goStep};
            self.gotoNextInput($(e.currentTarget), e.keyCode, null, null, goStep);
        },

        /**
         * table中的input的Change事件
         * 发生改变修改datatable该行的数据
         */
        tableInputChange: function (e) {
            var self = this;
            var info = self.getCurInputIdx($(e.currentTarget));
            var curInputIdx_part = info.curInputIdx_part;

            var goStep = 1;
            var keyCode = 999;
            if (curInputIdx_part === service.goNextInputInfo.curInputIdx_part) {
                goStep = service.goNextInputInfo.goStep;
                keyCode = 1000;
            }
            service.goNextInputInfo = {};

            // 如果输入框中输入的是空，那么设置成0
            var val = $(e.currentTarget).val();
            if (!$.trim(val)) {
                $(e.currentTarget).val(0);
            }
            // 输入01,02,0003 这种是数字的，自动转换成 1,2,3
            if (!isNaN(val)) {
                $(e.currentTarget).val(Number(val));
            }
            //更新dataTable中的数据
            self.updateTableRowData(e);
            self.gotoNextInput(null, keyCode, info.curRowIdx, info.curInputIdx, goStep);
        },

        /**
         * 获取当前input下标相关的内容
         * @param $current
         * @returns {{curInputIdx: *, curRowIdx: *, curInputIdx_part: *}}
         */
        getCurInputIdx: function ($current) {
            var self = this;
            // 获取当前行号
            var curRowIdx = service.curTableInfo.tableObj.DataTable().row($current.parents('tr')).index();
            // 获取当前input在行中的下标
            var curInputIdx = Number($current.attr('input-idx'));
            // 当前页开始的下标
            var displayStartIdx = service.curTableInfo.tableObj.DataTable().page.info().start;
            // 当前页的input相对于总input的偏移量
            var inputOffect = displayStartIdx * service.rowInputNum;
            var curInputIdx_part = curRowIdx * service.rowInputNum - inputOffect + curInputIdx;
            return {curInputIdx_part: curInputIdx_part, curRowIdx: curRowIdx, curInputIdx: curInputIdx};
        },

        /**
         * 进入下一个input
         * @param $current 当前input的jq对象
         * @param keyCode
         * @param rowIdx 当前行的下标
         * @param inputIdx  input的下标
         */
        gotoNextInput: function ($current, keyCode, rowIdx, inputIdx, goStep) {
            var self = this;
            // 如果keyCode是999（change触发），那么下一次的keyup事件不走跳转
            // 如果keyCode是1000（change触发），那么是keyup传递过来的，需要走跳转动作
            if (keyCode === 999) {
                service.gotoInputFlag = 1;
            }
            //获取上下页和Input下标的相关信息
            var pageInfo = self.getPageAndInputInfo();
            var $DataTable = service.curTableInfo.tableObj.DataTable();
            // 当前页开始的下标
            var displayStartIdx = $DataTable.page.info().start;
            // 当前页的input相对于总input的偏移量
            var inputOffect = displayStartIdx * service.rowInputNum;
            // 当前input所在的行下标
            var curRowIdx = !$.trim(rowIdx) ? $DataTable.row($current.parents('tr')).index() : rowIdx;
            // 当前input在行中的下标
            var curInputIdx = !$.trim(inputIdx) ? $DataTable.row($current.attr('input-idx')).index() : inputIdx;
            // 下个input在全局的下标
            var nextInputIdx_global = curRowIdx * service.rowInputNum + curInputIdx + goStep;
            // 下个input在当前页的下标
            var nextInputIdx_part = nextInputIdx_global - inputOffect;
            // 当前页最后一个input的下标
            var curPageLastInputIdx_part = pageInfo.curPageLastInputIdx - inputOffect;

            if (nextInputIdx_part >= 0 && nextInputIdx_part <= curPageLastInputIdx_part) {
                // 当前页
                $(service.curTableInfo.tableObj.find('input')[nextInputIdx_part]).focus();
                return;
            } else if (nextInputIdx_global > 0 && nextInputIdx_part < 0) {
                // 上一页
                var pageNo = pageInfo.previous;
                $DataTable.page(pageNo).draw('page');
                displayStartIdx = $DataTable.page.info().start;
                nextInputIdx_part = nextInputIdx_global - displayStartIdx * service.rowInputNum;
                $(service.curTableInfo.tableObj.find('input')[nextInputIdx_part]).focus();
                return;
            } else if (nextInputIdx_part > curPageLastInputIdx_part && nextInputIdx_part < pageInfo.totalInputIdx) {
                // 下一页
                var pageNo = pageInfo.next;
                $DataTable.page(pageNo).draw('page');
                displayStartIdx = $DataTable.page.info().start;
                nextInputIdx_part = nextInputIdx_global - displayStartIdx * service.rowInputNum;
                $(service.curTableInfo.tableObj.find('input')[nextInputIdx_part]).focus();
                return;
            }
            return;
        },

        /**
         * 获取上下页和Input下标的相关信息
         * @returns {{curPageLastInputIdx: *, next: *, previous: *, totalInputIdx: *}}
         */
        getPageAndInputInfo: function () {
            var self = this;
            var $DataTable = service.curTableInfo.tableObj.DataTable();
            // 总行数
            var recordsTotal = $DataTable.page.info().recordsTotal;
            // 每页显示条数
            var displayLength = $DataTable.page.info().length;
            // 总页数
            var totalPage = $DataTable.page.info().pages - 1;
            // 当前页
            var curPage = $DataTable.page.info().page;
            // 下一页
            var next = curPage + 1 <= totalPage ? curPage + 1 : curPage;
            // 上一页
            var previous = curPage - 1 >= 0 ? curPage - 1 : curPage;

            // table中最后一个input的下标
            var totalInputIdx = (recordsTotal + 1) * service.rowInputNum - 1;
            // 当前页的最后一个input的下标
            var curPageLastInputIdx;
            if (curPage < totalPage) {
                //中间页，-1是因为下标从0开始
                curPageLastInputIdx = displayLength * (curPage + 1) * service.rowInputNum - 1;
            } else {
                // 最后一页，当前页的最后一个input的下标 与 table中最后一个input的下标 一致
                curPageLastInputIdx = totalInputIdx;
            }
            return {
                curPageLastInputIdx: curPageLastInputIdx,
                totalInputIdx: totalInputIdx,
                next: next,
                previous: previous,
            };
        },

        /**
         * 更新dataTable中的数据
         * @param e
         */
        updateTableRowData: function (e) {
            var self = this;
            var $current = $(e.currentTarget);
            var $row = service.curTableInfo.tableObj.DataTable().row($current.parents('tr'));
            var data = $row.data();
            data[$current.attr('column-name')] = $current.val();
            data['isChange'] = 'true';
            $row.data(data);
        },

        /**
         * table dom的动画
         * @param offset
         */
        tableDomAnimate: function (offset) {
            var self = this;
            var $module = $('.module.J_dataBlock.data-dictionary-list');
            var height = $module.height();
            $module.animate({height: height + offset + 'px'}, null, null, function () {
                self.reDrawTable(service.curTableInfo.tableObj, service.curTableInfo.height);
            });
        },

        /**
         * zTree搜索
         * @param $selector
         * @param searchStr
         */
        searchTree: function (treeId, searchStr) {
            var self = this;
            var treeObj = $.fn.zTree.getZTreeObj(treeId);
            if (treeObj === null) {
                return;
            }
            $.searchTree(treeId, searchStr, true);
        },

        /**
         * dataTable搜索
         * @param $selector
         * @param searchStr
         */
        searchTable: function ($selector, searchStr) {
            $selector.DataTable().search(searchStr, false, true).draw();
        },

        /**
         * 重新绘制表格（数据不变）
         * @param $table
         * @param height
         */
        reDrawTable: function ($table, height) {
            var self = this;
            // 获取当前table的页码
            var page = $table.DataTable().page();
            var settings = $table.dataTable().fnSettings();
            $(settings.nScrollBody).css('max-height', self.getTableScrollY() - $(settings.nScrollHead).height() - height);
            // 绘制那一页
            $table.DataTable().page(page).draw('page');
            // 列头不至于挤在一起
            $.fn.dataTable.tables({visible: true, api: true}).columns.adjust();
        },

        /**
         * tab切换订单还是补单
         * @param e
         */
        switchTab: function (e) {
            var self = this;
            var $current = $(e.currentTarget);
            if ($current.hasClass('active')) {
                return;
            }
            $('.orderTab li').removeClass('active');
            $current.addClass('active');
            if ($current.attr('action-name') === '订单') {
                $('#supplement-table-dom').hide();
                $('#supplement-ztree-dom').hide();
                $('#order-table-dom').show();
                $('#order-ztree-dom').show();
                service.curTableInfo = {
                    tableObj: $('#orderTable'),
                    height: 0,
                };
                service.curZtreeInfo = {
                    treeId: 'orderZtree',
                    ztreeDom: 'order-ztree-dom',
                };
            } else if ($current.attr('action-name') === '补单') {
                $('#order-table-dom').hide();
                $('#order-ztree-dom').hide();
                $('#supplement-table-dom').show();
                $('#supplement-ztree-dom').show();
                service.curTableInfo = {
                    tableObj: $('#supplementTable'),
                    height: 30,
                };
                service.curZtreeInfo = {
                    treeId: 'supplementZtree',
                    ztreeDom: 'supplement-ztree-dom',
                };
            }
            self.reDrawTable(service.curTableInfo.tableObj, service.curTableInfo.height);
        },

        initPage: function () {
            var self = this;
            var orderNo = $.trim($('#curOrderNo').html());
            if (orderNo) {
                service.getOrderByOrderNo({
                    data: {orderNo: orderNo},
                    callback: function (resp) {
                        var result = resp.result;
                        $('#orderId').val(result.id);
                        $('#orderOrderNo').val(result.orderNo);
                        $('#orderName').val(result.name);
                        $('#orderAddr').val(result.addr);
                        $('#orderPhoneNo').val(result.phoneNo);
                        $('#lunar').val(result.lunarCalendar);
                        $('#orderTotal').val(result.total);
                        $('#solar').val(new Date(result.solarCalendarLong).format('yyyy-MM-dd')); //初始化时间数据
                    },
                });
            }
            service.getPageInfo({
                data: {orderNo: orderNo},
                callback: function (resp) {
                    self.initZtree(resp);
                    self.initTable(resp);
                },
            });
        },

        /**
         * 日期控件初始化，默认展示一周
         */
        initDate: function () {
        },

        /**
         * 初始化ztree
         */
        initZtree: function (resp) {
            var self = this;
            var setting = {
                check: {
                    enable: true,
                },
                view: {
                    showLine: false,
                    selectedMulti: false,
                },
                callback: {
                    onCheck: function (event, treeId, treeNode) {
                        var val = $('#' + service.curZtreeInfo.ztreeDom + " [action-name='筛选zTree']").val();
                        if ($.trim(val)) {
                            $('#' + service.curZtreeInfo.ztreeDom + " [action-name='筛选zTree']").val('');
                            self.searchTree(service.curZtreeInfo.treeId, '');
                        }
                        var treeObj = $.fn.zTree.getZTreeObj(treeId);
                        if (treeNode.checked) {
                            // 将节点移动到可视区
                            treeObj.selectNode(treeNode);
                            self.addRow(treeNode.data);
                        } else {
                            // 不给用户反选
                            treeObj.checkNode(treeNode, true, false, false);
                        }
                    },
                    onClick: function (event, treeId, treeNode) {
                        var treeObj = $.fn.zTree.getZTreeObj(treeId);
                        treeObj.checkNode(treeNode, null, false, true);
                        // 根节点，原来展开，现在关闭
                        if (treeNode.pId === '0' && treeNode.open) {
                            treeObj.cancelSelectedNode();
                            treeObj.expandNode(treeNode, false, false, true);
                        } else if (treeNode.pId === '0' && !treeNode.open) {
                            treeObj.expandAll(false);
                            // 根节点，原来关闭，现在展开
                            treeObj.expandNode(treeNode, true, false, true);
                        }
                    },
                    onRightClick: function (event, treeId, treeNode) {
                        var zTree = $.fn.zTree.getZTreeObj(treeId);
                        if ((!treeNode && event.target.tagName.toLowerCase() != 'button' && $(event.target).parents('a').length == 0) || treeNode.pId === '0') {
                            $('#rMenu .childAction').hide();
                            $('#rMenu .parentAction').show();
                            zTree.cancelSelectedNode();
                            self.rMenuFloatHandler(event);
                        } else if (treeNode && !treeNode.noR) {
                            $('#rMenu .parentAction').hide();
                            $('#rMenu .childAction').show();
                            zTree.selectNode(treeNode);
                            self.rMenuFloatHandler(event);
                        }
                    },
                },
            };
            $.fn.zTree.init($('#orderZtree'), setting, resp.result.orderTree);
            $.fn.zTree.init($('#supplementZtree'), setting, resp.result.supplementTree);
            service.curZtreeInfo = {
                treeId: 'orderZtree',
                ztreeDom: 'order-ztree-dom',
            };
        },

        /**
         * 处理右键浮动
         * @param event
         */
        rMenuFloatHandler: function (event) {
            var self = this;
            var rMenu = $('#rMenu');
            var x = event.pageX || event.clientX + document.body.scroolLeft;
            var y = event.pageY || event.clientY + document.body.scrollTop;
            var clientHeight = document.body.clientHeight;
            var bottom = clientHeight - y;
            var rH = rMenu.height();
            if (rH > bottom) {
                y = y - rH + bottom;
            }
            rMenu.css({
                top: y + 'px',
                left: x + 'px',
                display: 'block',
                'z-index': 1100,
            });
            $('body').bind('mousedown', self.onBodyMouseDown);
        },
        hideRMenu: function () {
            var self = this;
            var rMenu = $('#rMenu');
            if (rMenu) rMenu.css({display: 'none'});
            $('body').unbind('mousedown', self.onBodyMouseDown);
        },
        onBodyMouseDown: function (event) {
            var rMenu = $('#rMenu');
            if (!(event.target.id == 'rMenu' || $(event.target).parents('#rMenu').length > 0)) {
                rMenu.css({display: 'none'});
            }
        },

        /**
         * 添加数据到data中
         * @param data
         */
        addRow: function (data) {
            // 记录添加的行号到html中
            var rowIdx = service.curTableInfo.tableObj.attr('rowIdx');
            var curRowIdx = Number(rowIdx) + 1;
            service.curTableInfo.tableObj.attr('rowIdx', curRowIdx);

            service.curTableInfo.tableObj
                .DataTable()
                .row.add({
                no: curRowIdx,
                commodityId: data.id,
                commodityName: data.name,
                initial: data.initial,
                price: '0',
                weight: '0',
                unitId: data.unitId,
            })
                .draw();
            //绘制到当前页
            service.curTableInfo.tableObj.DataTable().page('last').draw('page');
            // 滚动到最下方
            var $scrollBody = $(service.curTableInfo.tableObj.DataTable().table().node()).parent();
            $scrollBody.scrollTop($scrollBody.get(0).scrollHeight);
        },

        /**
         * 初始化dataTable
         */
        initTable: function (resp) {
            var self = this;
            $('#order-table-dev').html("<table id='orderTable' name='订单'></table>");
            $('#supplement-table-dev').html("<table id='supplementTable'name='补单'></table>");
            var opt1 = {
                aoColumns: service.getOrderTableColumns(),
                aaData: resp.result.orderTable,
                scrollY: 1000,
                aaSorting: [],
                fnDrawCallback: function (oSettings) {
                    $.formValidate($('#orderForm'));
                }
            };
            var opt2 = {
                aoColumns: service.getOrderTableColumns(),
                aaData: resp.result.supplementTable,
                scrollY: 1000,
                aaSorting: [],
                fnDrawCallback: function (oSettings) {
                    $.formValidate($('#supplementForm'));
                }
            };
            // 给当前table信息赋值
            service.curTableInfo = {
                tableObj: $('#orderTable'),
                height: 0,
            };
            // 初始化table
            $.initDataTable($('#orderTable'), opt1, null, self.getTableScrollY());
            $.initDataTable($('#supplementTable'), opt2, null, self.getTableScrollY());
            // 初始化完列表后将最大行存入html中
            $('#orderTable').attr('rowIdx', $('#orderTable').DataTable().rows().data().length);
            $('#supplementTable').attr('rowIdx', $('#supplementTable').DataTable().rows().data().length);

        },

        /**
         * 获取dataTable纵轴的高度
         * @returns {number}
         */
        getTableScrollY: function () {
            return (
                $('.module.J_dataBlock.data-dictionary-list').height() -
                $('.data-dictionary-list .module-header.J_dataTitle').height() - // 已选商品 header
                $('.tab.navbar-nav.navbar-nav2.orderTab').height() - // 订单补单的tab
                $('#chooseCommodityDom .searchbar.clearfix').height() - // 搜索框
                70
            ); //table列名和底部高度;
        },
    };
});
