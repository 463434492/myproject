define(['/scripts/public/util.js'], function (util) {
    var api = {
        getOrdersList: '/order/getOrdersList',
    };
    var doAjax = function (url, opt, errorMsg) {
        util.doAjax(url, opt.data, opt.ajaxOpt, null)
            .done(function (resp) {
                if (!resp) {
                    $.error('加载数据失败');
                    return false;
                }
                if (!resp.success) {
                    $.error(resp.messages || errorMsg || '加载数据失败');
                    return false;
                }
                if (opt.callback && typeof opt.callback === 'function') {
                    opt.callback(resp);
                }
            })
            .fail(function () {
                $.warn(errorMsg || '操作失败');
            });
    };
    return {
        api: api,
        init: function () {
            var self = this;
        },
        rTime: function (date) {
            var json_date = new Date(date).toJSON();
            return new Date(new Date(json_date) + 8 * 3600 * 1000);
        },
        getColumns: function () {
            var self = this;
            return [
                {
                    mData: 'id',
                    sTitle: '订单Id',
                    defaultContent: '',
                    bSortable: false,
                    visible: false,
                    mRender: function (data) {
                        return data || '';
                    }
                },
                {
                    mData: 'orderNo',
                    sTitle: '订单号',
                    defaultContent: '',
                    bSortable: false,
                    visible: false,
                    mRender: function (data) {
                        return data || '';
                    }
                },
                {
                    mData: 'name',
                    sTitle: '姓名',
                    sWidth: '5%',
                    defaultContent: '',
                    bSortable: false,
                    mRender: function (data, type, row, meta) {
                        return data || '';
                    }
                },
                {
                    mData: 'addr',
                    sTitle: '地址',
                    sWidth: '15%',
                    defaultContent: '',
                    bSortable: false,
                    mRender: function (data) {
                        return data || '';
                    }
                },
                {
                    mData: 'phoneNo',
                    sTitle: '电话',
                    sWidth: '10%',
                    defaultContent: '',
                    bSortable: false,
                    mRender: function (data, type, row, meta) {
                        return data || '';
                    }
                },
                {
                    mData: 'createTime',
                    sTitle: '创建时间',
                    sWidth: '10%',
                    defaultContent: '',
                    bSortable: false,
                    mRender: function (data, type, row, meta) {
                        return self.rTime(data).format('yyyy-MM-dd HH:mm:ss');
                    }
                },
                {
                    mData: 'solarCalendar',
                    sTitle: '公历',
                    sWidth: '10%',
                    defaultContent: '',
                    bSortable: false,
                    mRender: function (data, type, row, meta) {
                        return self.rTime(data).format('yyyy-MM-dd');
                    }
                },
                {
                    mData: 'lunarCalendar',
                    sTitle: '农历',
                    sWidth: '10%',
                    defaultContent: '',
                    bSortable: false,
                    mRender: function (data, type, row, meta) {
                        return data || '';
                    }
                },
                {
                    mData: 'total',
                    sTitle: '合计',
                    sWidth: '5%',
                    defaultContent: '',
                    bSortable: false,
                    mRender: function (data, type, row, meta) {
                        return data || '';
                    }
                },
                {
                    mData: 'operate',
                    sTitle: '操作',
                    sWidth: '10%',
                    defaultContent: '',
                    bSortable: false,
                    mRender: function (data, type, row, meta) {
                        return '<a class="btn-fa" data-toggle="tooltips" data-placement="top" data-title="编辑" id="saveOrder"' +
                            '   href="javascript:void(0);">' +
                            '    <i class="fa fa-pencil"></i>' +
                            '</a>' +
                            '<a class="btn-fa" data-toggle="tooltips" data-placement="top" data-title="删除" id="deliverGoods"' +
                            '   href="javascript:void(0);">' +
                            '    <i class="fa fa-trash-solid"></i>' +
                            '</a>';
                    }
                }
            ];
        },
    };
});
