define(['/scripts/project/order/history/historyOrderService.js', '/scripts/public/util.js'], function (service, util) {
    return {
        init: function () {
            var self = this;
            service.init();
            self.bindEvent();
            self.initDate();
            self.drawTableWithAjax();
        },
        /**
         * 绑定事件
         */
        bindEvent: function () {
            var self = this;
            // dataTable相关的事件
            $("[data-module='addOrEditOrder']")
                .on('focus', '.chooseCommodityForm input', function (e) {
                    $(e.currentTarget).select();
                    return false;
                });
        },
        initDate: function () {
            var startTime = new Date(new Date() - 30 * 24 * 60 * 60 * 1000).format('yyyy-MM-dd 00:00:00'),
                endTime = new Date().format('yyyy-MM-dd 23:59:59');

            $('#startTime').val(startTime); // 初始化时间数据
            $('#endTime').val(endTime); //初始化时间数据
        },
        /**
         * 绘制表格
         *
         */
        drawTableWithAjax: function () {
            var self = this;
            $('#history-order-div').html("<table id='task-list-table' class='tables tables-line'></table>");
            var opt = {
                "aoColumns": service.getColumns(),
                "aaSorting": [],
                "retrieve": true,
                "searching": false, //不使用过滤功能
                "lengthChange": false, //用户不可改变每页显示数量
                "serverSide": true,
                "scrollY": 1000,
                "ajax": {
                    "url": service.api.getOrdersList,
                    "type": "POST",
                    "data": {
                        startTime: $("#startTime").val(),
                        endTime: $("#endTime").val()
                    },
                    "beforeSend": function () {
                        $("#ajaxSubmittingTip").show();
                    },
                    "dataFilter": function (resp) {
                        resp = JSON.parse(resp);
                        var result = '{"iTotalRecords" : 0, "iTotalDisplayRecords" : 0, "sEcho" : "1", "aaData" : [ ]}';
                        if (resp && !resp.success) {
                            $.warn(resp.messages || "请求失败，没有获取到数据，请联系管理员！");
                            return result;
                        }
                        if (!resp.result) {
                            return result;
                        }
                        return JSON.stringify(resp.result);
                    },
                    "complete": function () {
                        $("#ajaxSubmittingTip").hide();
                    }
                }
            };
            $.initDataTable($("#task-list-table"), opt, null, self.getTableScrollY());
        },
        /**
         * 获取dataTable纵轴的高度
         * @returns {number}
         */
        getTableScrollY: function () {
            return (
                $('.flexitem-main.webmain').height() -
                $('.page-titlebar').height() - // 已选商品 header
                $('.module-header.J_dataTitle').height() - // 订单补单的tab
                $('.searchbar.clearfix').height() - // 搜索框
                90
            ); //table列名和底部高度;
        },
    };
});
