var Effect = {
    init: function () {
        this._initDownTriangle();
        this._initNavButton();
        this._initSidebar();
        this._menuToggle();

    },

    //下拉三角形的点击--done
    _initDownTriangle: function () {
        // $("body").on("click", ".J_dataBlock .animation-reverse", function (e) {
        //     var $this = $(this).parents('.J_dataBlock');
        //     //当前按钮
        //     var theBtn = $(this);
        //     //判断按钮当前状态并添加class样式
        //     theBtn.hasClass("reverse") ? theBtn.removeClass('reverse') : theBtn.addClass('reverse');
        //     $this.find('.J_dataContent').slideToggle();
        // });
    },

    //tab切换的效果--done
    _initNavButton: function () {
        var $nav = $('.J_tabNav');
        $nav.click(function (e) {
            var theTarget = $(e.target);
            var $this = theTarget.hasClass('nav-button') ? theTarget : theTarget.parents('.nav-button');
            if ($this.length > 0) {
                $nav.find('.nav-button.active').removeClass('active');
                $this.addClass('active');
            }
        });
    },

    _initSidebar: function () {
        var $sidebar = $('#sideBar');
        var $wrapper = $('.wrapper');
        var top = $wrapper.length ? $wrapper.offset().top : 0;
        $(window).scroll(function (e) {
            var scrollTop = $(window).scrollTop();
            if (scrollTop > top) {
                $sidebar.addClass('fixed');
            } else {
                $sidebar.removeClass('fixed');
            }
        });
    },


    //菜单切换
    _menuToggle: function () {

        //侧边栏折叠
        $(document).on('click', '#J_BdCollapse', function () {
            var $bdSidebar = $('.sidemenubar'), $bdContent = $('.maincontent-fix');

            if ($(this).hasClass('reverse')) {
                $bdContent.animate({'left': 221}, 100);
                $bdSidebar.animate({'width': 220}, 100).find('.title,.side-content').fadeIn();
                $bdSidebar.remove('collapse');
                $(this).removeClass('reverse');
            } else {
                $bdSidebar.animate({'width': 30}, 100).find('.title,.side-content').css('display', 'none');
                $bdContent.animate({'left': 31}, 100);
                $bdSidebar.addClass('collapse');
                $(this).addClass('reverse');
            }
        });


        //侧边栏两级菜单
        $(document).on('click', '.side-list>li', function () {
            if ($(this).hasClass('open')) {
                $(this).removeClass('open');
                $(this).children('.side-list-sub').slideToggle("fast");
                ;
                $(this).find('.link-arrow').removeClass('reverse');
            } else {
                $(this).addClass('selected open');
                $(this).siblings('li').removeClass('selected open').children('.side-list-sub').find('li').removeClass('selected');
                $(this).children('.side-list-sub').slideToggle("fast");
                ;
                $(this).find('.link-arrow').addClass('reverse');
            }
        });

        $(document).on('click', '.side-list>li>ul>li', function (e) {
            $('.side-list>li>ul>li').removeClass('selected');
            $(this).addClass('selected');
            e.stopPropagation();
        });


        // 侧边栏显示隐藏
        $(document).on('click', '.J_collapse .J_toggleButton', function (e) {
            var $this = $(this).parents('.J_collapse');
            if ($this.hasClass('collapse')) {
                $this.removeClass('collapse');
            } else {
                $this.addClass('collapse');
            }

            if ($(this).hasClass('reverse')) {
                $(this).removeClass('reverse');
            } else {
                $(this).addClass('reverse');
            }
        });

    },


};

$(function () {
    Effect.init();
});
