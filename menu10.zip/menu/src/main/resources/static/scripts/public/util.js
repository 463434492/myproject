/**
 * 前端工具类
 *
 */
define(function () {
    return {
        /**
         * 封装ajax异步请求入口 [doAjax description]
         * @param  {[type]} url    [请求路径]
         * @param  {[type]} data   [ajax请求参数]
         * @param  {[type]} opt    [ajax请求配置]
         * @param  {[type]} action [请求类型:get/post/put/delete,其他的慎用]
         * @return {[type]}        [description]
         */
        doAjax: function (url, data, opt, action) {
            return $.lzyAjax(url, data, opt, action);
        },

        /**
         * 封装ajaxForm异步请求入口 [ajaxForm description]
         *
         * @param {[type]}
         *            $form [要提交的表单的jQuery对象]
         * @param {[type]}
         *            url [请求路径]
         * @param {[type]}
         *            opt [ajax请求配置]
         * @return {[type]} [description]
         */
        ajaxForm: function ($form, url, opt) {
            return $.lzyAjaxForm($form, url, opt);
        },

        /**
         * 传递json字符串ajax
         * @param url
         * @param data
         */
        postJson: function (url, data, success, fail) {
            var self = this;
            return self.doAjax(url, JSON.stringify(data || {}), {
                contentType: 'application/json;charset=UTF-8',
                success: success,
                error: fail
            });
        },

        /**
         * 带提示框的ajax
         */
        postJsonMsg: function (msg, url, data, success, fail) {
            var self = this;
            self
                .postJson(url, data)
                .done(function (res) {
                    if (!res.success) {
                        $.error(res.messages || msg + '失败');
                        return false;
                    }
                    if (typeof success === 'function') {
                        $.msg(res.messages || msg + '成功');
                        success(res);
                    }
                })
                .fail(function (res) {
                    $.error(res.messages || msg + '失败');
                    if (typeof fail === 'function') {
                        fail(res);
                    }
                });
        },

        /**
         * array去重
         */
        uniqBy: function (a, key) {
            var seen = {};
            return a.filter(function (item) {
                var k = key(item);
                return seen.hasOwnProperty(k) ? false : (seen[k] = true);
            });
        },

        /**
         * 将Object的null,defined,false,NaN转换为空字符串
         */
        removeObjNull: function (obj) {
            //for in loop 没有闭包，多使用Object.keys和$.each方法，且会找到原型链上的属性，所以要使用o.hasOwnProperty()方法判断是否是自身的属性
            Object.keys(obj).map(function (key, index) {
                var o = obj[key];
                if (!o && o !== 0) {
                    obj[key] = '';
                }
                return null;
            });
        },

        /**
         * array去重通过JSON.stringify
         */
        uniqByStringify: function (a) {
            var self = this;
            return self.uniqBy(a, JSON.stringify);
        },

        /**
         * 对象数组根据自定义属性去重
         *
         * @param arr 对象数组
         * @param attr 比较哪些属性的数组 e.g. ['id','name']
         * @returns {Array} 返回去重的对象数组
         */
        uniqueObjArr: function (arr, attr) {
            var tmp = [];
            $.each(arr, function (index, item) {
                var events = $.grep(tmp, function (e) {
                    var flag = true;
                    $.each(attr, function (i, it) {
                        flag &= item[it] === e[it];
                    });
                    return flag;
                });
                if (events.length === 0) {
                    tmp.push(item);
                }
            });
            return tmp;
        },

        /**
         * 获取前端html模板方法<!注意 模板命名已模块名开头,请求路径为resources/moduleName/*.html>
         *
         * @param {[type]}
         *            [url] [模板资源名称]
         * @return {[type]} [description]
         */
        getTemPlates: function (url) {
            var self = this;
            var templateHtmlTpl = $.appCache.templates[url];
            if (templateHtmlTpl) {
                return $.templates(templateHtmlTpl);
            } else {
                self
                    .doAjax(url, null, {
                        type: 'get', //静态资源使用get方式请求
                        dataType: 'html',
                        async: false
                    })
                    .done(function (resp) {
                        $.appCache.templates[url] = resp;
                        templateHtmlTpl = resp;
                    });
            }
            return $.templates(templateHtmlTpl);
        },

        /**
         * 日期字符串格式化接口(返回格式为:'yyyy-MM-dd')
         * @param  {[type]} dateStr   [description]
         * @param  {[type]} formatStr [description]
         * @param  {[type]} needDay [是否需要星期]
         * @return {[type]}           [description]
         */
        dateFormat: function (dateStr, formatStr, needDay) {
            var self = this;
            if (!dateStr) {
                return '';
            }
            if ($.isString(dateStr)) {
                dateStr = dateStr.replace(/-/g, '/');
            }
            var myFormatStr = formatStr || 'yyyy-MM-dd';
            var date = new Date(dateStr);
            var day = needDay ? '(' + self.WEEK[date.getDay()].zh + ') ' : '';
            return date.format(myFormatStr) + day;
        },

        /**
         * 日期和时间的字符串
         * @param  {[type]} dateStr [description]
         * @param  {[type]} needDay [是否需要星期]
         * @return {[type]}         [description]
         */
        dateTimeFormat: function (dateStr, needDay) {
            var self = this;
            if ($.isString(dateStr)) {
                dateStr = dateStr.replace(/-/g, '/');
            }
            var dateTime = self.dateFormat(dateStr, 'yyyy-MM-dd HH:mm:ss');
            var tempArr = dateTime.split(' ');
            if (tempArr.length !== 2 || !needDay) {
                return dateTime;
            }

            var date = new Date(dateStr);
            var day = '(' + self.WEEK[date.getDay()].zh + ') ';

            return tempArr[0] + day + tempArr[1];
        },

        /**
         * 将表单数据转换成Object如：{Name:'摘取天上星',position:'IT技术'}
         * ps:注意将同名的放在一个数组里
         * @param  {[type]} form [description]
         * @return {[type]}      [description]
         */
        getFormValue: function ($form) {
            var obj = {};
            var formValue = $($form).serializeArray();
            $.each(formValue, function () {
                if (obj[this.name] !== undefined) {
                    if (!obj[this.name].push) {
                        obj[this.name] = [obj[this.name]];
                    }
                    obj[this.name].push($.trim(this.value) || '');
                } else {
                    obj[this.name] = $.trim(this.value) || '';
                }
            });
            return obj;
        },

        /**
         * 迭代去空字符串函数
         */
        removeBlank: function (obj) {
            (function filter(obj) {
                $.each(obj, function (key, value) {
                    if (value === '' || value === null || value === undefined) {
                        delete obj[key];
                    } else if (Object.prototype.toString.call(value) === '[object Object]') {
                        filter(value);
                    } else if ($.isArray(value)) {
                        $.each(value, function (k, v) {
                            filter(v);
                        });
                    }
                });
            })(obj);
            return obj;
        },

        /**
         * 判断是否是整数
         * @param val
         * @returns {boolean}
         */
        isInteger: function (val) {
            return /^([0-9]+)$/.test(val);
        },

        /**
         * 获取表格指定行的数据
         * @return {[type]} [description]
         */
        getSelectedRowData: function ($table, $tr) {
            if (!$table || !$tr) {
                return {};
            }
            return $table.dataTable().fnGetData($tr);
        },

        /**
         * 删除指定行
         * @param  {[type]} $table [description]
         * @param  {[type]} $tr    [description]
         * @return {[type]}        [description]
         */
        delSelectedRowData: function ($table, $tr) {
            if (!$table || !$tr) {
                return {};
            }
            return $table.dataTable().fnDeleteRow($tr);
        },

        /**
         * dataTable数据筛选
         * @param 选择器
         * @param 筛选Str
         */
        dataTableDoSearch: function ($selector, searchStr) {
            $selector
                .DataTable()
                .search(searchStr, false, true)
                .draw();
        },
        /**
         * dataTable重载（data存在且不为空时  ）
         */
        reloadTable: function ($selector, data) {
            var table = $selector.dataTable();
            table.fnClearTable();
            if (data && !$.isEmptyObject(data)) {
                //null undefined '' 0 false NaN
                table.fnAddData(data);
            }
            table.fnDraw();
        },
        /**
         * optopn下拉数据处理
         * @param  {[type]} optData [description]
         * @param  {[type]} key     [description]
         * @return {[type]}         [description]
         */
        optionDataAdapter: function (optData, key, value) {
            $.each(optData, function (index, item) {
                if (typeof value !== 'undefined' && item.STYPE === value) {
                    item.selected = true;
                }
            });
        },
        /**
         * 根据代码获取显示值
         * @param  {[type]} data [description]
         * @param  {[type]} type [description]
         * @return {[type]}      [description]
         */
        getDisplayValueByType: function (data, type) {
            var obj;
            $.each(data, function (index, item) {
                if (item.STYPE === type) {
                    obj = item.NAME;
                    return false;
                }
            });
            return obj;
        },
        /**
         * js 数组 转obj
         * @param  {[type]} datas [description]
         * @param  {[type]} key   [description]
         * @return {[type]}       [description]
         */
        listToMap: function (datas, key) {
            var obj = {};
            if (!datas || !key) {
                return obj;
            }
            $.each(datas, function (index, item) {
                var val = item[key];
                if (!obj[val]) {
                    obj[val] = [item];
                } else {
                    obj[val].push(item);
                }
            });
            return obj;
        },

        /**
         * 全选或取消全选 指定jquery容器内的 checkBox
         * @param  {[type]} $dom        [jquery容器]
         * @param  {[type]} checkedFlag [true 表示全选 ，false 表示取消全选]
         * @param  {[type]} name        [checkbox name属性值]
         * @return {[type]}             [description]
         */
        selectedAll: function ($dom, checkedFlag, name) {
            if (!$dom || !name) {
                return;
            }
            $($dom)
                .find("[type='checkbox'][name='" + name + "']input")
                .prop('checked', checkedFlag);
        },

        /**
         * 将数字格式化为千分位表示的字符串
         * @param num
         * @return {*}
         */
        formatNumInThousandth: function (num) {
            if (isNaN(num)) {
                return '-';
            }
            if (goog.string.isEmptyOrWhitespaceSafe(num)) {
                return '-';
            }
            var str = num + '';
            return str.replace(/\d{1,3}(?=(\d{3})+$)/g, function (s) {
                return s + ',';
            });
        },
        /**
         * 获取zTree当前节点的全部子节点
         * @param  {[type]} ids      [description]
         * @param  {[type]} treeNode [description]
         * @return {[type]}          [description]
         */
        getAllChildren: function (treeNodeArr, treeNode) {
            var self = this;
            if (!treeNode) {
                return;
            }
            treeNodeArr.push(treeNode);
            if (treeNode.isParent) {
                for (var obj in treeNode.children) {
                    self.getAllChildren(treeNodeArr, treeNode.children[obj]);
                }
            }
            return treeNodeArr;
        },
        /**
         * zTree模糊搜索
         */
        searchTree: $.searchTree,

        /**
         * 封装get异步请求入口 [doGet description]
         * @param  {[type]} url    [请求路径]
         * @param  {[type]} data   [ajax请求参数]
         * @param  {[type]} opt    [ajax请求配置]
         * @return {[type]}        [description]
         */
        doGet: function (url, data, opt) {
            return this.doAjax(url, data, opt, 'get');
        },

        /**
         * 星期 n
         * @type {Object}
         */
        WEEK: {
            0: {
                zh: '星期天',
                en: 'Sunday'
            },
            1: {
                zh: '星期一',
                en: 'Monday'
            },
            2: {
                zh: '星期二',
                en: 'Tuesday'
            },
            3: {
                zh: '星期三',
                en: 'Wednesday'
            },
            4: {
                zh: '星期四',
                en: 'Thursday'
            },
            5: {
                zh: '星期五',
                en: 'Friday'
            },
            6: {
                zh: '星期六',
                en: 'Saturday'
            }
        }
    };
});
