/**
 * 表单自定义校验规则
 */
(function () {
    //校验方法 以validate 开头
    $.metadata.setType('attr', 'validate');
    /**
     * 自定义表单提示消息,覆盖jQuery.validator.messages
     */
    $.extend(jQuery.validator.messages, {
        required: '必填项',
        remote: 'Please fix this field.',
        url: 'URL地址格式错误，请确认',
        date: '日期格式错误，请确认',
        dateISO: '日期格式(ISO)错误，请确认.',
        number: '请输入数字',
        digits: '请输入整数',
        creditcard: '信用卡号码格式错误',
        equalTo: '两次输入不一致',
        accept: '后缀名错误',
        chinese: '请输入中文',
        letter: '请输入字母',
        ip: 'IP地址格式错误',
        maxlength: $.validator.format('不能超过 {0} 个字符'),
        minlength: $.validator.format('不能少于 {0} 个字符'),
        rangelength: $.validator.format('字符长度必须在 {0} 到 {1} 之间'),
        range: $.validator.format('值大小必须在 {0} 到 {1}之间'),
        max: $.validator.format('最大值不超过 {0}'),
        min: $.validator.format('最小值不小于 {0}')
    });
    //非空校验
    jQuery.validator.addMethod(
        'required',
        function (value, element) {
            // 如果是数组判断数组长度
            if (value instanceof Array) {
                return value.length > 0;
            }
            return jQuery.trim(value) != '';
        },
        '必填项'
    );
    // 用户名校验，只能输入字母和数字_-@.
    jQuery.validator.addMethod(
        'isUsername',
        function (value, element) {
            var name = /^[a-zA-Z0-9\-_@.]*$/;
            return this.optional(element) || name.test(value);
        },
        '只能包含字母、数字和_-@.'
    );
    // 只能输入字母和数字_-
    jQuery.validator.addMethod(
        'ischarNumber',
        function (value, element) {
            var name = /^[a-zA-Z0-9\-_]*$/;
            return this.optional(element) || name.test(value);
        },
        '只能包含字母、数字和_-'
    );
    // 只能输入汉字、字母和数字_-
    jQuery.validator.addMethod(
        'ischaracterNumber',
        function (value, element) {
            var name = /^[a-zA-Z0-9\-_\u4e00-\u9fa5]*$/;
            return this.optional(element) || name.test(value);
        },
        '只能包含汉字、字母、数字和_-'
    );
    // 数据库密码校验
    jQuery.validator.addMethod(
        'updataPwd',
        function (value, element) {
            var name = /^[a-zA-Z][a-zA-Z0-9]{5,19}$/;
            return this.optional(element) || name.test(value);
        },
        '字母开头，只能包含字母和数字'
    );
    // 数据库名表名和字段名的校验
    jQuery.validator.addMethod(
        'sqlName',
        function (value, element) {
            var name = /^[a-zA-Z]{1}[a-zA-Z\d_]*$/;
            return this.optional(element) || name.test(value);
        },
        '字母开头，只能包含字母、数字和下划线'
    );
    // 非负整数
    jQuery.validator.addMethod(
        'isNumber',
        function (value, element) {
            var tel = /^\d*$/;
            return this.optional(element) || tel.test(value);
        },
        '请输入非负整数'
    );
    //密码验证,数字，字符，字母，不少于8位
    jQuery.validator.addMethod(
        'passwordCheck',
        function (value, element) {
            var password = /^(?=.*[0-9])(?=.*[a-zA-Z])(?=.*[^a-zA-Z0-9]).{8,}$/;
            return this.optional(element) || password.test(value);
        },
        '密码格式不正确'
    );
    //邮箱
    jQuery.validator.addMethod(
        'email',
        function (value, element) {
            var password = /^\w+([-+.\w])*@\w+([-.\w])*\.\w+([-.\w])*$/;
            return this.optional(element) || password.test(value);
        },
        '邮箱格式不正确'
    );
    //ip验证
    jQuery.validator.addMethod(
        'ip',
        function (value, element) {
            var ip = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
            return this.optional(element) || (ip.test(value) && (RegExp.$1 < 256 && RegExp.$2 < 256 && RegExp.$3 < 256 && RegExp.$4 < 256));
        },
        '格式不正确'
    );
    //多个ip验证，多个用英文逗号分隔
    jQuery.validator.addMethod(
        'multiIp',
        function (value, element) {
            var ip = /^((25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(25[0-5]|2[0-4]\d|[01]?\d\d?)(,((25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(25[0-5]|2[0-4]\d|[01]?\d\d?))*$/;
            return this.optional(element) || ip.test(value);
        },
        '格式不正确'
    );
    //端口验证，支持范围80-65535
    jQuery.validator.addMethod(
        'port',
        function (value, element) {
            var port = /^([8-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])$/;
            return this.optional(element) || port.test(value);
        },
        '格式不正确'
    );
    //多个端口验证，支持范围80-65535，多个用英文逗号分隔
    jQuery.validator.addMethod(
        'multiPort',
        function (value, element) {
            var port = /^([8-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])(,([8-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5]))*$/;
            return this.optional(element) || port.test(value);
        },
        '格式不正确'
    );
    //uri检测
    jQuery.validator.addMethod(
        'uri',
        function (value, element) {
            var uri = /^[/][0-9A-Za-z_%?&-=/]+$/;
            return this.optional(element) || uri.test(value);
        },
        '格式不正确'
    );
    //链接完整性检测
    jQuery.validator.addMethod(
        'url',
        function (value, element) {
            var url = /^(http|https):\/\/[\w\-_]+(\.[\w\-_]+)+([\w\-.,@?^=%&:/~+#]*[\w\-@?^=%&/~+#])?$/;
            return this.optional(element) || url.test(value);
        },
        '格式不正确'
    );
    jQuery.validator.addMethod(
        'https',
        function (value, element) {
            var url = /^(https):\/\/[\w\-_]+(\.[\w\-_]+)+([\w\-.,@?^=%&:/~+#]*[\w\-@?^=%&/~+#])?$/;
            return this.optional(element) || url.test(value);
        },
        '格式不正确,必须符合https协议'
    );
    // 字符验证
    jQuery.validator.addMethod(
        'stringCheck',
        function (value, element) {
            return this.optional(element) || /^[a-zA-Z]\w*$/.test(value);
        },
        '只能包括英文字母、数字和下划线'
    );

    // 身份证号码验证
    jQuery.validator.addMethod(
        'isIdCardNo',
        function (value, element) {
            var card = /(^[1-9]\d{5}(18|19|([23]\d))\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$)|(^[1-9]\d{5}\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\d{2}$)/;
            return this.optional(element) || card.test(value);
        },
        '身份证号码格式不正确'
    );

    // 手机号码验证
    jQuery.validator.addMethod(
        'isMobile',
        function (value, element) {
            var length = value.length;
            var mobile = /^1\d{10}$/;
            return this.optional(element) || (length === 11 && mobile.test(value));
        },
        '请正确填写手机号码'
    );

    // 电话号码验证
    jQuery.validator.addMethod(
        'isTel',
        function (value, element) {
            var tel = /^0\d{2,3}-?\d{7,8}$/;
            return this.optional(element) || tel.test(value);
        },
        '电话格式不正确'
    );

    // 联系电话(手机/电话皆可)验证
    jQuery.validator.addMethod(
        'isPhone',
        function (value, element) {
            var mobile = /^1\d{10}$/;
            var tel = /^0\d{2,3}-?\d{7,8}$/;
            var result = this.optional(element) || (tel.test(value) || mobile.test(value));
            return result;
        },
        '电话格式不正确'
    );

    // 邮政编码验证
    jQuery.validator.addMethod(
        'isZipCode',
        function (value, element) {
            var tel = /^[1-9][0-9]{5}$/;
            return this.optional(element) || tel.test(value);
        },
        '邮编格式不正确'
    );

    // 匹配qq
    jQuery.validator.addMethod(
        'isQq',
        function (value, element) {
            var tel = /^[1-9]\d{4,9}$/;
            return this.optional(element) || tel.test(value);
        },
        'QQ格式不正确'
    );

    // 汉字
    jQuery.validator.addMethod(
        'chcharacter',
        function (value, element) {
            var tel = /^[\u4e00-\u9fa5]+$/;
            return this.optional(element) || tel.test(value);
        },
        '请输入中文字符'
    );

    // 字符最小长度验证（一个中文字符长度为3）
    jQuery.validator.addMethod(
        'stringMinLength',
        function (value, element, param) {
            var length = value.length;
            return this.optional(element) || length >= param;
        },
        $.validator.format('不能少于 {0} 个字符')
    );

    // 字符最大长度验证（一个中文字符长度为3）
    jQuery.validator.addMethod(
        'stringMaxLength',
        function (value, element, param) {
            var length = value.length;
            return this.optional(element) || length <= param;
        },
        $.validator.format('不能超过 {0} 个字符')
    );

    // 字符长度范围验证（一个中文字符长度为3）
    jQuery.validator.addMethod(
        'stringLengthRange',
        function (value, element, param) {
            var length = value.length;
            return this.optional(element) || (length >= param[0] && length <= param[1]);
        },
        '字符长度必须在 {0} 到 {1} 之间'
    );

    // >0的两位小数
    jQuery.validator.addMethod(
        'meteringNum',
        function (value, element) {
            var reg = /(^[1-9]([0-9]+)?(\.[0-9]{1,2})?$)|(^(0){1}$)|(^[0-9]\.[0-9]([0-9])?$)/;
            var result = this.optional(element) || reg.test(value);
            if (result && Number(value) === 0) {
                return false;
            }
            return result;
        },
        '数字必须>0且最多是两位小数'
    );

    // 请输入字母
    jQuery.validator.addMethod(
        'letter',
        function (value, element) {
            var reg = /^[a-zA-Z]+$/;
            return this.optional(element) || reg.test(value);
        },
        '请输入字母'
    );

    //TODO(zhangfeng): 这个方法没用到，注释掉先
    // function isIdCardNo(num) {
    //   var factorArr = new Array(7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2, 1);
    //   var parityBit = new Array('1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2');
    //   var varArray = new Array();
    //   // var intValue;
    //   var lngProduct = 0;
    //   var intCheckDigit;
    //   var intStrLen = num.length;
    //   var idNumber = num;
    //   // initialize
    //   if (intStrLen != 15 && intStrLen != 18) {
    //     return false;
    //   }
    //   // check and set value
    //   for (var i = 0; i < intStrLen; i++) {
    //     varArray[i] = idNumber.charAt(i);
    //     if ((varArray[i] < '0' || varArray[i] > '9') && i != 17) {
    //       return false;
    //     } else if (i < 17) {
    //       varArray[i] = varArray[i] * factorArr[i];
    //     }
    //   }
    //   if (intStrLen == 18) {
    //     //check date
    //     var date8 = idNumber.substring(6, 14);
    //     if (isDate8(date8) == false) {
    //       return false;
    //     }
    //     // calculate the sum of the products
    //     for (var t = 0; t < 17; t++) {
    //       lngProduct = lngProduct + varArray[t];
    //     }
    //     // calculate the check digit
    //     intCheckDigit = parityBit[lngProduct % 11];
    //     // check last digit
    //     if (varArray[17] != intCheckDigit) {
    //       return false;
    //     }
    //   } else {
    //     //length is 15
    //     //check date
    //     var date6 = idNumber.substring(6, 12);
    //     if (isDate6(date6) == false) {
    //       return false;
    //     }
    //   }
    //   return true;
    // }

    // function isDate6(sDate) {
    //   if (!/^[0-9]{6}$/.test(sDate)) {
    //     return false;
    //   }
    //   var year, month; //, day;
    //   year = sDate.substring(0, 4);
    //   month = sDate.substring(4, 6);
    //   if (year < 1700 || year > 2500) return false;
    //   if (month < 1 || month > 12) returnfalse;
    //   return true;
    // }

    // function isDate8(sDate) {
    //   if (!/^[0-9]{8}$/.test(sDate)) {
    //     return false;
    //   }
    //   var year, month, day;
    //   year = sDate.substring(0, 4);
    //   month = sDate.substring(4, 6);
    //   day = sDate.substring(6, 8);
    //   var iaMonthDays = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    //   if (year < 1700 || year > 2500) return false;
    //   if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0) iaMonthDays[1] = 29;
    //   if (month < 1 || month > 12) returnfalse;
    //   if (day < 1 || day > iaMonthDays[month - 1]) return false;
    //   return true;
    // }
})();
