(function () {
    /**
     函数：日期Date类添加原型方法format 格式化日期
     参数：formatStr-格式化字符串
     d：将日显示为不带前导零的数字，如1
     dd：将日显示为带前导零的数字，如01
     ddd：将日显示为缩写形式，如Sun
     dddd：将日显示为全名，如Sunday
     M：将月份显示为不带前导零的数字，如一月显示为1
     MM：将月份显示为带前导零的数字，如01
     MMM：将月份显示为缩写形式，如Jan
     MMMM：将月份显示为完整月份名，如January
     yy：以两位数字格式显示年份
     yyyy：以四位数字格式显示年份
     h：使用12小时制将小时显示为不带前导零的数字，注意||的用法
     hh：使用12小时制将小时显示为带前导零的数字
     H：使用24小时制将小时显示为不带前导零的数字
     HH：使用24小时制将小时显示为带前导零的数字
     m：将分钟显示为不带前导零的数字
     mm：将分钟显示为带前导零的数字
     s：将秒显示为不带前导零的数字
     ss：将秒显示为带前导零的数字
     l：将毫秒显示为不带前导零的数字
     ll：将毫秒显示为带前导零的数字
     tt：显示am/pm
     TT：显示AM/PM
     返回：格式化后的日期
     */
    Date.prototype.format = function (fmt) {
        var date = this;
        var zeroize = function (value, length) {
            if (!length) {
                length = 2;
            }
            value = new String(value);
            for (var i = 0, zeros = ''; i < length - value.length; i++) {
                zeros += '0';
            }
            return zeros + value;
        };
        fmt = fmt || 'yyyy-MM-dd HH:mm:ss';
        var o = {
            'd{4}': ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][date.getDay()],
            'd{3}': ['Sun', 'Mon', 'Tue', 'Wed', 'Thr', 'Fri', 'Sat'][date.getDay()],
            'd{2}': zeroize(date.getDate()),
            'd{1}': date.getDate(),
            'M{4}': ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'][
                date.getMonth()
                ],
            'M{3}': ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][date.getMonth()],
            'M{2}': zeroize(date.getMonth() + 1),
            'M{1}': date.getMonth() + 1,
            'y{4}': date.getFullYear(),
            'y{2}': new String(date.getFullYear()).substr(2),
            'h{2}': zeroize(date.getHours() % 12 || 12),
            'h{1}': date.getHours() % 12 || 12,
            'H{2}': zeroize(date.getHours()),
            'H{1}': date.getHours(),
            'm{2}': zeroize(date.getMinutes()),
            'm{1}': date.getMinutes(),
            's{2}': zeroize(date.getSeconds()),
            's{1}': date.getSeconds(),
            'l{2}': zeroize(date.getMilliseconds()),
            'l{1}': date.getMilliseconds(),
            't{2}': date.getHours() < 12 ? 'am' : 'pm',
            'T{2}': date.getHours() < 12 ? 'AM' : 'PM',
            'S{1}': date.getMilliseconds() //毫秒
        };
        var fmtStrObj = {};
        var i = 0;
        while (i < Object.keys(o).length) {
            i = 0;
            for (var k in o) {
                if (new RegExp('(' + k + ')').test(fmt)) {
                    var rep = '$' + Math.random();
                    fmt = fmt.replace(RegExp.$1, rep);
                    fmtStrObj[rep] = o[k];
                    break;
                }
                i++;
            }
        }
        for (var key in fmtStrObj) {
            fmt = fmt.replace(key, fmtStrObj[key]);
        }
        return fmt;
    };

    /**
     * 判断字符串是否以指定字符串开头
     * @param  {string} startStr  指定字符串
     * @return {boolean}        返回是否以指定字符串开头的结果
     */
    String.prototype._startWith = function (startStr) {
        var fullString = this;
        return startStr != undefined && !isNaN(startStr) && fullString.indexOf(startStr) === 0;
    };

    /**
     * 判断字符串是否以指定字符串结尾
     * @param  {string} endStr  指定字符串
     * @return {boolean}        返回是否以指定字符串结尾的结果
     */
    String.prototype._endWith = function (endStr) {
        var fullString = this;
        return (
            endStr != undefined &&
            !isNaN(endStr) &&
            fullString
                .split('')
                .reverse()
                .join('')
                .indexOf(
                    (endStr + '')
                        .split('')
                        .reverse()
                        .join('')
                ) === 0
        );
    };

    /**
     * 重写$.fn.load方法
     */
    $.fn.extend({
        load: function (url, params, callback, logoutInTopWindow) {
            var $dom = $(this);
            if (!url) {
                return false;
            }
            var ajaxDefaultOpt = {
                url: url,
                data: params,
                type: 'post',
                logoutInTopWindow: logoutInTopWindow || true, // 如果页面使用iframe嵌套，默认找到最上一层页面进行登录跳转
                complete: function (XHR, textStatus) {
                    if (XHR.status === 901 || XHR.responseText.indexOf('统一登录') > -1) {
                        $.warn('登录超时，请重新登录！', {
                            yesCallBack: function () {
                                if (typeof this.logoutInTopWindow != 'undefined' && this.logoutInTopWindow == false) {
                                    window.location.href = APPURL + '/j_spring_cas_security_logout';
                                } else {
                                    window.top.location.href = APPURL + '/j_spring_cas_security_logout';
                                }
                            }.bind(this)
                        });
                    } else {
                        $dom.html(XHR.responseText);
                    }
                    if (callback && typeof callback === 'function') {
                        callback.apply(this, arguments);
                    }
                }
            };
            var ajaxDefaultOptForFirstTime = {
                url: url,
                data: params,
                type: 'post',
                logoutInTopWindow: logoutInTopWindow || true, // 如果页面使用iframe嵌套，默认找到最上一层页面进行登录跳转
                complete: function (XHR, textStatus) {
                    if (XHR && XHR.status === 901) {
                        var iframeUrl = url.indexOf('http') != 0 ? window.location.protocol + '//' + window.location.host + url : url;
                        $('body').append('<iframe style="display: none;" id ="iframeForLoginRedirect" src="' + iframeUrl + '"><iframe>');
                        var iframeForLoginRedirect = document.getElementById('iframeForLoginRedirect');

                        if (iframeForLoginRedirect.attachEvent) {
                            iframeForLoginRedirect.attachEvent('onload', function () {
                                $('#iframeForLoginRedirect').remove();
                                $.ajax(ajaxDefaultOpt);
                            });
                        } else {
                            iframeForLoginRedirect.onload = function () {
                                $('#iframeForLoginRedirect').remove();
                                $.ajax(ajaxDefaultOpt);
                            };
                        }
                    }
                    if (XHR && XHR.responseText) {
                        if (XHR.responseText.indexOf('统一登录') > -1) {
                            $.warn('登录超时，请重新登录！', {
                                yesCallBack: function () {
                                    if (typeof this.logoutInTopWindow != 'undefined' && this.logoutInTopWindow == false) {
                                        window.location.href = APPURL + '/j_spring_cas_security_logout';
                                    } else {
                                        window.top.location.href = APPURL + '/j_spring_cas_security_logout';
                                    }
                                }.bind(this)
                            });
                        } else {
                            $dom.html(XHR.responseText);
                        }
                    }
                    if (callback && typeof callback === 'function') {
                        callback.apply(this, arguments);
                    }
                }
            };
            return $.ajax(ajaxDefaultOptForFirstTime);
        }
    });

    //封装jquery 工具插件
    $.extend({
        /**
         * 全局模板缓存
         *
         * @type {Object}
         */
        appCache: {
            templates: {}
        },
        /**
         * 封装ajax异步请求入口 [doAjax description]
         * @param  {[type]} url    [请求路径]
         * @param  {[type]} data   [ajax请求参数]
         * @param  {[type]} opt    [ajax请求配置]
         * @param  {[type]} action [请求类型:get/post/put/delete,其他的慎用]
         * @return {[type]}        [description]
         */
        lzyAjax: function (url, data, opt, action) {
            // var self = this;
            if (!url) {
                return false;
            }
            var ajaxDefaultOpt = {
                url: url,
                data: data,
                type: action || 'post',
                dataType: 'json',
                showSubmittingTip: true,
                tipClass: 'show_' + Math.round(Math.random() * Math.pow(10, 18)),
                logoutInTopWindow: true // 如果页面使用iframe嵌套，默认找到最上一层页面进行登录跳转
            };
            var oldBeforeSendFun;
            var oldCompleteFun;
            if (opt) {
                ajaxDefaultOpt = $.extend(ajaxDefaultOpt, opt);
                oldBeforeSendFun = opt.beforeSend;
                oldCompleteFun = opt.complete;
            }
            ajaxDefaultOpt.beforeSend = function (XHR) {
                if (ajaxDefaultOpt.showSubmittingTip && $('#ajaxSubmittingTip').length > 0) {
                    $('#ajaxSubmittingTip')
                        .show()
                        .addClass(ajaxDefaultOpt.tipClass);
                    $('#popupDiv').show();
                }
                if (oldBeforeSendFun) {
                    oldBeforeSendFun.apply(this, arguments);
                }
            };
            ajaxDefaultOpt.complete = function (XHR, textStatus) {
                if (ajaxDefaultOpt.showSubmittingTip && $('#ajaxSubmittingTip').length > 0) {
                    $('#ajaxSubmittingTip').removeClass(ajaxDefaultOpt.tipClass);
                    if (
                        $('#ajaxSubmittingTip')
                            .attr('class')
                            .indexOf('show_') === -1
                    ) {
                        $('#ajaxSubmittingTip').hide();
                        $('#popupDiv').hide();
                    }
                }
                if (XHR) {
                    if (XHR.status === 403) {
                        $.warn('没有权限访问该资源！');
                        return;
                    }
                    if (XHR.status === 404) {
                        $.warn('访问的资源不存在！');
                        return;
                    }
                    if (XHR.status === 500) {
                        $.warn('服务器发生了一点错误，请联系管理员！');
                        return;
                    }
                    if (XHR.status === 901 || (XHR.responseText && XHR.responseText.indexOf('统一登录') > -1)) {
                        $.warn('登录超时，请重新登录！', {
                            yesCallBack: function () {
                                if (typeof this.logoutInTopWindow != 'undefined' && this.logoutInTopWindow == false) {
                                    window.location.href = APPURL + '/j_spring_cas_security_logout';
                                } else {
                                    window.top.location.href = APPURL + '/j_spring_cas_security_logout';
                                }
                            }.bind(this)
                        });
                    }
                    if (XHR.responseJSON) {
                        var resp = XHR.responseJSON;
                        if (resp && resp.errMessages) {
                            var date = new Date();
                            if (!$('#errorMsg')[0]) {
                                $('body').append($('<div style="display:none;" id="errorMsg">'));
                            }
                            $('#errorMsg').append('<p><span>' + date.toLocaleString() + '</span>' + resp.errMessages + '</p>');
                        }
                    }
                }
                if (oldCompleteFun) {
                    oldCompleteFun.apply(this, arguments);
                }
            };
            return $.ajax(ajaxDefaultOpt);
        },
        /**
         * 封装ajaxForm异步请求入口 [ajaxForm description]
         *
         * @param {[type]}
         *            $form [要提交的表单的jQuery对象]
         * @param {[type]}
         *            url [请求路径]
         * @param {[type]}
         *            opt [ajax请求配置]
         * @return {[type]} [description]
         */
        lzyAjaxForm: function ($form, url, opt) {
            if (!url) {
                return false;
            }
            var ajaxFormDefaultOpt = {
                url: url,
                type: 'post',
                dataType: 'json',
                showSubmittingTip: true,
                tipClass: 'show_' + Math.round(Math.random() * Math.pow(10, 18)),
                logoutInTopWindow: true // 如果页面使用iframe嵌套，默认找到最上一层页面进行登录跳转
            };
            var oldBeforeSubmitFun;
            var oldCompleteFun;
            if (opt) {
                ajaxFormDefaultOpt = $.extend(ajaxFormDefaultOpt, opt);
                oldBeforeSubmitFun = opt.beforeSubmit;
                oldCompleteFun = opt.complete;
            }
            ajaxFormDefaultOpt.beforeSubmit = function (formData, $form, options) {
                if (ajaxFormDefaultOpt.showSubmittingTip && $('#ajaxSubmittingTip').length > 0) {
                    $('#ajaxSubmittingTip')
                        .show()
                        .addClass(ajaxFormDefaultOpt.tipClass);
                    $('#popupDiv').show();
                }
                if (oldBeforeSubmitFun) {
                    oldBeforeSubmitFun.apply(this, arguments);
                }
            };
            ajaxFormDefaultOpt.complete = function (XHR, textStatus) {
                if (ajaxFormDefaultOpt.showSubmittingTip && $('#ajaxSubmittingTip').length > 0) {
                    $('#ajaxSubmittingTip').removeClass(ajaxFormDefaultOpt.tipClass);
                    if (
                        $('#ajaxSubmittingTip')
                            .attr('class')
                            .indexOf('show_') === -1
                    ) {
                        $('#ajaxSubmittingTip').hide();
                        $('#popupDiv').hide();
                    }
                }
                if (XHR) {
                    if (XHR.status === 403) {
                        $.warn('没有权限访问该资源！');
                        return;
                    }
                    if (XHR.status === 404) {
                        $.error('访问的资源不存在！');
                        return;
                    }
                    if (XHR.status === 500) {
                        $.error('服务器发生了一点错误，请联系管理员！');
                        return;
                    }
                    if (XHR.status === 901 || (XHR.responseText && XHR.responseText.indexOf('统一登录') > -1)) {
                        $.warn('登录超时，请重新登录！', {
                            yesCallBack: function () {
                                if (typeof this.logoutInTopWindow != 'undefined' && this.logoutInTopWindow == false) {
                                    window.location.href = APPURL + '/j_spring_cas_security_logout';
                                } else {
                                    window.top.location.href = APPURL + '/j_spring_cas_security_logout';
                                }
                            }.bind(this)
                        });
                    }
                    if (XHR.responseJSON) {
                        var resp = XHR.responseJSON;
                        if (resp && resp.errMessages) {
                            var date = new Date();
                            if (!$('#errorMsg')[0]) {
                                $('body').append($('<div style="display:none;" id="errorMsg">'));
                            }
                            $('#errorMsg').append('<p><span>' + date.toLocaleString() + '</span>' + resp.errMessages + '</p>');
                        }
                    }
                }
                if (oldCompleteFun) {
                    oldCompleteFun.apply(this, arguments);
                }
            };
            return $form.ajaxForm(ajaxFormDefaultOpt).submit();
        },
        /**
         * 消息提示
         * @param  {[type]}   msg      [description]
         * @param  {[type]}   interval [description]
         * @param  {Function} callback [description]
         * @return {[type]}            [description]
         */
        msg: function (msg, opt) {
            //依赖alertify.js
            if ('undefined' !== typeof alertify) {
                var defaults = {
                    logPosition: 'top right', //设置消息的显示位置 "top left" || "top right" ||"bottom left" || "bottom right"
                    callback: null, //回调
                    type: '', //设置消息提示的类型 "normal" || "success" || "error" 默认是黑色的样式 可以自定义className区分消息类型
                    interval: 5000 //设置显示时间 默认是5000毫秒
                };
                var options = $.extend({}, defaults, opt);
                alertify.logPosition(options['logPosition']);
                alertify._$$alertify.delay = options['interval'];
                alertify._$$alertify.log(msg, options['type']);
                if ($.isFunction(options['callback'])) {
                    options.callback();
                }
            } else {
                if (!msg) {
                    if (opt && opt.callback) {
                        opt.callback();
                    }
                    return;
                }
                var domId = 'hint_' + Math.round(Math.random() * Math.pow(10, 18));
                $('body').append(
                    '<div class="dialog-hint fixed" id="' + domId + '" style="z-index:99999;"><div class="dialog-hint-info">' + msg + '</div></div>'
                );

                var myInterval = 1500;
                if (opt && opt.interval) {
                    myInterval = opt.interval;
                }
                setTimeout(function () {
                    if ($('#' + domId).length !== 0) {
                        $('#' + domId).fadeOut(200, function () {
                            $(this).remove();
                            if (opt && opt.callback) {
                                opt.callback();
                            }
                        });
                    } else {
                        if (opt && opt.callback) {
                            opt.callback();
                        }
                    }
                }, myInterval);
                return domId;
            }
        },
        /**
         * 警告提示
         * @param  {[type]} msg [提示消息字符串]
         * @param  {[type]} opt [相关参数,yesCallBack: 点击确定按钮的回调]
         * @return {[type]}     [description]
         */
        warn: function (msg, opt) {
            var randomId = Math.ceil(Math.random() * 100);
            var templateHtml =
                '<div id="lzy-tool-warn' +
                randomId +
                '"><div class="depict" ><i class="fa fa-warning"></i> <div class="depict-info"><span>' +
                msg +
                '</span></div></div></div>';
            var myOpt = {
                title: '警告',
                width: 300,
                position: {
                    my: 'center',
                    at: 'center',
                    of: window,
                    collision: 'fit'
                },
                buttons: {
                    确定: function ($dom) {
                        if (opt && opt.yesCallBack && typeof opt.yesCallBack === 'function') {
                            opt.yesCallBack();
                        }
                        $('#lzy-tool-warn' + randomId).dialog('destroy');
                    }
                }
            };
            $.dialog($(templateHtml), myOpt);
        },

        /**
         * 消息提示框
         * @param  {[type]} msg [description]
         * @param  {[type]} opt [结构:{callBack:function}]
         * @return {[type]}     [description]
         */
        confirm: function (msg, opt) {
            var randomId = Math.ceil(Math.random() * 100);
            var templateHtml =
                '<div id="lzy-tool-confirm' +
                randomId +
                '"><div class="depict" ><i class="fa fa-question-circle"></i><div class="depict-info"><span>' +
                msg +
                '</span></div></div></div>';
            var myOpt = {
                title: '提示',
                width: 300,
                position: {
                    my: 'center',
                    at: 'center',
                    of: window,
                    collision: 'fit'
                },
                buttons: {
                    确定: function ($dom) {
                        if (opt && opt.yesCallBack && typeof opt.yesCallBack === 'function') {
                            opt.yesCallBack();
                        }
                        $('#lzy-tool-confirm' + randomId).dialog('destroy');
                    },
                    取消: function ($dom) {
                        if (opt && opt.noCallBack && typeof opt.noCallBack === 'function') {
                            opt.noCallBack();
                        }
                        $('#lzy-tool-confirm' + randomId).dialog('destroy');
                    }
                },
                close: function (event, ui) {
                    if (opt && opt.noCallBack && typeof opt.noCallBack === 'function') {
                        opt.noCallBack();
                    }
                }
            };
            $.dialog($(templateHtml), myOpt);
        },
        /**
         * 失败提示
         * @param  {[type]} msg [description]
         * @param  {[type]} opt [description]
         * @return {[type]}     [description]
         */
        error: function (msg, opt) {
            var randomId = Math.ceil(Math.random() * 100);
            var templateHtml =
                '<div id="lzy-tool-error' +
                randomId +
                '"><div class="depict" ><i class="fa fa-times-circle"></i><div class="depict-info"><span>' +
                msg +
                '</span></div></div></div>';
            var myOpt = {
                title: '错误',
                width: 300,
                position: {
                    my: 'center',
                    at: 'center',
                    of: window,
                    collision: 'fit'
                },
                buttons: {
                    确定: function ($dom) {
                        if (opt && opt.yesCallBack && typeof opt.yesCallBack === 'function') {
                            opt.yesCallBack();
                        }
                        $('#lzy-tool-error' + randomId).dialog('destroy');
                    }
                }
            };
            $.dialog($(templateHtml), myOpt);
        },
        /**
         * object 转 jsonStr
         * @param  {[type]} obj [description]
         * @return {[type]}     [description]
         */
        toJsonStr: function (obj) {
            return JSON.stringify(obj);
        },
        /**
         * JsonStr 转 Obj
         * @param  {[type]} str [description]
         * @return {[type]}     [description]
         */
        toJson: function (str) {
            try {
                return JSON.parse(str);
            } catch (e) {
                return {};
            }
        },
        /**
         * 格式化数字为千分位字符串
         * @num 要格式化的数字
         * @fixed 要保留的小数位数，即精度
         */
        formatNumber: function (num, fixed) {
            if (!isNaN(num)) {
                var tempNum = (num + '').split('.');
                if (fixed && !isNaN(fixed)) {
                    tempNum = (Number(num).toFixed(fixed) + '').split('.');
                }
                var result = tempNum[0].replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&,');
                if (tempNum.length > 1) {
                    result += '.' + tempNum[1];
                }
                return result;
            }
            return num;
        },
        /**
         * 初始化表格组件入口
         *
         * @param {[type]} $tabledom [div占位]
         * @param {[type]} dataTableOpt [参数信息]
         * @param {[type]} isBackStage [是否需要后台分页]
         * @param {[type]} height [dataTables的高度]
         * @return {[type]} [description]
         */
        initDataTable: function ($tableDom, dataTableOpt, isBackStage, height) {
            var defaultOpt = {
                destroy: true, // 允许重新实例化Datatables
                ordering: true, // 是否启用Datatables排序
                scrollCollapse: true, // 开启滚动条
                processing: true, //    显示加载信息
                serverSide: false, // 开启服务器模式
                autoWidth: false, // 让Datatables自动计算宽度
                //stateSave: true, // 允许浏览器缓存Datatables，以便下次恢复之前的状态
                searching: true, // 开启搜索功能
                info: true, // 开启Datatables信息显示
                lengthMenu: [[20, 50, 100, 250, -1], [20, 50, 100, 250, '全部']], // 改变每页显示条数列表的选项
                lengthChange: true, // 允许改变每页显示的数据条数
                pageLength: 20, // 更改初始页面长度 （每页的行数）
                paging: true, // 允许表格分页
                pagingType: 'full_numbers', // 分页按钮种类显示选项
                language: {
                    url: '/thirdparty/jquery-dataTables/cn.txt' // 从 Ajax 源加载数据的表的内容
                },
                dom: 'rt<"bottom"lip>' // 按什么顺序定义表的控制元素在页面上出现
            };
            var oldDrawCallback = dataTableOpt.drawCallback;
            dataTableOpt['drawCallback'] = function (opt) {
                $(opt.nTableWrapper)
                    .off('click', '#checkAll:not(".disabled")')
                    .on('click', '#checkAll:not(".disabled")', function (event) {
                        // 此处table实时获取，防止使用全局变量导致状态共享
                        var table = $(opt.nTable).DataTable();
                        // 使用筛选功能的时候，再次筛选的结果中，点击全选时，先把所有不在当前结果中的已选中的去掉勾选
                        var allRows = table.rows(function (idx, data, node) {
                            return data.disabled ? false : true;
                        })[0];
                        var curSearchResult = table.rows(
                            function (idx, data, node) {
                                return data.disabled ? false : true;
                            },
                            {
                                search: 'applied'
                            }
                        )[0];
                        var notInSearchResult = [];
                        for (var idx in allRows) {
                            if (curSearchResult.indexOf(allRows[idx]) === -1) {
                                notInSearchResult.push(allRows[idx]);
                            }
                        }
                        table.rows(notInSearchResult).deselect();

                        if (
                            table
                                .rows({
                                    selected: true,
                                    search: 'applied'
                                })
                                .data().length ===
                            table
                                .rows(
                                    function (idx, data, node) {
                                        return data.disabled ? false : true;
                                    },
                                    {
                                        search: 'applied'
                                    }
                                )
                                .data().length
                        ) {
                            table
                                .rows(
                                    function (idx, data, node) {
                                        return data.disabled ? false : true;
                                    },
                                    {
                                        search: 'applied'
                                    }
                                )
                                .deselect();
                        } else {
                            table
                                .rows(
                                    function (idx, data, node) {
                                        return data.disabled ? false : true;
                                    },
                                    {
                                        search: 'applied'
                                    }
                                )
                                .select();
                        }
                    });

                if (oldDrawCallback && 'function' == typeof oldDrawCallback) {
                    oldDrawCallback(opt);
                }
            };

            if (dataTableOpt.lzySelect) {
                dataTableOpt['select'] = {
                    style: 'multi',
                    selector: 'td:first-child .checkbox'
                };
                var selectColumn = [
                    {
                        data: 'id',
                        title: "<i class='checkbox' id='checkAll'></i>",
                        width: dataTableOpt.selectColumnWidth ? dataTableOpt.selectColumnWidth : '1%',
                        orderable: false,
                        render: function (data, type, row, meta) {
                            return '<i class="checkbox' + (row.disabled ? ' disabled' : '') + '"></i>';
                        }
                    }
                ];
                if (dataTableOpt.aoColumns) {
                    dataTableOpt['aoColumns'] = selectColumn.concat(dataTableOpt['aoColumns']);
                }
                if (dataTableOpt.columns) {
                    dataTableOpt['columns'] = selectColumn.concat(dataTableOpt['columns']);
                }
            }
            if (isBackStage) {
                var otherOpt = {
                    serverSide: true, // 开启服务器模式
                    ajax: {
                        url: null, // 从 Ajax 源加载数据的表的内容
                        dataSrc: null // 表数据的数据属性或操作方法
                    }
                };
                defaultOpt = $.extend(defaultOpt, otherOpt);
            }
            var opt = $.extend(defaultOpt, dataTableOpt);
            var table = $tableDom.DataTable(opt);

            table
                .on('select', function (e, dt, type, indexes) {
                    if (!dt) {
                        return;
                    }
                    if (
                        dt
                            .rows({
                                selected: true
                            })
                            .data().length < dt.rows().data().length
                    ) {
                        $(dt.containers()[0])
                            .find('#checkAll:not(".disabled")')
                            .addClass('half-check');
                    } else {
                        $(dt.containers()[0])
                            .find('#checkAll:not(".disabled")')
                            .removeClass('half-check')
                            .addClass('checked');
                    }

                    if (dataTableOpt.selectedCallback && 'function' == typeof dataTableOpt.selectedCallback) {
                        dataTableOpt.selectedCallback(e, dt, type, indexes);
                    }
                })
                .on('deselect', function (e, dt, type, indexes) {
                    if (!dt) {
                        return;
                    }
                    if (
                        dt
                            .rows({
                                selected: true
                            })
                            .data().length === 0
                    ) {
                        $(dt.containers()[0])
                            .find('#checkAll:not(".disabled")')
                            .removeClass('checked')
                            .removeClass('half-check');
                    } else {
                        $(dt.containers()[0])
                            .find('#checkAll:not(".disabled")')
                            .removeClass('checked')
                            .addClass('half-check');
                    }

                    if (dataTableOpt.deselectedCallback && 'function' == typeof dataTableOpt.deselectedCallback) {
                        dataTableOpt.deselectedCallback(e, dt, type, indexes);
                    }
                })
                .on('init', function (e, settings, json) {
                    if (height) {
                        $(settings.nScrollBody).css(
                            'max-height',
                            height -
                            $(settings.nScrollHead).height() -
                            $(settings.nTableWrapper)
                                .find('.bottom')
                                .height()
                        );
                    }
                });

            return table;
        },
        /**
         * [可输可选的下拉组件]
         * @param  {[type]} $dom       [jquery选择器]
         * @param  {[type]} select2Opt [参数]
         * @return {[type]}            [description]
         */
        initSelect2: function ($dom, select2Opt) {
            var defaultOpt = {
                placeholder: '请选择',
                allowClear: true,
                language: 'zh-CN', //国际化中文
                multiple: false, //是否允许多选
                escapeMarkup: function (m) {
                    return m;
                }
            };
            var opt = $.extend(defaultOpt, select2Opt);
            return $dom.select2(opt);
        },
        /**
         * 对话框组件
         * @return {[type]} [description]
         */
        dialog: function ($dialog, dialogOpt) {
            var defaultOpt = {
                dialogClass: 'z_index_1000',
                autoOpen: true, //自动打开
                modal: true, //是否模式对话框
                draggable: true, //是否允许拖动
                title: '标题', //标题
                resizable: false, //是否允许改变窗口大小
                maxHeight: 800,
                position: {
                    my: 'top',
                    at: 'top',
                    of: window,
                    collision: 'fit',
                    using: function (pos) {
                        $(this).css('top', 80);
                        $(this).css('left', pos.left);
                    }
                },
                closeText: '关闭',
                dragStop: function (event, ui) {
                    $(event.target)
                        .closest('.ui-dialog')
                        .css('height', 'auto');
                },
                close: function (event, ui) {
                    $(this).dialog('destroy');
                }
            };
            var closeCallback = dialogOpt.close;
            if (dialogOpt && dialogOpt.close) {
                defaultOpt.close = function (event, ui) {
                    closeCallback(event, ui);
                    $(this).dialog('destroy');
                };
                delete dialogOpt.close;
            }
            var opt = $.extend(defaultOpt, dialogOpt);
            $($dialog).dialog(opt);
        },

        /**
         * 初始化树组件(V 0.0.1 版本使用zTree)
         * @param  {[type]} $treeDom [description]
         * @param  {[type]} treeOpt  [description]
         * @return {[type]} treeSetting [description]
         */
        initTree: function ($treeDom, treeNodes, treeSetting) {
            var defaultTreeSetting = {
                view: {
                    selectedMulti: true, //设置是否能够同时选中多个节点
                    showIcon: true, //设置是否显示节点图标
                    showLine: true, //设置是否显示节点与节点之间的连线
                    showTitle: true //设置是否显示节点的title提示信息
                },
                data: {
                    simpleData: {
                        enable: true, //设置是否启用简单数据格式（zTree支持标准数据格式跟简单数据格式）
                        idKey: 'id', //设置启用简单数据格式时id对应的属性名称
                        pidKey: 'pId' //设置启用简单数据格式时parentId对应的属性名称,ztree根据id及pid层级关系构建树结构
                    }
                },
                check: {
                    enable: false //设置是否显示checkbox复选框
                },
                callback: {
                    onClick: null, //定义节点单击事件回调函数
                    onRightClick: null, //定义节点右键单击事件回调函数
                    beforeRename: null, //定义节点重新编辑成功前回调函数，一般用于节点编辑时判断输入的节点名称是否合法
                    onDblClick: null, //定义节点双击事件回调函数
                    onCheck: null //定义节点复选框选中或取消选中事件的回调函数
                },
                async: {
                    enable: false //设置启用异步加载
                }
            };
            var finalTreeSetting = $.extend(defaultTreeSetting, treeSetting);
            return $($treeDom).zTree.init($($treeDom), finalTreeSetting, treeNodes);
        },
        /**
         * [初始化下拉多选组件]
         * @param  {[type]} $dom [description]
         * @param  {[type]} opt  [description]
         * @return {[type]}      [description]
         */
        initMultiSelect: function ($dom, opt) {
            var defaultOpt = {
                header: true,
                classes: '',
                noneSelectedText: '==请选择==',
                checkAllText: '全选',
                uncheckAllText: '全不选',
                selectedText: '# 选中',
                selectedList: 0,
                show: null,
                hide: null,
                autoOpen: false,
                multiple: true,
                position: {},
                menuWidth: null
            };
            var finalOpt = $.extend(defaultOpt, opt);
            $dom.multiselect(finalOpt);
        },

        /**
         * json字符串 兼容IE
         * @param  {[type]} data [description]
         * @return {[type]}      [description]
         */
        formatJsonForIE: function (data) {
            if ($.isString(data)) {
                //IE的情况下需要去除文本格式<pre></pre>标签
                var reg = new RegExp('<(/?)pre>', 'ig');
                data = data.replace(reg, '');
                data = eval('(' + data + ')'); // NOSONAR
            }
            return data;
        },
        /**
         * 获取文件大小
         * @param  {[type]} sizeRaw [description]
         * @return {[type]}         [description]
         */
        getFileSize: function (sizeRaw) {
            var size = '0 B';
            var sizeb = parseFloat(sizeRaw);
            var sizekb = parseFloat(sizeb) / 1024;
            var sizemb = parseFloat(sizekb) / 1024;
            var sizegb = parseFloat(sizemb) / 1024;
            var sizetb = parseFloat(sizegb) / 1024;
            var sizepb = parseFloat(sizetb) / 1024;
            var sizeeb = parseFloat(sizepb) / 1024;
            var sizezb = parseFloat(sizeeb) / 1024;
            var sizeyb = parseFloat(sizezb) / 1024;
            var sizebb = parseFloat(sizeyb) / 1024;
            var sizenb = parseFloat(sizebb) / 1024;
            var sizedb = parseFloat(sizenb) / 1024;
            if (sizeb > 1) size = sizeb.toFixed(2) + ' B';
            if (sizekb > 1) size = sizekb.toFixed(2) + ' KB';
            if (sizemb > 1) size = sizemb.toFixed(2) + ' MB';
            if (sizegb > 1) size = sizegb.toFixed(2) + ' GB';
            if (sizetb > 1) size = sizetb.toFixed(2) + ' TB';
            if (sizepb > 1) size = sizepb.toFixed(2) + ' PB';
            if (sizeeb > 1) size = sizeeb.toFixed(2) + ' EB';
            if (sizezb > 1) size = sizezb.toFixed(2) + ' ZB';
            if (sizeyb > 1) size = sizeyb.toFixed(2) + ' YB';
            if (sizebb > 1) size = sizebb.toFixed(2) + ' BB';
            if (sizenb > 1) size = sizenb.toFixed(2) + ' NB';
            if (sizedb > 1) size = sizedb.toFixed(2) + ' DB';
            return size;
        },
        /**
         * 选择checkbox
         * @param  {[type]} name [description]
         * @return {[type]}      [description]
         */
        clickSelect: function (name) {
            if (!name) name = 'selected';
            var allSelect = true;
            $.each($('input:checkbox[name="' + name + '"]:not(:disabled)'), function (index, item) {
                if (!item.checked) {
                    allSelect = false;
                    return;
                }
            });
            $('input:checkbox[name="' + name + '_all"]')[0].checked = allSelect;
        },
        /**
         * 全选
         * @param  {[type]} name [description]
         * @return {[type]}      [description]
         */
        clickAllSelected: function (name) {
            if (!name) name = 'selected';
            $.each($('input:checkbox[name="' + name + '"]:not(:disabled)'), function (index, item) {
                item.checked = $('input:checkbox[name="' + name + '_all"]')[0].checked;
            });
        },
        /**
         * 选择checkbox
         * @param  {[type]} event [description]
         * @return {[type]}      [description]
         */
        _clickSelect: function (event) {
            var allSelect = true;
            $.each($('input:checkbox[name="selected"]:not(:disabled)'), function (index, item) {
                if (!item.checked) {
                    allSelect = false;
                    return;
                }
            });
            $(event.currentTarget)
                .parents('.tables')
                .find('input:checkbox[name="selected_all"]')[0].checked = allSelect;
        },
        /**
         * 全选
         * @param  {[type]} event [description]
         * @return {[type]}      [description]
         */
        _clickAllSelected: function (event) {
            $.each($('input:checkbox[name="selected"]:not(:disabled)'), function (index, item) {
                item.checked = $(event.currentTarget).attr('checked');
            });
        },
        /**
         * 检查选中项
         * @param  {[type]} name [description]
         * @return {[type]}      [description]
         */
        checkSelected: function (name) {
            if (!name) name = 'selected';
            var selectedNum = 0;
            $.each($('input:checkbox[name="' + name + '"]:not(:disabled)'), function (index, item) {
                if (item.checked) {
                    selectedNum++;
                }
            });
            if (selectedNum == 0) {
                $.msg('未选择任何项！');
                return false;
            }
            return true;
        },
        /**
         * 新的检查选中项，配合新的select组件使用
         * @param datatableSelector
         * @return true/false
         */
        newCheckSelected: function (datatableSelector) {
            if (
                $(datatableSelector)
                    .DataTable()
                    .rows({
                        selected: true
                    })
                    .data().length === 0
            ) {
                $.msg('未选择任何项！');
                return false;
            }
            return true;
        },
        /**
         * 检查多选
         * @param  {[type]} name [description]
         * @return {[type]}      [description]
         */
        checkMultiSelected: function (name) {
            if (!name) name = 'selected';
            if ($('input:checkbox[name="' + name + '"]:checked').size() > 1) {
                $.msg('不能选择多个项！');
                return false;
            }
            return true;
        },
        newCheckMultiSelected: function (datatableSelector) {
            if (
                $(datatableSelector)
                    .DataTable()
                    .rows({
                        selected: true
                    })
                    .data().length > 1
            ) {
                $.msg('不能选择多个项！');
                return false;
            }
            return true;
        },
        /**
         * 清空表单
         * @param  {[type]} formId [description]
         * @return {[type]}        [description]
         */
        cleanForm: function (formId) {
            $('#' + formId)
                .find('.controls-text')
                .val('');
        },
        /**
         * 数据加载中提示
         * @param 选择器
         */
        showLoadingBody: function ($selector) {
            var loadingStr =
                '<div class="msg msg-loading">' + '<i class="fa fa-spinner fa-spin"></i><span>数据加载中，请稍候...</span>' + '</div>';
            $selector.html(loadingStr);
        },
        /**
         * 没有查询到数据提示(用于datatable)
         * @param 选择器
         */
        showNoDataBody: function ($selector) {
            var noDataStr = '<div class="msg msg-info">' + '<i class="fa fa-info-circle"></i><span>没有查询到数据</span>' + '</div>';
            $selector.html(noDataStr);
        },
        /**
         * 添加无数据提示(用于除datatable的其他场景)
         * @param  {[type]} $dom): function(     [description]
         * @return {[type]}        [description]
         */
        showContainerNoDataBody: function ($dom) {
            if (!$dom) {
                return;
            }
            var noDataStr = '<div class="nodatas"><i class="fa fa-file-text-o"></i><span class="nodata-text">目前还没有数据</span></div>';
            $($dom).append(noDataStr);
        },
        /**
         * 表单校验
         * @param  {[type]} $form [description]
         * @return {[type]}       [description]
         */
        formValidate: function ($form) {
            if (!$form) {
                return;
            }
            return $($form).valid();
        },
        /**
         * 是否字符串
         * @param  {[type]}  obj [description]
         * @return {Boolean}     [description]
         */
        isString: function (obj) {
            return typeof obj === 'string' && obj.constructor == String;
        },
        /**
         * 是否整数
         * @param  {[type]}  obj [description]
         * @return {Boolean}     [description]
         */
        isInteger: function (obj) {
            return typeof obj === 'number' && obj % 1 == 0;
        },
        /**
         * 判断是否是身份证号码
         * @param  {[type]}  value [description]
         * @return {Boolean}       [description]
         */
        isCardNo: function (value) {
            value = $.clearBlank(value);
            var cardno = /(^[1-9]\d{5}(18|19|([23]\d))\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$)|(^[1-9]\d{5}\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\d{2}$)/;
            return cardno.test(value);
        },
        /**
         * 判断是否为邮箱
         * @param  {[type]}  value [description]
         * @return {Boolean}       [description]
         */
        isEmail: function (value) {
            value = $.clearBlank(value);
            var email = /^\w+([-+.\w])*@\w+([-.\w])*\.\w+([-.\w])*$/;
            return email.test(value);
        },
        /**
         * 判断是否是电话号码
         * @param  {[type]}  value [description]
         * @return {Boolean}       [description]
         */
        isMobile: function (value) {
            value = $.clearBlank(value);
            var tel = /^0\d{2,3}-?\d{7,8}$/; //电话号码验证
            var mobile = /^1\d{10}$/; //手机号码验证
            return tel.test(value) || mobile.test(value);
        },
        /**
         * 判断是否是指定格式的日期串yyyy-MM-dd
         * @param  {[type]}  value [description]
         * @return {Boolean}       [description]
         */
        isDate: function (value) {
            var date = /^((?:19|20)\d\d)-(0[1-9]|1[012])-(0[1-9]|[12][0-9]|3[01])$/;
            return date.test(value);
        },
        /**
         * 去除字符串中的全部空格
         * @param  {[type]} value [description]
         * @return {[type]}       [description]
         */
        clearBlank: function (value) {
            if (!value) {
                return '';
            }
            return (value + '').replace(/[ ]/g, '');
        },

        /**
         * 将表单数据转换成Object如：{Name:'摘取天上星',position:'IT技术'}
         * ps:注意将同名的放在一个数组里
         * @param  {[type]} form [description]
         * @return {[type]}      [description]
         */
        getFormValue: function ($form) {
            var obj = {};
            var formValue = $($form).serializeArray();
            $.each(formValue, function () {
                if (obj[this.name] !== undefined) {
                    if (!obj[this.name].push) {
                        obj[this.name] = [obj[this.name]];
                    }
                    obj[this.name].push(this.value || '');
                } else {
                    obj[this.name] = this.value || '';
                }
            });
            return obj;
        },
        /**
         * 获取前端html模板方法<!注意 模板命名已模块名开头,请求路径为resources/moduleName/*.html>
         *
         * @param {[type]}
         *            [url] [模板资源名称]
         * @return {[type]} [description]
         */
        getTemPlates: function (url) {
            var templateHtmlTpl = $.appCache.templates[url];
            if (templateHtmlTpl) {
                return $.templates(templateHtmlTpl);
            } else {
                var ajaxDefaultOpt = {
                    url: url,
                    async: false,
                    type: 'get',
                    dataType: 'html'
                };
                $.ajax(ajaxDefaultOpt).done(function (resp) {
                    $.appCache.templates[url] = resp;
                    templateHtmlTpl = resp;
                });
            }
            return $.templates(templateHtmlTpl);
        },
        /**
         * 日期字符串格式化接口(返回格式为:'yyyy-MM-dd')
         * @param  {[type]} dateStr   [description]
         * @param  {[type]} formatStr [description]
         * @return {[type]}           [description]
         */
        dateFormat: function (dateStr, formatStr) {
            if (!dateStr) {
                return '';
            }
            var myFormatStr = formatStr || 'yyyy-MM-dd';
            var date = new Date(dateStr);
            return date.format(myFormatStr);
        },
        /**
         * @param value 校验字符串
         * @param maxLength 最大长度
         * @description 字符串最大长度验证
         */
        validateStringMaxLength: function (value, maxLength) {
            if (!value || !maxLength) {
                return '';
            }
            var length = value.length;
            if (length > maxLength) {
                return $.validator.format('不能超过 {0} 个字符');
            }
            return '';
        },

        /**
         *
         * @param 表格 jquery 对象
         * @param $item 具体的输入项
         * @description 编辑表格校验
         */
        tableValidate: function ($tableContainer, $item) {
            if (!$tableContainer) {
                return false;
            }

            var tableValidateMethod = {
                /**
                 * 输入项必填校验
                 */
                requiredValidate: function ($item) {
                    // var _this = tableValidateMethod;
                    if (!$item) {
                        return false;
                    }
                    var fieldName = $item.val();
                    $item.next('.data-required').remove();
                    if (!$item.next('.error-msg').length) {
                        $item.removeClass('error');
                    }
                    if (!fieldName) {
                        $item.after("<label  class='error error-msg data-required'>必填项</label>");
                        $item.addClass('error');
                    }
                },

                /**
                 *
                 * @description 表格必填校验
                 */
                trRequiredValidate: function ($tableContainer, $item) {
                    var _this = tableValidateMethod;
                    //  存在 data-required 属性的不能为空
                    if ($item) {
                        if (typeof $item.attr('data-required') === 'undefined') {
                            return;
                        }
                        _this.requiredValidate($item);
                    } else {
                        $tableContainer.find('[data-required]').each(function (index) {
                            _this.requiredValidate($(this));
                        });
                    }
                },

                /**
                 *
                 * @param $tableContainer
                 * @param $item
                 * @description 表格同一列 防重复校验
                 */
                trNotDoubleValidate: function ($tableContainer, $item) {
                    // 存在 data-required 防重复校验
                    var fieldNameArrObj = {};
                    // 遍历每个tr 里面的 data-notdouble
                    $tableContainer.find('tr').each(function (trIndex) {
                        var $tr = $(this);
                        $tr.find('[data-notdouble]').each(function (columnIndex) {
                            var rowFieldNameArr;
                            // 空值直接return
                            if (!$(this).val()) {
                                return true;
                            }

                            if ($item) {
                                var itemColIndex = $item.attr('data-columnindex');
                                var otherColIndex = $(this).attr('data-columnindex');

                                // 指定校验项的话 必须保证 列序号相同
                                if (itemColIndex == otherColIndex) {
                                    $(this)
                                        .next('.data-notdouble')
                                        .remove();
                                    if (!$(this).next('.error-msg').length) {
                                        $(this).removeClass('error');
                                    }
                                    rowFieldNameArr = fieldNameArrObj[itemColIndex] || [];
                                    rowFieldNameArr.push($(this).val());
                                    fieldNameArrObj[itemColIndex] = rowFieldNameArr;
                                }
                            } else {
                                // 对整个表格 做 防重
                                $(this)
                                    .next('.data-notdouble')
                                    .remove();
                                if (!$(this).next('.error-msg').length) {
                                    $(this).removeClass('error');
                                }
                                rowFieldNameArr = fieldNameArrObj[columnIndex] || [];
                                rowFieldNameArr.push($(this).val());
                                fieldNameArrObj[columnIndex] = rowFieldNameArr;
                            }
                        });
                    });

                    // 遍历每列数据 做校验
                    for (var columnIndex in fieldNameArrObj) {
                        var fieldNameArr = fieldNameArrObj[columnIndex];

                        if (!fieldNameArr || !fieldNameArr.length) {
                            return;
                        }

                        var fieldNameArrCount = fieldNameArr.reduce(function (allElements, ele) {
                            if (ele in allElements) {
                                allElements[ele]++;
                            } else {
                                allElements[ele] = 1;
                            }
                            return allElements;
                        }, {});

                        for (var i in fieldNameArrCount) {
                            var count = fieldNameArrCount[i];
                            if (count > 1) {
                                // TODO 当前jquery 版本 1.12.3 不支持 input 的value 属性选择器 so ugly ! 1.4.2 版本及之前版本支持!

                                $tableContainer.find('tr').each(function (trIndex) {
                                    var $filter = $(this);
                                    if ($item) {
                                        $filter = $(this)
                                            .find('td')
                                            .eq($item.attr('data-columnindex'));
                                    }

                                    $filter.find('[data-notdouble]').each(function ($rowIndex) {
                                        var thisVal = $(this).val();
                                        if ($item) {
                                            if (thisVal === i) {
                                                $(this).after("<label  class='error error-msg data-notdouble'>当前列有重复值</label>");
                                                $(this).addClass('error');
                                            }
                                        } else {
                                            if (thisVal === i && $rowIndex == columnIndex) {
                                                $(this).after("<label  class='error error-msg data-notdouble'>当前列有重复值</label>");
                                                $(this).addClass('error');
                                            }
                                        }
                                    });
                                });
                            }
                        }
                    }
                },

                /**
                 * 最大长度校验
                 * @param {*}
                 */
                maxLengthValidate: function ($item) {
                    if (!$item) {
                        return false;
                    }
                    var fieldName = $item.val();
                    $item.next('.data-maxlength').remove();

                    if (!$item.next('.error-msg').length) {
                        $item.removeClass('error');
                    }
                    var maxlength = parseInt($item.attr('data-maxlength'));
                    var msg = $.validateStringMaxLength(fieldName, maxlength);
                    if (msg) {
                        $item.after("<label  class='error error-msg data-maxlength'>最大长度不能超过" + maxlength + ',中文代表3个字符</label>');
                        $item.addClass('error');
                    }
                },

                /**
                 *
                 * @description 表格最大长度校验
                 */
                trMaxLengthValidate: function ($tableContainer, $item) {
                    var _this = tableValidateMethod;
                    if ($item) {
                        if (typeof $item.attr('data-maxlength') === 'undefined') {
                            return;
                        }
                        _this.maxLengthValidate($item);
                    } else {
                        //  最大长度校验
                        $tableContainer.find('[data-maxlength]').each(function (index) {
                            _this.maxLengthValidate($(this));
                        });
                    }
                },

                /**
                 * 字母开头，只能包含字母和下划线
                 */
                ischarNumberValidate: function ($item) {
                    var fieldName = $item.val();
                    $item.next('.data-ischarNumber').remove();
                    if (!$item.next('.error-msg').length) {
                        $item.removeClass('error');
                    }
                    var reg = /^[a-zA-Z]{1}[a-zA-Z\d_]*$/;
                    if (!reg.test(fieldName)) {
                        $item.after("<label  class='error error-msg data-ischarNumber'>字母开头，只能包含字母和下划线</label>");
                        $item.addClass('error');
                    }
                },

                /**
                 *
                 * @description 表格字符串 校验 字母开头，只能包含字母和下划线
                 */
                trIscharNumberValidate: function ($tableContainer, $item) {
                    var _this = tableValidateMethod;
                    if ($item) {
                        if (typeof $item.attr('data-ischarNumber') === 'undefined') {
                            return;
                        }
                        _this.ischarNumberValidate($item);
                    } else {
                        //  最大长度校验
                        $tableContainer.find('[data-ischarNumber]').each(function (index) {
                            _this.ischarNumberValidate($(this));
                        });
                    }
                }
            };

            tableValidateMethod.trRequiredValidate($tableContainer, $item);
            tableValidateMethod.trNotDoubleValidate($tableContainer, $item);
            tableValidateMethod.trMaxLengthValidate($tableContainer, $item);
            tableValidateMethod.trIscharNumberValidate($tableContainer, $item);

            return !$tableContainer.find('.error-msg').length;
        },
        /**
         * 系统错误提示方法
         *
         * @param errorOpt {
         *  errorCode        错误码
         *  errorCallback    错误弹窗回调函数
         *  errorLogs:[      错误日志
         *    {
         *      logTime:'2018-07-04 20:48:37',
         *      logType:'INFO', // INFO|ERROR|WARN
         *      logMsg:'外部资源库 : 外部资源库算子 开始执行...'
         *    }
         *  ]
         * }
         * @example
         *  $.showLzySystemError({
         *    errorCode: "DEFAULT-0000",
         *    errorCallback: function () { },
         *    errorLogs: [
         *      { logTime: '2018-07-04 20:48:37', logType: 'INFO', logMsg: '默认日志 : 开始执行...' },
         *      { logTime: '2018-07-04 20:48:47', logType: 'WARN', logMsg: '警告日志 : 开始执行...' },
         *      { logTime: '2018-07-04 20:48:57', logType: 'ERROR', logMsg: '错误日志 : 开始执行...' }
         *    ]
         *  });
         */
        showLzySystemError: function (errorOpt) {
            $('.lzy-system-error-box').remove();
            var maxIndex = this.getDomMaxZIndex();
            errorOpt = errorOpt || {};
            (function (eOpt, mIndex) {
                eOpt.errorCode = eOpt.errorCode || $.systemErrorDict.DEFAULT_ERROR_CODE;
                var promptbox = $('<div class="promptbox lzy-system-error-box"></div>');
                var promptContent = $('<div class="prompt-content"></div>');
                var errorCodeTemplate = '<div class="errorcode"><span>{{SYSTEMERROR_CODE}}</span></div>';
                var errorCode = $(errorCodeTemplate.replace('{{SYSTEMERROR_CODE}}', '出错代码：' + eOpt.errorCode));
                promptContent.append(errorCode);
                var promptInfo = $('<div class="prompt-info"></div>');
                var promptInfoBaseContent = $('<div></div>');
                if (eOpt.errorCode) {
                    var errorDict = $.systemErrorDict[eOpt.errorCode] || $.systemErrorDict[$.systemErrorDict.DEFAULT_ERROR_CODE];
                    if (errorDict.errorReason) {
                        var resaonTemplate =
                            '<div class="fence fence-red"><h3 class="fence-tittle">出错原因</h3><div class="fence-inner">{{SYSTEMERROR_REASON}}</div></div>';
                        var resaon = $(resaonTemplate.replace('{{SYSTEMERROR_REASON}}', errorDict.errorReason));
                        promptInfoBaseContent.append(resaon);
                    }
                    if (errorDict.errorSolution) {
                        var solutionTemplate =
                            '<div class="fence fence-green"><h3 class="fence-tittle">建议处理方式</h3><div class="fence-inner">{{SYSTEMERROR_SOLUTION}}</div></div>';
                        var solution = $(solutionTemplate.replace('{{SYSTEMERROR_SOLUTION}}', errorDict.errorSolution));
                        promptInfoBaseContent.append(solution);
                    }
                }
                promptInfo.append(promptInfoBaseContent);
                if (eOpt.errorLogs && eOpt.errorLogs.length) {
                    var loglink = $('<a class="loglink" href="javascript:void(0);" title="日志"><i class="fa fa-info-circle"></i></a>');
                    promptContent.append(loglink);
                    loglink.on('click', function () {
                        promptInfoBaseContent.slideToggle();
                        promptInfoLogContent.slideToggle();
                    });
                    var promptInfoLogContent = $('<div class="promplog fence" style="display: none ;"></div>');
                    var logTypeDict = {
                        ERROR: 'log-info-error',
                        WARN: 'log-info-warn'
                    };
                    var logTimeTemplate = '<span class="log-time">{{SYSTEMERROR_LOGTIME}}</span>';
                    var logTypeTemplate = '<span class="log-type">{{SYSTEMERROR_LOGTYPE}}</span>';
                    var logMsgTemplate = '<span class="log-content">{{SYSTEMERROR_LOGMSG}}</span>';
                    $.each(eOpt.errorLogs, function (eli, elogItem) {
                        var elogItemDom = $('<p></p>');
                        if (logTypeDict[elogItem.logType]) {
                            elogItemDom.addClass(logTypeDict[elogItem.logType]);
                        }
                        elogItem.logTime && elogItemDom.append(logTimeTemplate.replace('{{SYSTEMERROR_LOGTIME}}', elogItem.logTime));
                        elogItem.logType && elogItemDom.append(logTypeTemplate.replace('{{SYSTEMERROR_LOGTYPE}}', elogItem.logType));
                        elogItem.logMsg && elogItemDom.append(logMsgTemplate.replace('{{SYSTEMERROR_LOGMSG}}', elogItem.logMsg));
                        promptInfoLogContent.append(elogItemDom);
                    });
                    promptInfo.append(promptInfoLogContent);
                }
                promptContent.append(promptInfo);
                var promptBottom = $('<div class="prompt-bottom"></div>');
                var promptBtn = $('<button class="btn btn-confirm">我知道了</button>');
                promptBottom.append(promptBtn);
                promptBtn.on('click', function () {
                    eOpt.errorCallback && eOpt.errorCallback();
                    promptbox.remove();
                });
                promptContent.append(promptBottom);
                promptbox.append(promptContent);
                promptbox.append($('<div class="prompt-cover"></div>'));
                promptbox.css('z-index', mIndex);
                $(document.body).append(promptbox);
            })(errorOpt, maxIndex);
        },
        /**
         * 系统错误相关 字典
         * 各个系统可以覆盖
         * $.systemErrorDict = $.extend(true,$.systemErrorDict,{各个系统自定义字典库})
         * errorCode:{
         *  errorReason:"",//出错原因
         *  errorSolution:""//建议处理方式
         * }
         */
        systemErrorDict: {
            DEFAULT_ERROR_CODE: 'DEFAULT_SERVER_ERROR',
            DEFAULT_SERVER_ERROR: {
                errorReason: '系统异常',
                errorSolution: '查看日志并联系管理员处理'
            }
        },
        /**
         * 提供最大的 zIndex 防止遮盖
         */
        getDomMaxZIndex: function () {
            var allDoms = $('body *');
            var max = 0;
            $.each(allDoms, function (i, allDomItem) {
                max = Math.max(max, allDomItem.style.zIndex || 0);
            });
            return max + 1;
        },
        checkBrowserSupport: function () {
            var Sys = {};
            var ua = navigator.userAgent.toLowerCase();
            var s;
            (s = ua.match(/rv:([\d.]+)\) like gecko/))
                ? (Sys.ie = s[1])
                : (s = ua.match(/msie ([\d.]+)/))
                ? (Sys.ie = s[1])
                : (s = ua.match(/firefox\/([\d.]+)/))
                    ? (Sys.firefox = s[1])
                    : (s = ua.match(/chrome\/([\d.]+)/))
                        ? (Sys.chrome = s[1])
                        : (s = ua.match(/opera.([\d.]+)/))
                            ? (Sys.opera = s[1])
                            : (s = ua.match(/version\/([\d.]+).*safari/))
                                ? (Sys.safari = s[1])
                                : 0;

            if (Sys.ie && parseInt(Sys.ie) >= 10) {
                return true;
            }
            if (Sys.firefox && parseInt(Sys.firefox) >= 41) {
                return true;
            }
            if (Sys.chrome && parseInt(Sys.chrome) >= 49) {
                return true;
            }
            return false;
        },
        /**
         * zTree模糊搜索
         */
        searchTree: function (treeId, keyword, notExpandFirstLevel) {
            var tree = $.fn.zTree.getZTreeObj(treeId);
            var allTreeNodes = tree.transformToArray(tree.getNodes());
            tree.hideNodes(allTreeNodes);
            var showNodes = tree.getNodesByParamFuzzy('name', $.trim(keyword), null);
            var showNodes2 = tree.getNodesByParamFuzzy('initial', $.trim(keyword), null);
            showNodes = showNodes.concat(showNodes2);
            var parentNodes = [];
            var getParentNodes = function (curNode) {
                var pNodes = [];
                if (curNode.getParentNode()) {
                    pNodes.push(curNode.getParentNode());
                    return pNodes.concat(getParentNodes(curNode.getParentNode()));
                } else {
                    return pNodes;
                }
            };
            for (var i = 0; i < showNodes.length; i++) {
                parentNodes = parentNodes.concat(getParentNodes(showNodes[i]));
            }
            showNodes = showNodes.concat(parentNodes);
            tree.showNodes(showNodes);
            // 搜索到的匹配的节点可能不是根节点，所以搜索结果展开，因为用户可能非常多，所以显示全部结果时仅展开第一层
            // 由于zTree收起展开使用了jQuery的动画，但没有考虑到异步的问题，没有提供回调，所以会出现问题
            tree.setting.view.expandSpeed = '';
            if ($.trim(keyword)) {
                tree.expandAll(true);
            } else {
                if (!notExpandFirstLevel) {
                    var rootNodes = tree.getNodes();
                    $.each(allTreeNodes, function (index) {
                        tree.expandNode(allTreeNodes[index], rootNodes.indexOf(allTreeNodes[index]) > -1);
                    });
                } else {
                    tree.expandAll(false);
                }
                // var checkedNodes = tree.getCheckedNodes(true);
                // if (checkedNodes.length > 0) {
                //     for (var nI = 0; nI < checkedNodes.length; nI++) {
                //         $.expandCheckedNode(tree, checkedNodes[nI]);
                //     }
                // }
            }
            // 解决方案：先关闭动画，收缩完成后再恢复
            tree.setting.view.expandSpeed = 'fast';
        },
        /**
         * 展开选中的节点
         */
        expandCheckedNode: function (tree, node) {
            var pNode = node.getParentNode();
            if (pNode) {
                $.expandCheckedNode(tree, pNode);
                tree.expandNode(pNode, true);
            }
        },
        /**
         * 初始化带搜索框的 ztree
         */
        zTreeInitWidthSearch: function (dom, setting, datas) {
            return (function (zDom, opt, result) {
                var tree = $.fn.zTree.init(zDom, opt, result);
                var treeSearchInput = $('<input class="ztree-search-input">');
                zDom.prepend(treeSearchInput);
                treeSearchInput.on('keyup', function () {
                    zDom.find('.ztree-search-noresult').remove();
                    $.searchTree(tree.setting.treeId, this.value);
                    var showNodes = tree.getNodesByParam('isHidden', false);
                    if (showNodes.length <= 0) {
                        var noResultDom = $('<li class="ztree-search-noresult">没有结果匹配 <span>' + this.value + '</span></li>');
                        zDom.append(noResultDom);
                    }
                    treeSearchInput.focus();
                });
                return tree;
            })(dom, setting, datas);
        },
        imgCroppingInit: function (dom, opt) {
            var defaultOpt = {
                labelName: '上传图标',
                defaultImg: 'common-resources/js/thirdparty/ImgCropping/template/default.jpg',
                aspectRatio: 1 / 1, // 默认比例
                preview: '.previewImg', // 预览视图
                guides: true, // 裁剪框的虚线(九宫格)
                autoCropArea: 0.5, // 0-1之间的数值，定义自动剪裁区域的大小，默认0.8
                //movable: false, // 是否允许移动图片
                dragCrop: true, // 是否允许移除当前的剪裁框，并通过拖动来新建一个剪裁框区域
                movable: true, // 是否允许移动剪裁框
                resizable: true, // 是否允许改变裁剪框的大小
                zoomable: false, // 是否允许缩放图片大小
                mouseWheelZoom: false, // 是否允许通过鼠标滚轮来缩放图片
                touchDragZoom: true, // 是否允许通过触摸移动来缩放图片
                rotatable: true, // 是否允许旋转图片
                crop: function (e) {
                    // 输出结果数据裁剪图像。
                }
            };
            defaultOpt = $.extend(true, defaultOpt, opt);
            var flagX = true;
            var $html = $($.getTemPlates('common-resources/js/thirdparty/ImgCropping/template/initTpl.html').render(defaultOpt));
            $html
                .off()
                .on('click', '#imagePreview', function () {
                    $html.find('#imageFile').click();
                })
                .on('change', '#imageFile', function (event) {
                    var file = $(event.target)[0];
                    //文件为空，返回
                    if (!file.files || !file.files[0]) {
                        return;
                    }
                    setSize();
                    $html.find('.tailoring-container').toggle();
                    var reader = new FileReader();
                    reader.onload = function (evt) {
                        var replaceSrc = evt.target.result;
                        // 更换cropper的图片
                        $html.find('#tailoringImg').cropper('replace', replaceSrc, false); // 默认false，适应高度，不失真
                    };
                    reader.readAsDataURL(file.files[0]);
                })
                .on('click', '#cropper-rotate-btn', function () {
                    // 旋转
                    $html.find('#tailoringImg').cropper('rotate', 45);
                })
                .on('click', '#cropper-reset-btn', function () {
                    // 复位
                    $html.find('#tailoringImg').cropper('reset');
                })
                .on('click', '#cropper-scaleX-btn', function () {
                    //换向
                    if (flagX) {
                        $html.find('#tailoringImg').cropper('scaleX', -1);
                        flagX = false;
                    } else {
                        $html.find('#tailoringImg').cropper('scaleX', 1);
                        flagX = true;
                    }
                    flagX != flagX;
                })
                .on('click', '#sureCut', function () {
                    // 确定按钮点击事件
                    if ($html.find('#tailoringImg').attr('src') == null) {
                        return false;
                    } else {
                        var cas = $html.find('#tailoringImg').cropper('getCroppedCanvas', {
                            width: 128,
                            height: 128
                        }); // 获取被裁剪后的canvas
                        var imgBase64 = cas.toDataURL('image/png'); // 转换为base64
                        $html.find('#imagePreview').prop('src', imgBase64); // 显示图片
                        $html.find('.tailoring-container').toggle(); // 关闭裁剪框
                    }
                })
                .on('click', '#black-cloth,#close-tailoring', function () {
                    $html.find('.tailoring-container').toggle(); // 关闭裁剪框
                });
            $html.find('#tailoringImg').cropper(defaultOpt);
            dom.html($html);

            function setSize() {
                var win_height = $(window).height();
                var win_width = $(window).width();
                if (win_width <= 768) {
                    $html.find('.tailoring-content').css({
                        top: (win_height - $html.find('.tailoring-content').outerHeight()) / 2,
                        left: 0
                    });
                } else {
                    $html.find('.tailoring-content').css({
                        top: (win_height - $html.find('.tailoring-content').outerHeight()) / 2,
                        left: (win_width - $html.find('.tailoring-content').outerWidth()) / 2
                    });
                }
            }
        }
    });
})();
