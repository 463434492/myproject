var jUI_tooltip = {
  init: function() {
    this._initJqueryToolTips();
  },
  _initJqueryToolTips: function() {
    $(document)
      .on('mouseover', '[data-toggle="tooltips"]', function(event) {
        var dataPlacement = $(this).attr('data-placement') ? $(this).attr('data-placement') : 'bottom';
        var position = {
          my: 'center top',
          at: 'center bottom'
        };
        var offset = 6;
        if (dataPlacement) {
          if (dataPlacement === 'top') {
            position = {
              my: 'center bottom',
              at: 'center top'
            };
            offset = -6;
          } else if (dataPlacement === 'left') {
            position = {
              my: 'right center',
              at: 'left center'
            };
            offset = -6;
          } else if (dataPlacement === 'right') {
            position = {
              my: 'left center',
              at: 'right center'
            };
          } else {
            dataPlacement = 'bottom';
          }
        }
        $(this).tooltip({
          show: null,
          hide: {
            effect: 'hide'
          },
          position: position,
          open: function(event, ui) {
            if (dataPlacement === 'top' || dataPlacement === 'bottom') {
              ui.tooltip.animate(
                {
                  top: ui.tooltip.position().top + offset
                },
                'fast'
              );
            } else {
              ui.tooltip.animate(
                {
                  left: ui.tooltip.position().left + offset
                },
                'fast'
              );
            }
          },
          items: '[data-title]',
          content: function() {
            return $(this).attr('data-title');
          }
        });
        $(this).tooltip('open');
      })
      .on('mouseleave', '[data-toggle="tooltips"]', function() {
        $(this).tooltip('destroy');
      });
  }
};

$(function() {
  jUI_tooltip.init();
});
