package com.yaozj.menu;

import com.github.promeg.pinyinhelper.Pinyin;
import com.github.promeg.tinypinyin.lexicons.java.cncity.CnCityDict;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletComponentScan;

@SpringBootApplication
@MapperScan("com.yaozj.menu.mapper")
@ServletComponentScan
public class MenuApplication implements CommandLineRunner {

  public static void main(String[] args) {
    SpringApplication.run(MenuApplication.class, args);
  }

  @Override
  public void run(String... args) throws Exception {
    // 添加中文城市词典
    Pinyin.init(Pinyin.newConfig().with(CnCityDict.getInstance()));
  }
}
