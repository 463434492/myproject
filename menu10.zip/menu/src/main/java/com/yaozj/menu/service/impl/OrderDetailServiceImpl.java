package com.yaozj.menu.service.impl;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.yaozj.menu.common.bean.JsonResponse;
import com.yaozj.menu.common.enums.OrderTypeEnum;
import com.yaozj.menu.common.util.excel.ExcelBaseInfo;
import com.yaozj.menu.common.util.excel.ExcelWriter;
import com.yaozj.menu.domain.OrderDetail;
import com.yaozj.menu.domain.Orders;
import com.yaozj.menu.domain.Unit;
import com.yaozj.menu.domain.vo.OrderDetailSubmitVo;
import com.yaozj.menu.domain.vo.OrderDetailVo;
import com.yaozj.menu.service.OrderDetailService;
import com.yaozj.menu.storage.OrderDetailStorage;
import com.yaozj.menu.storage.OrderStorage;
import com.yaozj.menu.storage.UnitStorage;
import org.apache.commons.collections.CollectionUtils;
import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.swing.filechooser.FileSystemView;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/** author: yaozj date: Created in 2020/9/13 14:07 description: */
@Service
public class OrderDetailServiceImpl implements OrderDetailService {

  private static final Logger LOGGER = LoggerFactory.getLogger(OrderDetailServiceImpl.class);

  @Autowired private OrderDetailStorage orderDetailStorage;
  @Autowired private OrderStorage orderStorage;
  @Autowired private UnitStorage unitService;

  @Override
  @Transactional
  public BigDecimal saveOrderDetail(OrderDetailSubmitVo orderDetailSubmitVo) {
    // 数据库中查询出原来订单的数据
    List<OrderDetailVo> orderDetailInDb =
        orderDetailStorage.getOrderDetailByParam(
            orderDetailSubmitVo.getOrderNo(), OrderTypeEnum.ORDER.getType());
    List<OrderDetailVo> supplementDetailInDb =
        orderDetailStorage.getOrderDetailByParam(
            orderDetailSubmitVo.getOrderNo(), OrderTypeEnum.SUPPLEMENT.getType());

    Orders orders = new Orders();
    orders.setOrderNo(orderDetailSubmitVo.getOrderNo());
    orders.setTotal(new BigDecimal(0));

    // 比较出的结果
    ArrayListMultimap<String, OrderDetail> orderMultimap =
        screenData(
            orderDetailInDb,
            orderDetailSubmitVo.getOrderData(),
            OrderTypeEnum.ORDER.getType(),
            orders);
    ArrayListMultimap<String, OrderDetail> supplementMultimap =
        screenData(
            supplementDetailInDb,
            orderDetailSubmitVo.getSupplementData(),
            OrderTypeEnum.SUPPLEMENT.getType(),
            orders);

    // 更新订单的总计
    orderStorage.updateOrderByOrderNo(orders);

    // 将结果合并
    orderMultimap.putAll(supplementMultimap);
    // 分别处理
    // 删除
    List<OrderDetail> delete = orderMultimap.get("delete");
    orderDetailStorage.batchDel(delete);
    // 修改
    List<OrderDetail> update = orderMultimap.get("update");
    orderDetailStorage.batchUpdate(update);
    // 新增
    List<OrderDetail> insert = orderMultimap.get("insert");
    orderDetailStorage.batchInsert(insert);
    return orders.getTotal();
  }

  private ArrayListMultimap<String, OrderDetail> screenData(
      List<OrderDetailVo> orderDetailInDb, List<OrderDetailVo> datas, int type, Orders orders) {
    // 封装数据库中的OrderDetail，用于比对
    HashMap<String, OrderDetail> orderDetailMapInDB = Maps.newHashMap();
    if (CollectionUtils.isNotEmpty(orderDetailInDb)) {
      for (OrderDetail orderDetail : orderDetailInDb) {
        // 键：CommodityId_Type
        orderDetailMapInDB.put(
            orderDetail.getCommodityId() + "_" + orderDetail.getType(), orderDetail);
      }
    }
    // 返回结果
    ArrayListMultimap<String, OrderDetail> result = ArrayListMultimap.create();
    // 添加的数据不为空的情况下进行数据处理
    if (CollectionUtils.isNotEmpty(datas)) {
      for (OrderDetailVo orderDetailVo : datas) {
        // 设置类型
        orderDetailVo.setType(type);
        orderDetailVo.setOrderNo(orders.getOrderNo());
        String key = orderDetailVo.getCommodityId() + "_" + type;
        // 在数据库中有，两种情况：1，更新，2不变
        if (orderDetailMapInDB.containsKey(key)) {
          // 获取一个就删除一个，剩余的就是需要删除的
          OrderDetail orderDetailInDB = orderDetailMapInDB.remove(key);
          if (orderDetailInDB.getPrice().compareTo(orderDetailVo.getPrice()) != 0
              || orderDetailInDB.getWeight().compareTo(orderDetailVo.getWeight()) != 0
              || !orderDetailInDB.getUnitId().equals(orderDetailVo.getUnitId())) {
            result.put("update", orderDetailVo);
          }
        } else {
          // 数据库中没有，说明要添加
          result.put("insert", orderDetailVo);
        }
        // 计算小计
        BigDecimal price = orderDetailVo.getPrice();
        BigDecimal weight = orderDetailVo.getWeight();
        BigDecimal subtotal = price.multiply(weight).setScale(2, BigDecimal.ROUND_HALF_UP);
        orderDetailVo.setSubtotal(subtotal);
        // 和入总计当中
        BigDecimal total = orders.getTotal();
        total = total.add(subtotal);
        orders.setTotal(total);
      }
      // 遍历完毕，数据库map中有剩余的说明要删除
      result.putAll("delete", orderDetailMapInDB.values());
    }
    return result;
  }

  @Override
  public JsonResponse<Boolean> exportOrderDetail(String orderNo, int exportType) {
    // 单位名称
    HashMap<Integer, String> unitMap = Maps.newHashMap();
    List<Unit> units = unitService.getUnits();
    for (Unit unit : units) {
      unitMap.put(unit.getId(), unit.getName());
    }

    Orders orders = orderStorage.getOrderByOrderNo(orderNo);

    // 数据库中查询出原来订单的数据
    List<OrderDetailVo> orderDetailInDb =
        orderDetailStorage.getOrderDetailByParam(orderNo, OrderTypeEnum.ORDER.getType());
    List<OrderDetailVo> supplementDetailInDb =
        orderDetailStorage.getOrderDetailByParam(orderNo, OrderTypeEnum.SUPPLEMENT.getType());

    OrderDetailVo order = new OrderDetailVo();
    order.setCommodityName("订单:");
    OrderDetailVo supplement = new OrderDetailVo();
    supplement.setCommodityName("补单:");

    ArrayList<OrderDetailVo> exportData = Lists.newArrayList();
    exportData.add(order);
    exportData.addAll(orderDetailInDb);
    exportData.add(supplement);
    exportData.addAll(supplementDetailInDb);

    ExcelBaseInfo excelInfo = null;

    FileSystemView fsv = FileSystemView.getFileSystemView();
    StringBuilder path = new StringBuilder(fsv.getHomeDirectory().getPath());
    // 0发货单，1结算单
    if (exportType == 0) {
      path.append("\\订单\\")
          .append(orders.getName())
          .append("-")
          .append(orders.getLunarCalendar())
          .append("-")
          .append("发货单.xlsx");
      excelInfo = ExcelBaseInfo.getDeliverExcelInfo();
    } else {
      path.append("\\订单\\")
          .append(orders.getName())
          .append("-")
          .append(orders.getLunarCalendar())
          .append("-")
          .append("结算单.xlsx");
      excelInfo = ExcelBaseInfo.getSettlementExcelInfo();

      OrderDetailVo total = new OrderDetailVo();
      total.setCommodityName("合计:");
      total.setWeight(orders.getTotal());
      exportData.add(total);
    }
    FileOutputStream fout = null;
    try {
      File file = new File(path.toString());
      if (file.exists()) {
        if (file.renameTo(file)) {
          file.delete();
          file = new File(path.toString());
        } else {
          return new JsonResponse<>(false, false, "文件正在被其他程序使用，请先将其关闭！");
        }
      }
      fout = new FileOutputStream(file);
      ExcelWriter excelWriter = new ExcelWriter(excelInfo, unitMap);
      Workbook workbook = excelWriter.exportData(exportData, orders);
      workbook.write(fout);
    } catch (Exception e) {
      LOGGER.error("导出excel报错", e);
    } finally {
      if (fout != null) {
        try {
          fout.close();
        } catch (IOException e) {
          LOGGER.error("关闭输出流报错", e);
        }
      }
    }

    return new JsonResponse<>(true, true, "导出excel成功！");
  }
}
