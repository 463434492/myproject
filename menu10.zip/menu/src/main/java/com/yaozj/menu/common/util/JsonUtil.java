package com.yaozj.menu.common.util;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * Jackson工具类 优势： 数据量高于百万的时候，速度和FastJson相差极小 API和注解支持最完善，可定制性最强 支持的数据源最广泛（字符串，对象，文件、流、URL）
 *
 * @author duanxinyuan 2018/6/28 23:24
 */
public class JsonUtil {
  private static final Logger LOGGER = LoggerFactory.getLogger(JsonUtil.class);
  private static final ObjectMapper MAPPER = new ObjectMapper();

  static {
    MAPPER
        .disable(SerializationFeature.FAIL_ON_EMPTY_BEANS)
        .disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)
        .enable(MapperFeature.PROPAGATE_TRANSIENT_MARKER)
        .setSerializationInclusion(JsonInclude.Include.ALWAYS);
  }

  /**
   * 把对象转为json字符串
   *
   * @param value 被转化的对象
   * @return 转化的json字符串
   */
  public static String toJson(Object value) {
    String result = null;
    try {
      result = MAPPER.writeValueAsString(value);
    } catch (Exception e) {
      LOGGER.error("JsonUtil.toJson error" + value, e);
    }
    return result;
  }

  /**
   * 把json字符串转为对象
   *
   * @param content 被转化的json字符串
   * @param valueType 转化的对象class类型
   * @param <T> 泛型
   * @return 转化的对象
   */
  public static <T> T fromJson(String content, Class<T> valueType) {
    T result = null;
    try {
      result = MAPPER.readValue(content, valueType);
    } catch (Exception e) {
      LOGGER.error("JsonUtil.fromJson error" + content, e);
    }
    return result;
  }

  /**
   * 把json字符串转为对象集合
   *
   * @param content 被转化的json字符串
   * @param valueType 转化的对象class类型
   * @param <T> 泛型
   * @return 转化的对象集合
   */
  public static <T> T fromJsonToList(String content, Class<T> valueType) {
    T result = null;
    try {
      result =
          MAPPER.readValue(
              content, MAPPER.getTypeFactory().constructParametricType(List.class, valueType));
    } catch (Exception e) {
      LOGGER.error("JsonUtil.fromJsonToList error" + content, e);
    }
    return result;
  }
}
