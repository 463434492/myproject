package com.yaozj.menu.common.bean;

public class JsonResponse<T> {

  private boolean success = true;

  private T result;

  private String messages;

  private String errCode;

  public JsonResponse() {}

  public JsonResponse(boolean success) {
    this.success = success;
  }

  public JsonResponse(boolean success, T result) {
    this.success = success;
    this.result = result;
  }

  public JsonResponse(boolean success, String messages) {
    this.success = success;
    this.messages = messages;
  }

  public JsonResponse(boolean success, T result, String messages) {
    this.success = success;
    this.result = result;
    this.messages = messages;
  }

  public JsonResponse(boolean success, T result, String messages, String errCode) {
    this.success = success;
    this.result = result;
    this.messages = messages;
    this.errCode = errCode;
  }

  public boolean isSuccess() {
    return success;
  }

  public void setSuccess(boolean success) {
    this.success = success;
  }

  public T getResult() {
    return result;
  }

  public void setResult(T result) {
    this.result = result;
  }

  public String getMessages() {
    return messages;
  }

  public void setMessages(String messages) {
    this.messages = messages;
  }

  public String getErrCode() {
    return errCode;
  }

  public void setErrCode(String errCode) {
    this.errCode = errCode;
  }

  public static <T> JsonResponse<T> success(T result) {
    return new JsonResponse<T>(true, result);
  }

  public static <T> JsonResponse<T> success(T result, String messages) {
    return new JsonResponse<T>(true, result, messages);
  }

  public static JsonResponse<Void> fail(String errcode, String messages) {
    return new JsonResponse<Void>(false, null, messages, errcode);
  }
}
