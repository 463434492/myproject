package com.yaozj.menu.service;

import com.yaozj.menu.common.bean.TreeNode;
import com.yaozj.menu.domain.Commodity;

public interface CommodityService {
  TreeNode saveCommodity(Commodity commodity);

  boolean delCommodity(int id);

  TreeNode editCommodity(Commodity commodity);
}
