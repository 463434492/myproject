package com.yaozj.menu.domain.vo;

import com.yaozj.menu.common.bean.TreeNode;

import java.util.List;

/** author: yaozj date: Created in 2020/9/9 19:29 description: */
public class OrderPageVo {
  private List<TreeNode> orderTree;
  private List<TreeNode> supplementTree;
  private List<OrderDetailVo> orderTable;
  private List<OrderDetailVo> supplementTable;

  public List<TreeNode> getOrderTree() {
    return orderTree;
  }

  public void setOrderTree(List<TreeNode> orderTree) {
    this.orderTree = orderTree;
  }

  public List<TreeNode> getSupplementTree() {
    return supplementTree;
  }

  public void setSupplementTree(List<TreeNode> supplementTree) {
    this.supplementTree = supplementTree;
  }

  public List<OrderDetailVo> getOrderTable() {
    return orderTable;
  }

  public void setOrderTable(List<OrderDetailVo> orderTable) {
    this.orderTable = orderTable;
  }

  public List<OrderDetailVo> getSupplementTable() {
    return supplementTable;
  }

  public void setSupplementTable(List<OrderDetailVo> supplementTable) {
    this.supplementTable = supplementTable;
  }
}
