package com.yaozj.menu.storage;

import com.yaozj.menu.domain.Commodity;
import com.yaozj.menu.domain.CommodityExample;
import com.yaozj.menu.mapper.CommodityMapper;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/** author: yaozj date: Created in 2020/9/9 7:07 description: */
@Service
public class CommodityStorage {
  // 正常
  public static final int COMMODITY_STATUS_NORMAL = 1;
  // 删除
  public static final int COMMODITY_STATUS_DEL = 0;

  @Autowired private CommodityMapper commodityMapper;

  public List<Commodity> getAllCommodity() {
    CommodityExample example = new CommodityExample();
    example.createCriteria().andStatusEqualTo(COMMODITY_STATUS_NORMAL);
    example.setOrderByClause("name asc, initial asc");
    List<Commodity> commodities = commodityMapper.selectByExample(example);
    return commodities;
  }

  public boolean saveCommodity(Commodity commodity) {
    int rowNum = 0;
    if (commodity != null) {
      rowNum = commodityMapper.insertSelective(commodity);
    }
    return rowNum > 0;
  }

  public Commodity getLastCommodityByParam(String name) {
    if (StringUtils.isNotBlank(name)) {
      return commodityMapper.getLastCommodityByParam(name);
    }
    return null;
  }

  public boolean delCommodity(int id) {
    Commodity commodity = new Commodity();
    commodity.setId(id);
    commodity.setStatus(COMMODITY_STATUS_DEL);
    return commodityMapper.updateByPrimaryKeySelective(commodity) > 0;
  }

  public boolean updateCommodity(Commodity commodity) {
    if (commodity != null) {
      return commodityMapper.updateByPrimaryKeySelective(commodity) > 0;
    }
    return false;
  }
}
