package com.yaozj.menu.mapper;

import com.yaozj.menu.domain.Orders;
import com.yaozj.menu.domain.OrdersExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface OrdersMapper {
  long countByExample(OrdersExample example);

  int deleteByExample(OrdersExample example);

  int deleteByPrimaryKey(Integer id);

  int insert(Orders record);

  int insertSelective(Orders record);

  List<Orders> selectByExample(OrdersExample example);

  Orders selectByPrimaryKey(Integer id);

  int updateByExampleSelective(
      @Param("record") Orders record, @Param("example") OrdersExample example);

  int updateByExample(@Param("record") Orders record, @Param("example") OrdersExample example);

  int updateByPrimaryKeySelective(Orders record);

  int updateByPrimaryKey(Orders record);

  List<Orders> getOrderList(Map<String, Object> param);

  long getOrderListCount(Map<String, Object> param);
}
