package com.yaozj.menu.service.impl;

import com.yaozj.menu.domain.Unit;
import com.yaozj.menu.service.UnitService;
import com.yaozj.menu.storage.UnitStorage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/** author: yaozj date: Created in 2020/9/12 16:49 description: */
@Service
public class UnitServiceImpl implements UnitService {
  @Autowired private UnitStorage unitService;

  @Override
  public List<Unit> getUnits(String orderNo) {
    return unitService.getUnits();
  }
}
