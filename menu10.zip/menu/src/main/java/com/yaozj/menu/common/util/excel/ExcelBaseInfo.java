package com.yaozj.menu.common.util.excel;

import java.util.ArrayList;
import java.util.List;

/** author: yaozj date: Created in 2020/9/14 23:43 description: */
public class ExcelBaseInfo {
  private List<String> cellHeads; // 列头

  // 每页商品的列
  private int pageColNum;
  // 每页商品的列
  private int commodityColNum;
  // 第一页开始行
  private int startRowIdx;
  // 每页显示的行
  private int pageLenth;
  // 标题
  private String pageTitle;

  public static ExcelBaseInfo getSettlementExcelInfo() {
    ExcelBaseInfo excelBaseInfo = new ExcelBaseInfo();
    List cellHeads = new ArrayList<>();
    cellHeads.add("品名");
    cellHeads.add("数量");
    cellHeads.add("价格(元)");
    cellHeads.add("小计(元)");
    cellHeads.add("");
    cellHeads.add("品名");
    cellHeads.add("数量");
    cellHeads.add("价格(元)");
    cellHeads.add("小计(元)");
    excelBaseInfo.setCellHeads(cellHeads);
    excelBaseInfo.setCommodityColNum(2);
    excelBaseInfo.setPageColNum(9);
    excelBaseInfo.setStartRowIdx(8);
    excelBaseInfo.setPageLenth(41);
    excelBaseInfo.setPageTitle("结算单");
    return excelBaseInfo;
  }

  public static ExcelBaseInfo getDeliverExcelInfo() {
    ExcelBaseInfo excelBaseInfo = new ExcelBaseInfo();
    List cellHeads = new ArrayList<>();
    cellHeads.add("品名");
    cellHeads.add("数量");
    cellHeads.add("");
    cellHeads.add("品名");
    cellHeads.add("数量");
    cellHeads.add("");
    cellHeads.add("品名");
    cellHeads.add("数量");
    excelBaseInfo.setCellHeads(cellHeads);
    excelBaseInfo.setCommodityColNum(3);
    excelBaseInfo.setPageColNum(8);
    excelBaseInfo.setStartRowIdx(8);
    excelBaseInfo.setPageLenth(41);
    excelBaseInfo.setPageTitle("发货单");
    return excelBaseInfo;
  }

  public List<String> getCellHeads() {
    return cellHeads;
  }

  public void setCellHeads(List<String> cellHeads) {
    this.cellHeads = cellHeads;
  }

  public int getPageColNum() {
    return pageColNum;
  }

  public void setPageColNum(int pageColNum) {
    this.pageColNum = pageColNum;
  }

  public int getCommodityColNum() {
    return commodityColNum;
  }

  public void setCommodityColNum(int commodityColNum) {
    this.commodityColNum = commodityColNum;
  }

  public int getStartRowIdx() {
    return startRowIdx;
  }

  public void setStartRowIdx(int startRowIdx) {
    this.startRowIdx = startRowIdx;
  }

  public int getPageLenth() {
    return pageLenth;
  }

  public void setPageLenth(int pageLenth) {
    this.pageLenth = pageLenth;
  }

  public String getPageTitle() {
    return pageTitle;
  }

  public void setPageTitle(String pageTitle) {
    this.pageTitle = pageTitle;
  }
}
