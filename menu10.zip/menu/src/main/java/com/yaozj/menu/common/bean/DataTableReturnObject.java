package com.yaozj.menu.common.bean;

import java.io.Serializable;
import java.util.List;

public class DataTableReturnObject implements Serializable {

  private static final long serialVersionUID = -7930023625978909190L;

  private long iTotalRecords;
  private long iTotalDisplayRecords;
  private String sEcho;
  private List aaData;

  public DataTableReturnObject() {
    super();
  }

  public DataTableReturnObject(
      long iTotalRecords, long iTotalDisplayRecords, String sEcho, List aaData) {
    super();
    this.iTotalRecords = iTotalRecords;
    this.iTotalDisplayRecords = iTotalDisplayRecords;
    this.sEcho = sEcho;
    this.aaData = aaData;
  }

  public long getiTotalRecords() {
    return iTotalRecords;
  }

  public void setiTotalRecords(long iTotalRecords) {
    this.iTotalRecords = iTotalRecords;
  }

  public long getiTotalDisplayRecords() {
    return iTotalDisplayRecords;
  }

  public void setiTotalDisplayRecords(long iTotalDisplayRecords) {
    this.iTotalDisplayRecords = iTotalDisplayRecords;
  }

  public String getsEcho() {
    return sEcho;
  }

  public void setsEcho(String sEcho) {
    this.sEcho = sEcho;
  }

  public List getAaData() {
    return aaData;
  }

  public void setAaData(List aaData) {
    this.aaData = aaData;
  }
}
