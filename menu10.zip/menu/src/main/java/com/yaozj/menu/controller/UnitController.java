package com.yaozj.menu.controller;

import com.yaozj.menu.common.bean.JsonResponse;
import com.yaozj.menu.domain.Unit;
import com.yaozj.menu.service.UnitService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/** author: yaozj date: Created in 2020/9/10 19:50 description: */
@RestController
@RequestMapping("/unit")
public class UnitController {

  private static final Logger LOGGER = LoggerFactory.getLogger(UnitController.class);

  @Autowired private UnitService unitService;

  @RequestMapping("/getUnits")
  public JsonResponse<List<Unit>> getUnits(String orderNo) {
    List<Unit> units = unitService.getUnits(orderNo);
    return new JsonResponse<>(Boolean.TRUE, units, "获取单位名称成功");
  }
}
