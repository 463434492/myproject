package com.yaozj.menu.domain.vo;

import java.util.List;

/** author: yaozj date: Created in 2020/9/13 13:16 description: */
public class OrderDetailSubmitVo {
  private String orderNo;

  private List<OrderDetailVo> orderData;

  private List<OrderDetailVo> supplementData;

  public String getOrderNo() {
    return orderNo;
  }

  public void setOrderNo(String orderNo) {
    this.orderNo = orderNo;
  }

  public List<OrderDetailVo> getOrderData() {
    return orderData;
  }

  public void setOrderData(List<OrderDetailVo> orderData) {
    this.orderData = orderData;
  }

  public List<OrderDetailVo> getSupplementData() {
    return supplementData;
  }

  public void setSupplementData(List<OrderDetailVo> supplementData) {
    this.supplementData = supplementData;
  }
}
