package com.yaozj.menu.storage;

import com.yaozj.menu.domain.Unit;
import com.yaozj.menu.domain.UnitExample;
import com.yaozj.menu.mapper.UnitMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/** author: yaozj date: Created in 2020/9/10 19:48 description: */
@Service
public class UnitStorage {
  @Autowired private UnitMapper unitMapper;

  public List<Unit> getUnits() {
    return unitMapper.selectByExample(new UnitExample());
  }
}
