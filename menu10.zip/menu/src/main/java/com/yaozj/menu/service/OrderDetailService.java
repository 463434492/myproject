package com.yaozj.menu.service;

import com.yaozj.menu.common.bean.JsonResponse;
import com.yaozj.menu.domain.vo.OrderDetailSubmitVo;

import java.math.BigDecimal;

/** author: yaozj date: Created in 2020/9/9 19:34 description: */
public interface OrderDetailService {
  BigDecimal saveOrderDetail(OrderDetailSubmitVo orderDetailSubmitVo);

  JsonResponse<Boolean> exportOrderDetail(String orderNo, int exportType);
}
