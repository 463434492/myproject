package com.yaozj.menu.service.impl;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.yaozj.menu.common.bean.DataTableReturnObject;
import com.yaozj.menu.common.bean.TreeNode;
import com.yaozj.menu.common.enums.OrderTypeEnum;
import com.yaozj.menu.common.util.OrderGen;
import com.yaozj.menu.domain.Commodity;
import com.yaozj.menu.domain.Orders;
import com.yaozj.menu.domain.vo.OrderDetailVo;
import com.yaozj.menu.domain.vo.OrderPageVo;
import com.yaozj.menu.domain.vo.OrdersVo;
import com.yaozj.menu.service.OrderService;
import com.yaozj.menu.storage.CommodityStorage;
import com.yaozj.menu.storage.OrderDetailStorage;
import com.yaozj.menu.storage.OrderStorage;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.time.Instant;
import java.util.*;

/** author: yaozj date: Created in 2020/9/9 19:35 description: */
@Service
public class OrderServiceImpl implements OrderService {
  @Autowired private CommodityStorage commodityStorage;
  @Autowired private OrderDetailStorage orderDetailStorage;
  @Autowired private OrderStorage orderStorage;

  @Override
  public OrderPageVo getOrderPageInfo(String orderNo) {
    // 查询全部商品
    List<Commodity> allCommodity = commodityStorage.getAllCommodity();
    List<OrderDetailVo> orderDetailList =
        orderDetailStorage.getOrderDetailByParam(orderNo, OrderTypeEnum.ORDER.getType());
    List<OrderDetailVo> supplementDetailList =
        orderDetailStorage.getOrderDetailByParam(orderNo, OrderTypeEnum.SUPPLEMENT.getType());
    // 封装返回对象
    OrderPageVo orderPageVo = new OrderPageVo();
    // 将订单勾选上
    selectCommodity(orderPageVo, allCommodity, orderDetailList, OrderTypeEnum.ORDER);
    // 将补单勾选上
    selectCommodity(orderPageVo, allCommodity, supplementDetailList, OrderTypeEnum.SUPPLEMENT);
    orderPageVo.setOrderTable(orderDetailList);
    orderPageVo.setSupplementTable(supplementDetailList);
    return orderPageVo;
  }

  /**
   * 勾选订单/补单中的商品
   *
   * @param orderPageVo 返回的page详情bean
   * @param allCommodity 全部的商品
   * @param needSelectCommodity 需要勾选的商品
   * @param type 类型
   */
  private void selectCommodity(
      OrderPageVo orderPageVo,
      List<Commodity> allCommodity,
      List<OrderDetailVo> needSelectCommodity,
      OrderTypeEnum type) {

    // 将需要勾选的id放入set中
    Set<Integer> setForSelect = Sets.newHashSet();
    if (CollectionUtils.isNotEmpty(needSelectCommodity)) {
      for (OrderDetailVo orderDetailVo : needSelectCommodity) {
        setForSelect.add(orderDetailVo.getCommodityId());
      }
    }

    TreeMap<String, TreeNode> parentNodeMap = Maps.newTreeMap();
    ArrayListMultimap<String, TreeNode> childNodeMap = ArrayListMultimap.create();
    for (Commodity commodity : allCommodity) {
      String initial = commodity.getInitial().substring(0, 1);
      // 添加父节点
      if (!parentNodeMap.containsKey(initial)) {
        TreeNode parentNode = new TreeNode(initial, "0", initial);
        parentNode.setOpen(false);
        parentNode.setChkDisabled(true);
        parentNodeMap.put(initial, parentNode);
      }
      // 添加子节点
      TreeNode childNode =
          new TreeNode(commodity.getId().toString(), initial, commodity.getName(), commodity);
      childNode.setChecked(setForSelect.contains(commodity.getId()));
      childNode.setInitial(commodity.getInitial());
      childNodeMap.put(initial, childNode);
    }

    // 获取navbar，并排序
    ArrayList<String> navbar = Lists.newArrayList(parentNodeMap.keySet());
    Collections.sort(navbar);
    // 将map转成有序的list
    ArrayList<TreeNode> parentNodeList = Lists.newArrayList(parentNodeMap.values());
    for (TreeNode parentNode : parentNodeList) {
      parentNode.setChildren(childNodeMap.get(parentNode.getId()));
    }

    // 封装对象
    switch (type) {
      case ORDER:
        orderPageVo.setOrderTree(parentNodeList);
        break;
      case SUPPLEMENT:
        orderPageVo.setSupplementTree(parentNodeList);
        break;
    }
  }

  @Override
  public OrdersVo getOrderByOrderNo(String orderNo) {
    Orders orders = orderStorage.getOrderByOrderNo(orderNo);
    OrdersVo ordersVo = new OrdersVo();
    BeanUtils.copyProperties(orders, ordersVo);
    ordersVo.setSolarCalendarLong(orders.getSolarCalendar().getTime());
    return ordersVo;
  }

  @Override
  public String saveOrEditOrder(OrdersVo ordersVo) {
    ordersVo.setSolarCalendar(new Date(ordersVo.getSolarCalendarLong()));
    String orderNo = ordersVo.getOrderNo();
    if (StringUtils.isBlank(orderNo)) {
      orderNo = OrderGen.generateOrderNo();
      ordersVo.setOrderNo(orderNo);
      Instant ins = Instant.now(); // 默认使用 UTC 时区
      Date date = Date.from(ins);
      ordersVo.setCreateTime(date);
      ordersVo.setStatus(Orders.STATUS_NORMAL);
      orderStorage.saveOrder(ordersVo);
    } else {
      orderStorage.editOrder(ordersVo);
    }
    return orderNo;
  }

  /**
   * 参数:
   *
   * <p>start - 分页起始值
   *
   * <p>length - 分页每页显示条数
   *
   * <p>startTime - 开始时间
   *
   * <p>endTime - 结束时间
   *
   * @param paraMap
   * @return
   */
  @Override
  public DataTableReturnObject getOrdersList(Map<String, String> paraMap) throws ParseException {
    String start = paraMap.get("start");
    String length = paraMap.get("length");

    HashMap<String, Object> params = Maps.newHashMap();
    params.put("start", NumberUtils.toInt(start));
    params.put("length", NumberUtils.toInt(length));
    params.put("startTime", paraMap.get("startTime"));
    params.put("endTime", paraMap.get("endTime"));

    List<Orders> orderList = orderStorage.getOrderList(params);
    long count = orderStorage.getOrderListCount(params);

    DataTableReturnObject dataTableReturnObject = new DataTableReturnObject();
    dataTableReturnObject.setiTotalRecords(count);
    dataTableReturnObject.setiTotalDisplayRecords(count);
    dataTableReturnObject.setsEcho(paraMap.get("draw"));
    dataTableReturnObject.setAaData(orderList);

    return dataTableReturnObject;
  }
}
