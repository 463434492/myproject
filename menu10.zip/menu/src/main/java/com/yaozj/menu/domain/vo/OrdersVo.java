package com.yaozj.menu.domain.vo;

import com.yaozj.menu.domain.Orders;

/** author: yaozj date: Created in 2020/9/12 21:34 description: */
public class OrdersVo extends Orders {
  private Long solarCalendarLong;

  public Long getSolarCalendarLong() {
    return solarCalendarLong;
  }

  public void setSolarCalendarLong(Long solarCalendarLong) {
    this.solarCalendarLong = solarCalendarLong;
  }
}
