package com.yaozj.menu.storage;

import com.google.common.collect.Lists;
import com.yaozj.menu.domain.OrderDetail;
import com.yaozj.menu.domain.vo.OrderDetailVo;
import com.yaozj.menu.mapper.OrderDetailMapper;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/** author: yaozj date: Created in 2020/9/10 22:21 description: */
@Service
public class OrderDetailStorage {
  @Autowired private OrderDetailMapper orderDetailMapper;

  public List<OrderDetailVo> getOrderDetailByParam(String orderNo, Integer type) {
    if (StringUtils.isNotBlank(orderNo) && type != null) {
      return orderDetailMapper.getOrderDetailByParam(orderNo, type);
    } else {
      return Lists.newArrayList();
    }
  }

  public boolean batchDel(List<OrderDetail> orderDetails) {
    if (CollectionUtils.isNotEmpty(orderDetails)) {
      return orderDetailMapper.deleteByBatch(orderDetails) > 0;
    }
    return false;
  }

  public boolean batchUpdate(List<OrderDetail> orderDetails) {
    if (CollectionUtils.isNotEmpty(orderDetails)) {
      return orderDetailMapper.updateByBatch(orderDetails) > 0;
    }
    return false;
  }

  public boolean batchInsert(List<OrderDetail> orderDetails) {
    if (CollectionUtils.isNotEmpty(orderDetails)) {
      return orderDetailMapper.insertList(orderDetails) > 0;
    }
    return false;
  }
}
