package com.yaozj.menu.service.impl;

import com.yaozj.menu.common.bean.TreeNode;
import com.yaozj.menu.domain.Commodity;
import com.yaozj.menu.service.CommodityService;
import com.yaozj.menu.storage.CommodityStorage;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/** author: yaozj date: Created in 2020/9/12 13:06 description: */
@Service
public class CommodityServiceImpl implements CommodityService {
  @Autowired private CommodityStorage commodityStorage;

  @Override
  public TreeNode saveCommodity(Commodity commodity) {
    if (StringUtils.isNotBlank(commodity.getInitial())) {
      commodity.setInitial(commodity.getInitial().toUpperCase());
    }
    boolean b = commodityStorage.saveCommodity(commodity);
    if (b) {
      Commodity commodityInDb = commodityStorage.getLastCommodityByParam(commodity.getName());
      TreeNode childNode =
          new TreeNode(
              commodityInDb.getId().toString(),
              commodityInDb.getInitial().substring(0, 1),
              commodityInDb.getName(),
              commodityInDb);
      childNode.setInitial(commodityInDb.getInitial());
      return childNode;
    }
    return null;
  }

  @Override
  public boolean delCommodity(int id) {
    return commodityStorage.delCommodity(id);
  }

  @Override
  public TreeNode editCommodity(Commodity commodity) {
    if (StringUtils.isNotBlank(commodity.getInitial())) {
      commodity.setInitial(commodity.getInitial().toUpperCase());
    }
    boolean b = commodityStorage.updateCommodity(commodity);
    if (b) {
      TreeNode childNode =
          new TreeNode(
              commodity.getId().toString(),
              commodity.getInitial().substring(0, 1),
              commodity.getName(),
              commodity);
      childNode.setInitial(commodity.getInitial());
      return childNode;
    }
    return null;
  }
}
