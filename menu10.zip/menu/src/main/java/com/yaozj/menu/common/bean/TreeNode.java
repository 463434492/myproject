package com.yaozj.menu.common.bean;

import java.util.ArrayList;
import java.util.List;

public class TreeNode {

  public TreeNode() {}

  public TreeNode(String id, String name) {
    this.id = id;
    this.name = name;
  }

  public TreeNode(String id, String pId, String name) {
    this.id = id;
    this.pId = pId;
    this.name = name;
  }

  public TreeNode(String id, String pId, String name, Object data) {
    this.id = id;
    this.pId = pId;
    this.name = name;
    this.data = data;
  }

  /** 节点ID */
  private String id;

  /** 父节点ID */
  private String pId;

  /** 节点名称（zTree） */
  private String name;

  /** 节点图标 */
  private String icon;

  /** 节点图标class */
  private String iconSkin;

  /** 点击跳转的url */
  private String url;

  /** 自定义url */
  private String target;

  /** 是否显示复选框 */
  private boolean checked = false;

  /** 是否展开 */
  private boolean open = false;

  /** 是否是父节点 */
  private boolean isParent = false;

  /** 是否隐藏 */
  private boolean isHidden = false;

  /** 复选框是否变灰 */
  private boolean chkDisabled = false;

  /** 不显示复选框 */
  private boolean nocheck = false;

  /** 节点所有数据的bean */
  private Object data;

  private String initial;

  /** 子节点列表 */
  private List<TreeNode> children = new ArrayList<TreeNode>();

  public void addChild(TreeNode child) {
    children.add(child);
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getpId() {
    return pId;
  }

  public void setpId(String pId) {
    this.pId = pId;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getIcon() {
    return icon;
  }

  public void setIcon(String icon) {
    this.icon = icon;
  }

  public String getIconSkin() {
    return iconSkin;
  }

  public void setIconSkin(String iconSkin) {
    this.iconSkin = iconSkin;
  }

  public String getUrl() {
    return url;
  }

  public void setUrl(String url) {
    this.url = url;
  }

  public String getTarget() {
    return target;
  }

  public void setTarget(String target) {
    this.target = target;
  }

  public boolean isChecked() {
    return checked;
  }

  public void setChecked(boolean checked) {
    this.checked = checked;
  }

  public boolean isOpen() {
    return open;
  }

  public void setOpen(boolean open) {
    this.open = open;
  }

  public boolean isIsParent() {
    return isParent;
  }

  public void setIsParent(boolean isParent) {
    this.isParent = isParent;
  }

  public boolean isIsHidden() {
    return isHidden;
  }

  public void setIsHidden(boolean isHidden) {
    this.isHidden = isHidden;
  }

  public boolean isChkDisabled() {
    return chkDisabled;
  }

  public void setChkDisabled(boolean chkDisabled) {
    this.chkDisabled = chkDisabled;
  }

  public boolean isNocheck() {
    return nocheck;
  }

  public void setNocheck(boolean nocheck) {
    this.nocheck = nocheck;
  }

  public Object getData() {
    return data;
  }

  public void setData(Object data) {
    this.data = data;
  }

  public List<TreeNode> getChildren() {
    return children;
  }

  public void setChildren(List<TreeNode> children) {
    this.children = children;
  }

  public String getInitial() {
    return initial;
  }

  public void setInitial(String initial) {
    this.initial = initial;
  }
}
