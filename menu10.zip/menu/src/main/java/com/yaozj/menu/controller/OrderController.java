package com.yaozj.menu.controller;

import com.yaozj.menu.common.bean.DataTableReturnObject;
import com.yaozj.menu.common.bean.JsonResponse;
import com.yaozj.menu.domain.Orders;
import com.yaozj.menu.domain.vo.OrderDetailSubmitVo;
import com.yaozj.menu.domain.vo.OrderPageVo;
import com.yaozj.menu.domain.vo.OrdersVo;
import com.yaozj.menu.service.OrderDetailService;
import com.yaozj.menu.service.OrderService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.Map;

@RestController
@RequestMapping("/order")
public class OrderController {

  private static final Logger LOGGER = LoggerFactory.getLogger(OrderController.class);

  @Autowired private OrderService orderService;
  @Autowired private OrderDetailService orderDetailService;

  @RequestMapping("/pageInfo")
  public JsonResponse<OrderPageVo> getOrderPageInfo(String orderNo) {
    OrderPageVo orderPageInfo = orderService.getOrderPageInfo(orderNo);
    return new JsonResponse<>(Boolean.TRUE, orderPageInfo, "获取订单页面相关信息成功");
  }

  @RequestMapping("/getOrderByOrderNo")
  public JsonResponse<Orders> getOrderByOrderNo(String orderNo) {
    Orders order = orderService.getOrderByOrderNo(orderNo);
    return new JsonResponse<>(Boolean.TRUE, order, "获取订单信息成功");
  }

  @RequestMapping("/saveOrEditOrder")
  public JsonResponse<String> saveOrEditOrder(OrdersVo ordersVo) {
    String orderNo = orderService.saveOrEditOrder(ordersVo);
    return new JsonResponse<>(Boolean.TRUE, orderNo, "获取订单信息成功");
  }

  @RequestMapping("/saveOrderDetail")
  public JsonResponse<BigDecimal> saveOrderDetail(@RequestBody OrderDetailSubmitVo ordersVo) {
    BigDecimal total = orderDetailService.saveOrderDetail(ordersVo);
    return new JsonResponse<>(Boolean.TRUE, total, "保存订单成功");
  }

  @RequestMapping("/exportOrderDetail")
  public JsonResponse<Boolean> exportOrderDetail(String orderNo, int exportType) {
    return orderDetailService.exportOrderDetail(orderNo, exportType);
  }

  /**
   * 参数:
   *
   * <p>start - 分页起始值
   *
   * <p>length - 分页每页显示条数
   *
   * <p>startTime - 开始时间
   *
   * <p>endTIme - 结束时间
   *
   * @param paraMap
   * @return
   */
  @RequestMapping(value = "/getOrdersList", method = RequestMethod.POST)
  public JsonResponse<DataTableReturnObject> getOrdersList(
      @RequestParam Map<String, String> paraMap) throws ParseException {
    DataTableReturnObject tableData = orderService.getOrdersList(paraMap);
    return new JsonResponse<>(Boolean.TRUE, tableData, "获取订单信息成功");
  }
}
