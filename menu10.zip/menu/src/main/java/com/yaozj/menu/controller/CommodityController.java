package com.yaozj.menu.controller;

import com.github.promeg.pinyinhelper.Pinyin;
import com.google.common.collect.Maps;
import com.yaozj.menu.common.bean.JsonResponse;
import com.yaozj.menu.common.bean.TreeNode;
import com.yaozj.menu.domain.Commodity;
import com.yaozj.menu.service.CommodityService;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/** author: yaozj date: Created in 2020/9/10 19:50 description: */
@RestController
@RequestMapping("/commodity")
public class CommodityController {

  private static final Logger LOGGER = LoggerFactory.getLogger(CommodityController.class);

  @Autowired private CommodityService commodityService;

  @RequestMapping("/getPinyin")
  public JsonResponse<Map<String, String>> getUnits(String commodityName) {
    String pinyin = Pinyin.toPinyin(StringUtils.trim(commodityName), ",");
    StringBuilder initial = new StringBuilder();
    if (StringUtils.isNotBlank(pinyin)) {
      String[] split = pinyin.split(",");
      for (String str : split) {
        initial.append(str.substring(0, 1));
      }
    }
    Map<String, String> result = Maps.newHashMap();
    result.put("pinyin", pinyin.toLowerCase());
    result.put("shortPinyin", initial.toString());
    return new JsonResponse<>(Boolean.TRUE, result, "获取拼音成功");
  }

  @RequestMapping("/saveCommodity")
  public JsonResponse<TreeNode> saveCommodity(Commodity commodity) {
    TreeNode treeNode = commodityService.saveCommodity(commodity);
    return new JsonResponse<>(treeNode != null, treeNode, treeNode != null ? "操作成功" : "操作失败");
  }

  @RequestMapping("/delCommodity")
  public JsonResponse<TreeNode> delCommodity(Integer commodityId) {
    boolean result = commodityService.delCommodity(commodityId);
    return new JsonResponse<>(result, result ? "删除成功" : "删除失败");
  }

  @RequestMapping("/editCommodity")
  public JsonResponse<TreeNode> editCommodity(Commodity commodity) {
    TreeNode treeNode = commodityService.editCommodity(commodity);
    return new JsonResponse<>(treeNode != null, treeNode, treeNode != null ? "操作成功" : "操作失败");
  }
}
