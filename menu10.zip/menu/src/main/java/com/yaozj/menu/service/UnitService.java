package com.yaozj.menu.service;

import com.yaozj.menu.domain.Unit;

import java.util.List;

public interface UnitService {
  List<Unit> getUnits(String orderNo);
}
