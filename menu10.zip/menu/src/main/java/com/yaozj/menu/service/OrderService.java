package com.yaozj.menu.service;

import com.yaozj.menu.common.bean.DataTableReturnObject;
import com.yaozj.menu.domain.vo.OrderPageVo;
import com.yaozj.menu.domain.vo.OrdersVo;

import java.text.ParseException;
import java.util.Map;

/** author: yaozj date: Created in 2020/9/9 19:34 description: */
public interface OrderService {
  OrderPageVo getOrderPageInfo(String orderNo);

  OrdersVo getOrderByOrderNo(String orderNo);

  String saveOrEditOrder(OrdersVo orderNo);

  DataTableReturnObject getOrdersList(Map<String, String> paraMap) throws ParseException;
}
