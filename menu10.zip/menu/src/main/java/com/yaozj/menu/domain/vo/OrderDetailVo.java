package com.yaozj.menu.domain.vo;

import com.yaozj.menu.domain.OrderDetail;

/** author: yaozj date: Created in 2020/9/9 19:28 description: */
public class OrderDetailVo extends OrderDetail {
  private Integer no;

  private String commodityName;

  private String initial;

  public Integer getNo() {
    return no;
  }

  public void setNo(Integer no) {
    this.no = no;
  }

  public String getCommodityName() {
    return commodityName;
  }

  public void setCommodityName(String commodityName) {
    this.commodityName = commodityName;
  }

  public String getInitial() {
    return initial;
  }

  public void setInitial(String initial) {
    this.initial = initial;
  }
}
