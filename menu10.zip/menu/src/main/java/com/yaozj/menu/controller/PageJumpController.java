package com.yaozj.menu.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class PageJumpController {

  private static final Logger LOGGER = LoggerFactory.getLogger(PageJumpController.class);

  @RequestMapping("/order/addOrEditOrder")
  public String addOrEditOrder() {
    LOGGER.info("进入/order/addOrEditOrder");
    return "order/addOrEditOrder";
  }

  @RequestMapping("order/historyOrder")
  public String historyOrder() {
    LOGGER.info("进入/order/historyOrder");
    return "order/historyOrder";
  }
}
