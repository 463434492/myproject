package com.yaozj.menu.storage;

import com.yaozj.menu.domain.Orders;
import com.yaozj.menu.domain.OrdersExample;
import com.yaozj.menu.mapper.OrdersMapper;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/** author: yaozj date: Created in 2020/9/9 7:07 description: */
@Service
public class OrderStorage {
  @Autowired private OrdersMapper ordersMapper;

  public Orders getOrderByOrderNo(String orderNo) {
    OrdersExample example = new OrdersExample();
    example.createCriteria().andOrderNoEqualTo(orderNo);
    List<Orders> orders = ordersMapper.selectByExample(example);
    return CollectionUtils.isNotEmpty(orders) ? orders.get(0) : null;
  }

  public boolean saveOrder(Orders orders) {
    if (orders != null) {
      return ordersMapper.insert(orders) > 0;
    }
    return false;
  }

  public boolean editOrder(Orders orders) {
    if (orders != null) {
      return ordersMapper.updateByPrimaryKeySelective(orders) > 0;
    }
    return false;
  }

  public boolean updateOrderByOrderNo(Orders orders) {
    if (orders != null) {
      OrdersExample example = new OrdersExample();
      example.createCriteria().andOrderNoEqualTo(orders.getOrderNo());
      return ordersMapper.updateByExampleSelective(orders, example) > 0;
    }
    return false;
  }

  public List<Orders> getOrderList(Map<String, Object> param) {
    List<Orders> orderList = ordersMapper.getOrderList(param);
    return orderList;
  }

  public long getOrderListCount(Map<String, Object> param) {
    long count = ordersMapper.getOrderListCount(param);
    return count;
  }
}
