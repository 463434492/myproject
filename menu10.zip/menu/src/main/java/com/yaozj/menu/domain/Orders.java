package com.yaozj.menu.domain;

import java.math.BigDecimal;
import java.util.Date;

public class Orders {
  public static final int STATUS_NORMAL = 1;
  public static final int STATUS_DELETE = 0;

  private Integer id;

  private String orderNo;

  private String name;

  private String addr;

  private String phoneNo;

  private BigDecimal total;

  private Date createTime;

  private Date solarCalendar;

  private String lunarCalendar;

  private Integer status;

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public String getOrderNo() {
    return orderNo;
  }

  public void setOrderNo(String orderNo) {
    this.orderNo = orderNo == null ? null : orderNo.trim();
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name == null ? null : name.trim();
  }

  public String getAddr() {
    return addr;
  }

  public void setAddr(String addr) {
    this.addr = addr == null ? null : addr.trim();
  }

  public String getPhoneNo() {
    return phoneNo;
  }

  public void setPhoneNo(String phoneNo) {
    this.phoneNo = phoneNo == null ? null : phoneNo.trim();
  }

  public BigDecimal getTotal() {
    return total;
  }

  public void setTotal(BigDecimal total) {
    this.total = total;
  }

  public Date getCreateTime() {
    return createTime;
  }

  public void setCreateTime(Date createTime) {
    this.createTime = createTime;
  }

  public Date getSolarCalendar() {
    return solarCalendar;
  }

  public void setSolarCalendar(Date solarCalendar) {
    this.solarCalendar = solarCalendar;
  }

  public String getLunarCalendar() {
    return lunarCalendar;
  }

  public void setLunarCalendar(String lunarCalendar) {
    this.lunarCalendar = lunarCalendar == null ? null : lunarCalendar.trim();
  }

  public Integer getStatus() {
    return status;
  }

  public void setStatus(Integer status) {
    this.status = status;
  }
}
