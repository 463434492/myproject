package com.yaozj.menu.common.enums;

public enum OrderTypeEnum {
  ORDER(0),
  SUPPLEMENT(1);
  private int type;

  OrderTypeEnum(int type) {
    this.type = type;
  }

  public int getType() {
    return type;
  }
}
