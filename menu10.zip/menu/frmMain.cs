﻿using Chromium.Remote.Event;
using MobileZone.dto;
using MySql.Data.MySqlClient;
using NetDimension.NanUI;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using System.Reflection;
using NPOI.HSSF.Model;
using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;
using NPOI.SS.Util;
using MobileZone.service;
using MobileZone.util;

namespace MobileZone
{
    /// <summary>
    /// 主窗口，继承HtmlUIForm
    /// </summary>
    public partial class frmMain : HtmlUIForm
    {
        frmSetting settingPage = null;
        frmNewGroup newGroupForm = null;

        /// <summary>
        /// 设定启示页面，scheme是embedded就是我们在Main里注册的当前程序集资源
        /// </summary>
        public frmMain()
            : base("embedded://www/index.html")
        {
            //LogHelper.error(typeof(frmMain), "测试Log4Net日志是否写入");
            // 窗口初期化
            InitializeComponent();

            // 加载调试窗口
            GlobalObject.AddFunction("showDevTools").Execute += (sender, args) =>
            {
                ShowDevTools();
            };

            //在js中注册一个方法来打开newGroup窗口
            GlobalObject.AddFunction("showNewGroup").Execute += showNewGroup;

            GlobalObject.AddFunction("showSettingPage").Execute += (sender, args) =>
            {
                ShowSetting();
            };

            //在js中注册一个方法来刷新右边的菜单列表
            GlobalObject.AddFunction("addDishToright").Execute += addDishToright;

            //在js中注册一个方法来刷新右边的菜单列表
            GlobalObject.AddFunction("removeDishToright").Execute += removeDishToright;

            //在js中注册一个方法来计算出总价
            GlobalObject.AddFunction("moneyToCount").Execute += moneyToCount;

            //在js中注册一个方法每当价格和重量变动时发生
            GlobalObject.AddFunction("WPChange").Execute += WPChange;

            //在js中注册一个方法来清空之前选的东西
            GlobalObject.AddFunction("removeChooseDishes").Execute += (sender, args) =>
            {
                removeChooseDishes();
            };

            //选中用户的账目从数据库取出，添加到右边
            GlobalObject.AddFunction("getShopperInfoToRight").Execute += getShopperInfoToRight;

            //在js中注册一个方法来删除账目事件
            GlobalObject.AddFunction("deleteListOfAccount").Execute += deleteListOfAccount;

            //在js中注册一个方法来序列化对象到文本文件中去
            GlobalObject.AddFunction("serializeDishes").Execute += serializeDishes;

            //在js中注册一个方法来向数据库中添加商品
            GlobalObject.AddFunction("addDishToDB").Execute += addDishToDB;

            //删除DB中的商品
            GlobalObject.AddFunction("removeLeftDish").Execute += removeLeftDish;

            //在js中注册一个方法搜索DB中的商品
            GlobalObject.AddFunction("searchDishes").Execute += searchDishes;

            //在js中注册一个方法每当订单和补菜切换时改变左侧选择的商品
            GlobalObject.AddFunction("changeDishlistType").Execute += (sender, args) =>
            {
                changeDishlistType();
            };

            //点击不同的分组，从DB中取出相应的东西
            GlobalObject.AddFunction("addDishesToLeft").Execute += addDishesToLeft;

            //更新拼音
            GlobalObject.AddFunction("updatePY").Execute += (sender, args) =>
            {
                updatePY();
            };

            //更新拼音
            GlobalObject.AddFunction("addFoods").Execute += (sender, args) =>
            {
                addFoods();
            };

            //获取更多顾客信息
            GlobalObject.AddFunction("getMoreShopper").Execute += getMoreShopper;
            
            /********************************************开账用******************************************************************/

            //选择菜品添加到右侧
            GlobalObject.AddFunction("addFoodToRight").Execute += addFoodToRight;

            //删除已选择的菜品
            GlobalObject.AddFunction("removeFoodToRight").Execute += removeFoodToRight;

            //后台取午/晚宴选了哪些菜品，在左侧导航栏将选择的菜品勾选出来
            GlobalObject.AddFunction("getSelectMenu").Execute += getSelectMenu;

            //重量发生改变
            GlobalObject.AddFunction("weightChange").Execute += weightChange;

            //桌数发生改变
            GlobalObject.AddFunction("tableNumChange").Execute += tableNumChange;

            //开账保存
            GlobalObject.AddFunction("printMenu").Execute += printMenu;

            //后台清空所有开账的有关信息
            GlobalObject.AddFunction("clearKaiZhangInfos").Execute += (sender, args) =>
            {
                clearKaiZhangInfos();
            };

            //根据orderNum获取开账的详细信息
            GlobalObject.AddFunction("getKaiZhangInfos").Execute += getKaiZhangInfos;

            //获取更多开账顾客信息
            GlobalObject.AddFunction("getMoreKZShopper").Execute += getMoreKZShopper;

            //账写成excel
            GlobalObject.AddFunction("exportExcel").Execute += exportExcel;

            /********************************************新增/修改******************************************************************/

            //通过id获取主料
            GlobalObject.AddFunction("getMainDishById").Execute += getMainDishById;

            //菜品添加到数据库
            GlobalObject.AddFunction("addFoodToDB").Execute += addFoodToDB;

            //取出要修改的商品
            GlobalObject.AddFunction("dishShowToModifyPage").Execute += dishShowToModifyPage;

            //更新某一个商品
            GlobalObject.AddFunction("updateDishToDB").Execute += updateDishToDB;

            //取出要修改的菜品
            GlobalObject.AddFunction("foodShowToModifyPage").Execute += foodShowToModifyPage;

            //更新某一个菜品
            GlobalObject.AddFunction("updateFoodToDB").Execute += updateFoodToDB;
            
            //删除DB中的菜品
            GlobalObject.AddFunction("removeLeftFood").Execute += removeLeftFood;

            //搜索菜品
            GlobalObject.AddFunction("searchFoods").Execute += searchFoods;
        }

        DishService dishService = new DishService();
        ShopperService shopperService = new ShopperService();
        DishListService dishListServer = new DishListService();
        FoodsService foodsService = new FoodsService();
        FoodListService foodListService = new FoodListService();

        

        private void ShowSetting()
        {
            this.UpdateUI(() =>
            {

                if (settingPage == null || settingPage.IsDisposed)
                {
                    settingPage = new frmSetting();
                    settingPage.Show(this);

                }
                else
                {
                    settingPage.Activate();
                }
            });
        }

        //打开新建群聊窗口
        private void showNewGroup(object sender, CfrV8HandlerExecuteEventArgs e)
        {
            this.UpdateUI(() =>
            {
                var orederNum = "";
                if (e.Arguments != null && e.Arguments.Length > 0)
                {
                    orederNum = e.Arguments.FirstOrDefault(p => p.IsString).StringValue;
                }
                //显示字窗体的过程，不解释
                if (newGroupForm == null || newGroupForm.IsDisposed)
                {
                    newGroupForm = new frmNewGroup();
                    newGroupForm.OrderNum = orederNum;
                    newGroupForm.Show(this);
                }
                else
                {
                    newGroupForm.Close();
                }

            });
        }

        //选择的菜
        private List<Dishes> chooseLis = new List<Dishes>();

        //选择的菜copy
        private List<Dishes> chooseLis_copy = new List<Dishes>();

        private Dictionary<String, Dishes> dic = new Dictionary<string, Dishes>();

        //选择菜的数量
        private int dishesNum;
        
        //账单分页，每页最大包含的个数
        private int pageCount = 10;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="start">重哪开始</param>
        /// <param name="pageCou">每页的条数</param>
        /// <param name="fromSource">1:账单，2：开账</param>
        private void addListOfAccounts(int start,int pageCou, int fromSource)
        {
            //获取所有的用户列表
            List<Shopper> shoppers = null;
            if (fromSource == 1)
            {
                shoppers = shopperService.getShopper(start, pageCou);
                string allShoppers = JsonConvert.SerializeObject(shoppers);
                ExecuteJavascript($"$client.addListOfAccountsToList('{allShoppers}')");
            }else
            {
                shoppers = shopperService.getShopper(start, pageCou, fromSource);
                string allShoppers = JsonConvert.SerializeObject(shoppers);
                ExecuteJavascript($"$client.kzAddListOfAccountsToList('{allShoppers}')");
            }
            

        }

        /// <summary>
        /// 往右边添加一个用户选择的菜
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void addDishToright(object sender, CfrV8HandlerExecuteEventArgs e)
        {
            var idAndType = String.Empty;
            if (e.Arguments != null && e.Arguments.Length > 0)
            {
                //获取的结果    f-id-Dishlist_type
                idAndType = e.Arguments.FirstOrDefault(p => p.IsString).StringValue;
            }
            string[] idAndType_Array = idAndType.Split('-');
            //根据Id获取商品信息
            Dishes d = dishService.getDishesById(Convert.ToInt32(idAndType_Array[1]));
            //设置类型：0-订货，1-补货，2退货
            d.Dishlist_type = Convert.ToInt32(idAndType_Array[2]);
            d.UpdateDate = CommonsUtil.currentTimeMillis(new DateTime());
            chooseLis.Add(d);
            string chooseLisJson = JsonConvert.SerializeObject(chooseLis);
            ExecuteJavascript($"$client.addToRight('{chooseLisJson}')");
        }

        /// <summary>
        /// 删除某个已选择的菜
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void removeDishToright(object sender, CfrV8HandlerExecuteEventArgs e)
        {
            var Id = "";
            if (e.Arguments != null && e.Arguments.Length > 0)
            {
                Id = e.Arguments.FirstOrDefault(p => p.IsString).StringValue;
            }
            string[] str = Id.Split('-');
            string chooseLisJson = String.Empty;
            for (int i = 0; i < chooseLis.Count; i++)
            {
                if (chooseLis[i].Dishes_id.ToString().Equals(str[1]) && chooseLis[i].Dishlist_type.ToString().Equals(str[2]))
                {

                    chooseLis.RemoveAt(i);
                    chooseLisJson = JsonConvert.SerializeObject(chooseLis);
                }
            }
            ExecuteJavascript($"$client.addToRight('{chooseLisJson}')");
        }

        /// <summary>
        /// 结算
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void moneyToCount(object sender, CfrV8HandlerExecuteEventArgs e)
        {
            var json = "";
            if (e.Arguments != null && e.Arguments.Length > 0)
            {
                json = e.Arguments.FirstOrDefault(p => p.IsString).StringValue;
            }

            JObject msg = (JObject)JsonConvert.DeserializeObject(json);
            //总计
            double money = 0;
            //前台获取的客户信息
            string orderNum = msg["OrderNum"].ToString();
            string adderss = msg["Shopper_address"].ToString();
            string name = msg["Shopper_Name"].ToString();
            string tableNum = msg["Shopper_tableNum"].ToString();
            string tel = msg["Shopper_tel"].ToString();
            string data = msg["DateToEat"].ToString();

            //判断是否是新的订单
            if (orderNum != null && orderNum != "")
            {
                //是老订单
                //比较选择的商品是否有改变
                for (int i = 0; i < chooseLis.Count(); i++)
                {

                    double weight = chooseLis[i].Dishes_weight;
                    double price = chooseLis[i].Dishes_price;

                    money += Math.Round(weight * price, 1, MidpointRounding.AwayFromZero);

                    int dishes_id = chooseLis[i].Dishes_id;
                    int dishList_id = chooseLis[i].Dishlist_id;
                    int type = chooseLis[i].Dishlist_type;
                    string key = dishes_id + "-" + type;
                    //是否存在某个key
                    if (dic.ContainsKey(key))
                    {
                        //说明已经存在需要更新
                        Dishes dish = dic[key];
                        if (weight != dish.Dishes_weight || price != dish.Dishes_price)
                        {
                            //数据库更新原来的商品列表
                            int row = dishListServer.updateDishListById(dishList_id, weight, price);
                        }
                        //删除这个key
                        dic.Remove(key);
                    }
                    else
                    {
                        //不存在某个key，原来没有，需要新增
                        //保存dishList

                        int dishlist_type = chooseLis[i].Dishlist_type;
                        string dishes_name = chooseLis[i].Dishes_name;
                        string dishes_unit = chooseLis[i].Dishes_unit;
                        long millis = chooseLis[i].UpdateDate;
                        int row = dishListServer.insertDishList(dishes_id,
                                                                dishlist_type,
                                                                price,
                                                                weight,
                                                                orderNum,
                                                                dishes_name,
                                                                dishes_unit,
                                                                millis);

                        //判断出现的次数
                        if (type == 0)
                        {
                            if (!dic.ContainsKey(dishes_id + "-" + 1))
                            {
                                //统计次数+1
                                dishService.updateDishes_countById(dishes_id);
                            }
                        }
                        else if (type == 1)
                        {
                            if (!dic.ContainsKey(dishes_id + "-" + 0))
                            {
                                //统计次数+1
                                dishService.updateDishes_countById(dishes_id);
                            }
                        }
                    }

                }
                //遍历删除剩下的要删除的商品
                Dictionary<string, Dishes>.ValueCollection valueCol = dic.Values;
                foreach (Dishes value in valueCol)
                {
                    dishListServer.delDelishListByID(value.Dishlist_id);
                }
                //更新shopper
                shopperService.updateShopperByOrderNum(
                                             orderNum,
                                             adderss,
                                             name,
                                             tableNum,
                                             tel,
                                             money,
                                             data);
            }
            else
            {
                //新订单
                Random rad = new Random();//实例化随机数产生器rad；
                int value = rad.Next(100000, 1000000);//用rad生成大于等于1000，小于等于9999的随机数；
                //生产orderNumber
                orderNum = DateTime.Now.ToString("yyyyMMddHHmmssfff") + value;
                //存储用户信息
                for (int i = 0; i < chooseLis.Count(); i++)
                {

                    double weight = chooseLis[i].Dishes_weight;
                    double price = chooseLis[i].Dishes_price;
                    money += weight * price;

                    int dishes_id = chooseLis[i].Dishes_id;
                    int type = chooseLis[i].Dishlist_type;
                    int dishlist_type = chooseLis[i].Dishlist_type;
                    string dishes_name = chooseLis[i].Dishes_name;
                    string dishes_unit = chooseLis[i].Dishes_unit;
                    long millis = chooseLis[i].UpdateDate;
                    //新增
                    //保存dishList
                    int row = dishListServer.insertDishList(dishes_id,
                                                            dishlist_type,
                                                            price,
                                                            weight,
                                                            orderNum,
                                                            dishes_name,
                                                            dishes_unit,
                                                            millis);
                    //统计次数+1
                    dishService.updateDishes_countById(dishes_id);
                }
                //新增
                shopperService.insertShopper(
                                             orderNum,
                                             adderss,
                                             name,
                                             tableNum,
                                             tel,
                                             money,
                                             data);
            }


            dishesNum = chooseLis.Count();
            ExecuteJavascript($"$client.moneyToCountResult('{orderNum + "-" + money}')");
            //根据orderNum取shopper
            getShopperAndDisher(orderNum);
            //重新初始化账目清单
            addListOfAccounts(0,pageCount,1);
            //刷新商品
            //addDishes();
            //TODO
        }

        /// <summary>
        /// 价格或者重量改变，改变List中的数据
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void WPChange(object sender, CfrV8HandlerExecuteEventArgs e)
        {
            var json = "";
            if (e.Arguments != null && e.Arguments.Length > 0)
            {
                json = e.Arguments.FirstOrDefault(p => p.IsString).StringValue;
            }
            JObject msg = (JObject)JsonConvert.DeserializeObject(json);
            for (int i = 0; i < chooseLis.Count; i++)
            {
                if (chooseLis[i].Dishes_id.ToString().Equals(msg["id"].ToString()) && chooseLis[i].Dishlist_type.ToString().Equals(msg["dishlistType"].ToString()))
                {
                    chooseLis[i].Dishes_weight = msg["weight"].ToString().Equals("") ? 0 : Convert.ToDouble(msg["weight"].ToString());
                    chooseLis[i].Dishes_price = msg["price"].ToString().Equals("") ? 0 : Convert.ToDouble(msg["price"].ToString());

                }
            }

        }

        /// <summary>
        /// 清空之前选的东西
        /// </summary>
        private void removeChooseDishes()
        {
            chooseLis.Clear();
            chooseLis_copy.Clear();
            dic.Clear();
        }

        /// <summary>
        /// 选中用户的账目从数据库取出，添加到右边
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void getShopperInfoToRight(object sender, CfrV8HandlerExecuteEventArgs e)
        {
            var orderNum = "";
            if (e.Arguments != null && e.Arguments.Length > 0)
            {
                orderNum = e.Arguments.FirstOrDefault(p => p.IsString).StringValue;
            }
            getShopperAndDisher(orderNum);
        }

        /// <summary>
        /// 根据订单号提取出来从数据库取顾客需要的商品
        /// </summary>
        /// <param name="orderNum"></param>
        private void getShopperAndDisher(string orderNum)
        {
            removeChooseDishes();
            dishListServer.getDishListByOrderNum(chooseLis, chooseLis_copy, dic, orderNum);
            string noonDishesJson = JsonConvert.SerializeObject(chooseLis);
            dishesNum = chooseLis.Count;
            ExecuteJavascript($"$client.addToRight('{noonDishesJson}')");
        }

        /// <summary>
        /// 删除账目，数据库也删掉
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void deleteListOfAccount(object sender, CfrV8HandlerExecuteEventArgs e)
        {
            var orderNum = "";
            if (e.Arguments != null && e.Arguments.Length > 0)
            {
                orderNum = e.Arguments.FirstOrDefault(p => p.IsString).StringValue;
            }
            //清空账目listOfAccounts
            //listOfAccounts.Clear();

            //删除shopper
            shopperService.delShopper(orderNum);
            //根据orderNum删除DishList
            dishListServer.delDishListByOrderNum(orderNum);
            //根据orderNum删除FoodList
            foodListService.delFoodListByOrderNum(orderNum);
            //重新初始化账目清单(由于有变动)
            addListOfAccounts(0,pageCount,1);
            //重新初始化开账历史记录
            addListOfAccounts(0, pageCount, 2);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="lieRow">某一行</param>
        /// <param name="column">某一列（从0开始）</param>
        /// <param name="str">插入的格式</param>
        /// <param name="style1">样式</param>
        private void addCellAndSetValue(IRow lieRow, int column, string[] str, ICellStyle style1)
        {
            for (int i = 0; i < str.Length; i++)
            {
                lieRow.CreateCell(column + i).SetCellValue(str[i]);
                lieRow.GetCell(column + i).CellStyle = style1;
            }
        }

        /// <summary>
        /// 写入excel
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void serializeDishes(object sender, CfrV8HandlerExecuteEventArgs e)
        {
            try
            {
                //自动获取桌面地址
                string path = System.Environment.GetFolderPath(System.Environment.SpecialFolder.Desktop) + "\\菜单&账单\\菜单\\";
                //判断文件夹是都存在，不存在创建
                if (!Directory.Exists(path))
                {
                    DirectoryInfo directoryInfo = new DirectoryInfo(path);
                    directoryInfo.Create();
                }

                HSSFWorkbook wk = new HSSFWorkbook();
                ISheet tb = wk.CreateSheet("mySheet");

                tb.Header.Center = @"&22 姚军南北货批发";

                tb.Footer.Right = "手机：13813789012  手机：13646281358";
                ICellStyle style1 = wk.CreateCellStyle();
                style1.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.CENTER;//【Center】居中  
                style1.WrapText = true;

                ICellStyle style2 = wk.CreateCellStyle();
                style2.Alignment = NPOI.SS.UserModel.HorizontalAlignment.CENTER_SELECTION;//【Center】居中  
                style2.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.CENTER;//【Center】居中  
                style2.WrapText = true;

                NPOI.SS.UserModel.IFont font = wk.CreateFont();
                font.FontHeightInPoints = 12;
                style1.SetFont(font);
                style2.SetFont(font);
                Dictionary<int, IRow> rows = new Dictionary<int, IRow>();
                IRow r = tb.CreateRow(0);
                r.Height = 30 * 20;
                rows.Add(0, r);
                for (int i = 1; i < 60; i++)
                {
                    rows.Add(i, tb.CreateRow(i));
                }
                var strs = "";
                if (e.Arguments != null && e.Arguments.Length > 0)
                {
                    strs = e.Arguments.FirstOrDefault(p => p.IsString).StringValue;
                }
                string needPrice = strs.Split('-')[0];
                string orderNum = strs.Split('-')[1];
                Shopper s = getShopper(orderNum);

                string excelPath = path + s.Shopper_Name + "-" + s.DateToEat + "请客(发货).xls";
                string excelPath_money = path + s.Shopper_Name + "-" + s.DateToEat + "请客(结账).xls";
                FileInfo fi = new FileInfo(excelPath);
                if (fi.Exists)     //判断文件是否已经存在,如果存在就删除!  
                {
                    if (CommonsUtil.FileIsUsed(excelPath))
                    {
                        MessageBox.Show("文件在被另一个程序使用，请先将其关闭");
                        return;
                    }
                    else
                    {
                        fi.Delete();
                    }
                }
                fi = new FileInfo(excelPath_money);
                if (fi.Exists)     //判断文件是否已经存在,如果存在就删除!  
                {
                    if (CommonsUtil.FileIsUsed(excelPath_money))
                    {
                        MessageBox.Show("文件在被另一个程序使用，请先将其关闭");
                        return;
                    }
                    else
                    {
                        fi.Delete();
                    }

                }

                int pageTotal = 42;
                string shopperInfo = "姓名:" + s.Shopper_Name + "  地址:" + s.Shopper_address + "  电话:" + s.Shopper_tel + "  " + s.DateToEat + "请客";
                if (needPrice.Equals("0") && dishesNum == chooseLis.Count)
                {
                    CellRangeAddress cellRangeAddress = new CellRangeAddress(0, 0, 0, 8);
                    tb.AddMergedRegion(cellRangeAddress);

                    rows[0].CreateCell(0).SetCellValue(shopperInfo);  //在第1行中创建单元格
                    rows[0].GetCell(0).CellStyle = style2;
                    string[] str = new string[4];
                    str[0] = "品名";
                    str[1] = "数量";
                    str[2] = "价格(元)";
                    str[3] = "小计(元)";
                    addCellAndSetValue(rows[1], 0, str, style1);
                    rows[2].CreateCell(0).SetCellValue("订单:");  //在第1行中创建单元格
                    rows[2].GetCell(0).CellStyle = style1;
                    int hang = 3;
                    int jiLie = 0;
                    int kaishiLie = 0;

                    int count1 = 0;
                    int count2 = 0;
                    int count3 = 0;

                    List<Dishlist> dishlist = dishListServer.getDishlistByOrderNum(orderNum);
                    for (int i = 0; i < dishlist.Count; i++)
                    {

                        jiLie = hang / pageTotal;
                        if (jiLie == 0)
                        {

                            if (count1 == 0)
                            {
                                kaishiLie = 0;
                            }
                            count1++;

                        }
                        else if (jiLie != 0 && jiLie % 2 == 1)
                        {
                            if (hang % pageTotal == 0)
                            {
                                count2 = 0;
                            }
                            if (count2 == 0)
                            {
                                kaishiLie += 5;
                            }
                            count2++;

                        }
                        else if (jiLie != 0 && jiLie % 2 == 0)
                        {
                            if (hang % pageTotal == 0)
                            {
                                count3 = 0;
                            }
                            if (count3 == 0)
                            {
                                kaishiLie += 4;
                            }
                            count3++;

                        }

                        if (hang % pageTotal == 0 && hang == pageTotal)
                        {
                            hang++;
                            addCellAndSetValue(rows[hang % pageTotal], kaishiLie, str, style1);
                            hang++;
                        }
                        else if (hang % pageTotal == 0 && hang != pageTotal)
                        {
                            addCellAndSetValue(rows[hang % pageTotal], kaishiLie, str, style1);
                            hang++;
                        }
                        string[] str1 = new string[4];
                        str1[0] = dishlist[i].Dishes_name;
                        str1[1] = dishlist[i].Dishes_weight + dishlist[i].Dishes_unit;
                        str1[2] = dishlist[i].Dishes_price.ToString();
                        //四舍五入保留一位有效数字
                        str1[3] = Math.Round(Convert.ToDouble(dishlist[i].Dishes_weight * dishlist[i].Dishes_price), 1, MidpointRounding.AwayFromZero).ToString();

                        addCellAndSetValue(rows[hang % pageTotal], kaishiLie, str1, style1);
                        hang++;

                        //补菜
                        if ((i + 1) < dishlist.Count)
                        {
                            if (dishlist[i].Dishlist_type != dishlist[i + 1].Dishlist_type)
                            {
                                jiLie = hang / pageTotal;
                                if (jiLie == 0)
                                {

                                    if (count1 == 0)
                                    {
                                        kaishiLie = 0;
                                    }
                                    count1++;

                                }
                                else if (jiLie != 0 && jiLie % 2 == 1)
                                {
                                    if (hang % pageTotal == 0)
                                    {
                                        count2 = 0;
                                    }
                                    if (count2 == 0)
                                    {
                                        kaishiLie += 5;
                                    }
                                    count2++;

                                }
                                else if (jiLie != 0 && jiLie % 2 == 0)
                                {
                                    if (hang % pageTotal == 0)
                                    {
                                        count3 = 0;
                                    }
                                    if (count3 == 0)
                                    {
                                        kaishiLie += 4;
                                    }
                                    count3++;

                                }

                                if (hang % pageTotal == 0 && hang == pageTotal)
                                {
                                    hang++;
                                    addCellAndSetValue(rows[hang % pageTotal], kaishiLie, str, style1);
                                    hang++;
                                }
                                else if (hang % pageTotal == 0 && hang != pageTotal)
                                {
                                    addCellAndSetValue(rows[hang % pageTotal], kaishiLie, str, style1);
                                    hang++;
                                }
                                str1[0] = "补菜：";
                                str1[1] = "";
                                str1[2] = "";
                                str1[3] = "";
                                addCellAndSetValue(rows[hang % pageTotal], kaishiLie, str1, style1);
                                hang++;
                            }
                        }
                    }

                    //合计
                    jiLie = hang / pageTotal;
                    if (jiLie == 0)
                    {

                        if (count1 == 0)
                        {
                            kaishiLie = 0;
                        }
                        count1++;

                    }
                    else if (jiLie != 0 && jiLie % 2 == 1)
                    {
                        if (hang % pageTotal == 0)
                        {
                            count2 = 0;
                        }
                        if (count2 == 0)
                        {
                            kaishiLie += 5;
                        }
                        count2++;

                    }
                    else if (jiLie != 0 && jiLie % 2 == 0)
                    {
                        if (hang % pageTotal == 0)
                        {
                            count3 = 0;
                        }
                        if (count3 == 0)
                        {
                            kaishiLie += 4;
                        }
                        count3++;

                    }
                    str[0] = "合计(元):";
                    str[1] = s.TotalMoney.ToString();
                    str[2] = "";
                    str[3] = "";
                    if (hang % pageTotal == 0 && hang == pageTotal)
                    {
                        hang++;
                        addCellAndSetValue(rows[hang % pageTotal], kaishiLie, str, style1);
                        hang++;
                    }
                    else if (hang % pageTotal == 0 && hang != pageTotal)
                    {
                        addCellAndSetValue(rows[hang % pageTotal], kaishiLie, str, style1);
                        hang++;
                    }
                    else
                    {
                        addCellAndSetValue(rows[hang % pageTotal], kaishiLie, str, style1);
                        hang++;
                    }

                    //设置单元格宽度
                    int count = 4;
                    for (int i = 0; i < kaishiLie + 4; i++)
                    {
                        if (count == i)
                        {
                            tb.SetColumnWidth(i, 4 * 250);
                            count += 9;
                        }
                        else
                        {
                            tb.SetColumnWidth(i, 11 * 250);
                        }

                    }

                    using (FileStream fs = File.OpenWrite(excelPath_money)) //打开一个xls文件，如果没有则自行创建，如果存在myxls.xls文件则在创建是不要打开该文件！
                    {
                        wk.Write(fs);   //向打开的这个xls文件中写入mySheet表并保存。
                                        //MessageBox.Show("结算单写入完毕");
                    }

                }
                else if (needPrice.Equals("1") && dishesNum == chooseLis.Count)
                {
                    tb.Footer.Left = "地址：林梓金盛农贸市场姚军南北货批发";
                    CellRangeAddress cellRangeAddress = new CellRangeAddress(0, 0, 0, 7);
                    tb.AddMergedRegion(cellRangeAddress);
                    rows[0].CreateCell(0).SetCellValue(shopperInfo);  //在第1行中创建单元格
                    rows[0].GetCell(0).CellStyle = style2;
                    string[] str = new string[2];
                    str[0] = "品名";
                    str[1] = "数量";
                    addCellAndSetValue(rows[1], 0, str, style1);
                    rows[2].CreateCell(0).SetCellValue("订单:");  //在第1行中创建单元格
                    rows[2].GetCell(0).CellStyle = style1;
                    int hang = 3;
                    int jiLie = 0;
                    int kaishiLie = 0;

                    int count1 = 0;
                    int count2 = 0;
                    List<Dishlist> dishlist = dishListServer.getDishlistByOrderNum(orderNum);
                    for (int i = 0; i < dishlist.Count; i++)
                    {
                        //输入的第三列开始
                        int pageBegin = 6;
                        //基础列
                        jiLie = hang / pageTotal;
                        
                        if (jiLie == 0)//从0开始第0列开始写
                        {

                            if (count1 == 0)
                            {
                                //开始列为0
                                kaishiLie = 0;
                            }
                            count1++;
                        }
                        else if (jiLie != 0)//从0开始不是写在第0行了
                        {
                            if (hang % pageTotal == 0)
                            {
                                count2 = 0;
                            }
                            if (count2 == 0 && pageBegin == kaishiLie)
                            {
                                kaishiLie += 2;
                            }
                            else if (count2 == 0 && pageBegin != kaishiLie)
                            {
                                kaishiLie += 3;
                            }
                            count2++;
                        }

                        //excel中写的少于3列（第一页中）
                        if (hang % pageTotal == 0 && hang < pageTotal * 3)
                        {
                            //从0开始第1行开始写
                            hang++;
                            addCellAndSetValue(rows[hang % pageTotal], kaishiLie, str, style1);
                            hang++;
                        }
                        else if (hang % pageTotal == 0 && hang >= pageTotal * 3)//到了第二页
                        {
                            //从0开始第0行开始写
                            addCellAndSetValue(rows[hang % pageTotal], kaishiLie, str, style1);
                            hang++;
                        }
                        string[] str1 = new string[2];
                        str1[0] = dishlist[i].Dishes_name;
                        str1[1] = dishlist[i].Dishes_weight + dishlist[i].Dishes_unit;

                        addCellAndSetValue(rows[hang % pageTotal], kaishiLie, str1, style1);
                        hang++;
                        if ((i + 1) < dishlist.Count)
                        {
                            if (dishlist[i].Dishlist_type != dishlist[i + 1].Dishlist_type)
                            {
                                jiLie = hang / pageTotal;
                                if (jiLie == 0)
                                {

                                    if (count1 == 0)
                                    {
                                        kaishiLie = 0;
                                    }
                                    count1++;
                                }
                                else if (jiLie != 0)
                                {
                                    if (hang % pageTotal == 0)
                                    {
                                        count2 = 0;
                                    }
                                    if (count2 == 0)
                                    {
                                        kaishiLie += 3;
                                    }
                                    count2++;
                                }

                                if (hang % pageTotal == 0 && hang < pageTotal * 3)
                                {
                                    hang++;
                                    addCellAndSetValue(rows[hang % pageTotal], kaishiLie, str, style1);
                                    hang++;
                                }
                                else if (hang % pageTotal == 0 && hang >= pageTotal * 3)
                                {
                                    addCellAndSetValue(rows[hang % pageTotal], kaishiLie, str, style1);
                                    hang++;
                                }
                                str1[0] = "补菜：";
                                str1[1] = "";
                                addCellAndSetValue(rows[hang % pageTotal], kaishiLie, str1, style1);
                                hang++;
                            }
                        }

                    }
                    int count = 0;
                    if ((kaishiLie + 2) <= 8)
                    {
                        count = 8;
                    }
                    else
                    {
                        count = kaishiLie + 2;
                    }
                    for (int i = 0; i < count; i++)
                    {
                        tb.SetColumnWidth(i, 11 * 256);
                    }

                    using (FileStream fs = File.OpenWrite(excelPath)) //打开一个xls文件，如果没有则自行创建，如果存在myxls.xls文件则在创建是不要打开该文件！
                    {
                        wk.Write(fs);   //向打开的这个xls文件中写入mySheet表并保存。
                                        //MessageBox.Show("发货单写入完毕");
                    }
                }
                else
                {
                    MessageBox.Show("请先保存");
                }
                System.Threading.Thread.Sleep(1000);
            }
            finally
            {
                ExecuteJavascript($"$client.hideWatting()");
            }
        }

        /// <summary>
        /// 根据订单号获得顾客信息
        /// </summary>
        /// <param name="orderNum"></param>
        /// <returns></returns>
        private Shopper getShopper(string orderNum)
        {
            return shopperService.getShopperByOrderNum(orderNum);
        }

        /// <summary>
        /// 添加商品
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void addDishToDB(object sender, CfrV8HandlerExecuteEventArgs e)
        {
            var strs = "";
            if (e.Arguments != null && e.Arguments.Length > 0)
            {
                strs = e.Arguments.FirstOrDefault(p => p.IsString).StringValue;
            }
            string name = strs.Split('-')[0];
            string kind = strs.Split('-')[1];
            string unit = strs.Split('-')[2];
            //根据名称取商品
            Dishes d = dishService.getDishesByName(name);
            if (d != null && d.Dishes_type == 1 && d.Dishes_kind == Convert.ToInt32(kind) && unit.Equals(d.Dishes_unit))//名字相同，正常状态，类型相同
            {
                ExecuteJavascript($"$client.clearModifyPage('{"1-no"}')");
            }
            else if (d != null && d.Dishes_type == 0 && d.Dishes_kind == Convert.ToInt32(kind) && unit.Equals(d.Dishes_unit))
            {
                //本来就存在跟新商品
                dishService.updatDish(d.Dishes_count, kind, unit);
                //if (kind.Equals("1"))//是自家商品，商品列表才刷新
                //{
                //    //有变动刷新商品
                //    getAllKindDishes();
                //}
                ExecuteJavascript($"$client.clearModifyPage('{"1-no"}')");
            }
            else
            {
                //添加商品
                dishService.insertDish(name, kind, unit);
                //MessageBox.Show("添加成功！");
                //if (kind.Equals("1"))//是自家商品，商品列表才刷新
                //{
                //    //有变动刷新商品
                //    getAllKindDishes();
                //}
                ExecuteJavascript($"$client.clearModifyPage('{"1-no"}')");
            }
        }

        /// <summary>
        /// 删除DB中的商品
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void removeLeftDish(object sender, CfrV8HandlerExecuteEventArgs e)
        {
            var str = "";
            if (e.Arguments != null && e.Arguments.Length > 0)
            {
                str = e.Arguments.FirstOrDefault(p => p.IsString).StringValue;
            }
            //根据Id查找菜品里面，有没有用该商品做主料的
            List<Foods> foods = foodListService.getFoodsByMainId(Convert.ToInt32(str));
            if (foods.Count() == 0)
            {
                //更改状态为0（0删除）
                dishService.updatDishById(str);
                ExecuteJavascript($"$client.clearModifyPage('{"1-no"}')");
            }
            else
            {
                string msg = "取消其他【菜品】与该【商品】的关联后在进行删除操作";
                ExecuteJavascript($"$client.promptInformation('{msg}')");

            }
        }




        /// <summary>
        /// 搜索DB中的商品
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void searchDishes(object sender, CfrV8HandlerExecuteEventArgs e)
        {
            var str = "";
            if (e.Arguments != null && e.Arguments.Length > 0)
            {
                //获取模糊查询的关键词
                str = e.Arguments.FirstOrDefault(p => p.IsString).StringValue;
            }
            //模糊查询操作
            List<Dishes> dishes = dishService.getDishByLike(str.ToUpper());
            string noonDishesJson = JsonConvert.SerializeObject(dishes);
            ExecuteJavascript($"$client.searchDishesResult('{noonDishesJson}')");

        }

        /// <summary>
        /// 每当订单和补菜切换时改变左侧选择的商品
        /// </summary>
        private void changeDishlistType()
        {
            string ChooseDishes = JsonConvert.SerializeObject(chooseLis);
            ExecuteJavascript($"$client.dishlistTypeChange('{ChooseDishes}')");
        }

        /// <summary>
        /// 点击某个菜单分组则到后台取相应的分组的东西
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void addDishesToLeft(object sender, CfrV8HandlerExecuteEventArgs e)
        {
            string flag = "";
            if (e.Arguments != null && e.Arguments.Length > 0)
            {
                flag = e.Arguments.FirstOrDefault(p => p.IsString).StringValue;
            }

            if (flag.Equals("goods"))
            {
                getAllKindDishes();
            }
            else if (flag.Equals("loa"))
            {
                //如果是请求的客户列表（账目列表）
                addListOfAccounts(0, pageCount, 1);
            }else if (flag.Equals("hm"))
            {
                //如果是请求的客户列表（账目列表）
                addListOfAccounts(0, pageCount, 2);
            }

            else if (flag.Equals("cf") || flag.Equals("hf") || flag.Equals("mf") || flag.Equals("sgdx") || flag.Equals("pl") || flag.Equals("sc") || flag.Equals("sg"))
            {
                getOneKindFoods(flag);
            }
            else if (flag.Equals("goods_xg"))
            {
                List<Dishes> dishes = dishService.getDishesByParam();
                string allDish_xg = JsonConvert.SerializeObject(dishes);
                ExecuteJavascript($"$client.addAllGoodsToList_xg('{ allDish_xg }')");
            }
            else if (flag.Equals("cf_xg") || flag.Equals("hf_xg") || flag.Equals("mf_xg") || flag.Equals("sgdx_xg") || flag.Equals("pl_xg") || flag.Equals("sc_xg") || flag.Equals("sg_xg"))
            {
                getOneKindFood_XG(flag);
            }
        }

        /// <summary>
        /// 取出所有的商品
        /// </summary>
        private void getAllKindDishes()
        {
            //取出所有的商品
            List<Dishes> dishes = dishService.getDishesByParamExceptVegetables();

            string partDishes = JsonConvert.SerializeObject(dishes);
            string ChooseDishes = JsonConvert.SerializeObject(chooseLis);
            ExecuteJavascript($"$client.addToList('{ partDishes + "-" + ChooseDishes }')");
        }

        /// <summary>
        /// 更新拼音
        /// </summary>
        private void updatePY()
        {
            //如果是请求商品列表的某一个
            List<Dishes> dishes = dishService.getAllDishes();

            for (int i = 0; i < dishes.Count(); i++)
            {
                dishService.updateDishes(dishes[i].Dishes_id, dishes[i].Dishes_name);
            }
        }

        /// <summary>
        /// 添加
        /// </summary>
        private void addFoods()
        {
            //如果是请求商品列表的某一个
            List<Dishes> dishes = dishService.getAllDishes();

            for (int i = 0; i < dishes.Count(); i++)
            {
                foodsService.insertFood(dishes[i].Dishes_name,1, dishes[i].Dishes_id,0,0);
            }
        }


        /// <summary>
        /// 点击某个菜单分组则到后台取相应的分组的东西(账目用)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void getMoreShopper(object sender, CfrV8HandlerExecuteEventArgs e)
        {
            string shopperCountStr = "";
            if (e.Arguments != null && e.Arguments.Length > 0)
            {
                shopperCountStr = e.Arguments.FirstOrDefault(p => p.IsString).StringValue;
            }
            int pageStare = Convert.ToInt32(shopperCountStr);
            List<Shopper> shoppers = shopperService.getShopper(pageStare, pageCount);
            string moreShoppers = JsonConvert.SerializeObject(shoppers);
            ExecuteJavascript($"$client.addMoreShoppersToList('{moreShoppers}')");
        }

        /********************************************开账用******************************************************************/

        //午宴选择的菜品
        private List<Foods> noonFoods = new List<Foods>();

        //晚宴选择的菜品
        private List<Foods> nightFoods = new List<Foods>();

        //选择的配料   
        private List<Foods> peiLiao = new List<Foods>();

        //修改菜单，新添加或删除的菜品或调料
        private List<FoodListForModify> addOrDelFoods = new List<FoodListForModify>();

        //中午桌数
        private int tableNumber_noon = 0;
        //晚上桌数
        private int tableNumber_night = 0;

        //实时单桌总计
        private double realTimeMoney = 0;

        /// <summary>
        /// 取出某一大类的食物
        /// </summary>
        /// <param name="flag"></param>
        private void getOneKindFoods(string flag)
        {
            int kind = 0;
            if (flag.Equals("cf"))
            {
                kind = 1;
            }
            else if (flag.Equals("hf"))
            {
                kind = 2;
            }
            else if (flag.Equals("mf"))
            {
                kind = 3;
            }
            else if (flag.Equals("sgdx"))
            {
                kind = 4;
            }
            else if (flag.Equals("pl"))
            {
                kind = 5;
            }
            else if (flag.Equals("sc"))
            {
                kind = 6;
            }
            else if (flag.Equals("sg"))
            {
                kind = 7;
            }
            List<Foods> foods = foodsService.getFoodsByType(kind);
            string partFoods = JsonConvert.SerializeObject(foods);
            //string ChooseDishes = JsonConvert.SerializeObject(chooseLis);
            ExecuteJavascript($"$client.refreshLeftOneKindFoodList('{ partFoods + "-" + flag }')");
        }

        private void getOneKindFood_XG(string flag)
        {
            int kind = 0;
            if (flag.Equals("cf_xg"))
            {
                kind = 1;
            }
            else if (flag.Equals("hf_xg"))
            {
                kind = 2;
            }
            else if (flag.Equals("mf_xg"))
            {
                kind = 3;
            }
            else if (flag.Equals("sgdx_xg"))
            {
                kind = 4;
            }
            else if (flag.Equals("pl_xg"))
            {
                kind = 5;
            }
            else if (flag.Equals("sc_xg"))
            {
                kind = 6;
            }
            else if (flag.Equals("sg_xg"))
            {
                kind = 7;
            }
            List<Foods> foods = foodsService.getFoodsByType(kind);
            string partFoods = JsonConvert.SerializeObject(foods);
            ExecuteJavascript($"$client.refreshLeftOneKindFoodList_XG('{ partFoods + "-" + flag }')");
        }

        //进一法，并保留1位小数
        private double goOne(double num)
        {
            double a = Math.Ceiling(num * 10);
            return a * 1.0 / 10;
        }

        /// <summary>
        /// 操作记录更新
        /// </summary>
        /// <param name="fromSource">是午宴，晚宴还是配料</param>
        /// <param name="food">food类</param>
        /// <param name="operation_type_top">前端的操作 0：新增    1：删除    2：修改  </param>
        /// <param name="orderNum">订单号</param>
        private void updateXiuGaiList(int fromSource,Foods food, int operation_type_top, string orderNum)
        {
            //取出对比用的foodlistInfo
            FoodList foodlistInfo = foodListService.getOneInfo(orderNum, food.Id, fromSource);
            //前端操作类型
            if (operation_type_top == 0 || operation_type_top == 2)//新增/修改
            {
                //数据库中原本有没有：1）有，判断重量是否一致，不一致则需要修改，一致则找操作列表看有无操作痕迹存在则删除；2）没有，直接新增
                if (foodlistInfo != null && (foodlistInfo.Part_weight != food.Food_weight_total || foodlistInfo.Diy_type != food.Diy_type)) //有，重量或自定义的菜品类型不一致
                {
                    //需要修改
                    //查看原来有没有操作过该菜品
                    int index = isExitInOperationList(food, fromSource);
                    if (index == -1)//没有操作过
                    {
                        FoodListForModify flfm = new FoodListForModify();
                        flfm.Food_id = food.Id;
                        flfm.FromSource = fromSource;
                        flfm.Operation_type = FoodListForModify.update;
                        flfm.Weight = food.Food_weight_total;
                        flfm.Diy_type = food.Diy_type;
                        addOrDelFoods.Add(flfm);
                    }
                    else//操作过，修改对应的foodListForModify
                    {
                        addOrDelFoods[index].Operation_type = FoodListForModify.update;
                        addOrDelFoods[index].Weight = food.Food_weight_total;
                        addOrDelFoods[index].Diy_type = food.Diy_type;
                    }
                }else if(foodlistInfo == null)
                {
                    //需要添加
                    //查看原来有没有操作过该菜品
                    int index = isExitInOperationList(food, fromSource);
                    if (index == -1)//没有操作过
                    {
                        FoodListForModify flfm = new FoodListForModify();
                        flfm.Food_id = food.Id;
                        flfm.FromSource = fromSource;
                        flfm.Operation_type = FoodListForModify.add;
                        flfm.Weight = food.Food_weight_total;
                        flfm.Diy_type = food.Diy_type;
                        flfm.InTime = CommonsUtil.currentTimeMillis(new DateTime());
                        addOrDelFoods.Add(flfm);
                    }
                    else//操作过，修改对应的foodListForModify
                    {
                        addOrDelFoods[index].Operation_type = FoodListForModify.add;
                        addOrDelFoods[index].Weight = food.Food_weight_total;
                        addOrDelFoods[index].Diy_type = food.Diy_type;
                    }
                }else if (foodlistInfo != null && foodlistInfo.Part_weight == food.Food_weight_total && foodlistInfo.Diy_type == food.Diy_type) //有，重量和自定义的菜品类型都一致；看有无操作痕迹，有则删除
                {
                    //查看原来有没有操作过该菜品
                    int index = isExitInOperationList(food, fromSource);
                    if (index != -1)//操作过
                    {
                        addOrDelFoods.RemoveAt(index);
                    }
                }
            }
            else if (operation_type_top == 1)//删除
            {
                //数据库中原本有没有：有，删除；没有不变
                if (foodlistInfo != null) //有
                {
                    //需要删除
                    //查看原来有没有操作过该菜品
                    int index = isExitInOperationList(food, fromSource);
                    if (index == -1)//没有操作过
                    {
                        FoodListForModify flfm = new FoodListForModify();
                        flfm.Food_id = food.Id;
                        flfm.FromSource = fromSource;
                        flfm.Operation_type = FoodListForModify.del;
                        addOrDelFoods.Add(flfm);
                    }
                    else//操作过，修改对应的foodListForModify
                    {
                        addOrDelFoods[index].Operation_type = FoodListForModify.del;
                        addOrDelFoods[index].Weight = food.Food_weight_total;
                        addOrDelFoods[index].Diy_type = food.Diy_type;
                    }
                }else
                {
                    //查看原来有没有操作过该菜品
                    int index = isExitInOperationList(food, fromSource);
                    if (index != -1)//操作过
                    {
                        addOrDelFoods.RemoveAt(index);
                    }
                }
            }
        }

        /// <summary>
        /// 查找是否在操作列中
        /// </summary>
        /// <param name="food"></param>
        /// <param name="fromSource"></param>
        /// <returns></returns>
        private int isExitInOperationList(Foods food,int fromSource)
        {
            int index = -1;
            //查找现在有没有对其进行过操作
            for (int i = 0; i < addOrDelFoods.Count(); i++)
            {
                //FromSource和foodId相同便认为是操作的同一菜品
                if (addOrDelFoods[i].Food_id == food.Id && addOrDelFoods[i].FromSource == fromSource)
                {
                    return i;
                }
            }

            return index;
        }

        /// <summary>
        /// 选择菜品添加到右侧
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void addFoodToRight(object sender, CfrV8HandlerExecuteEventArgs e)
        {
            string param = "";
            if (e.Arguments != null && e.Arguments.Length > 0)
            {
                param = e.Arguments.FirstOrDefault(p => p.IsString).StringValue;
            }
            //food的ID
            string id = param.Split('-')[1];
            string type = param.Split('-')[2];
            //添加到的列表编号
            string index = param.Split('-')[3];
            //订单号
            string orderNum = param.Split('-')[4];
            //现在添加到的类型
            string diyType = param.Split('-')[5];
            //根据ID差出菜品
            Foods food = foodsService.getFoodsByid(Convert.ToInt32(id));
            
            if (index == "0")
            {
                food.Diy_type = Convert.ToInt32(diyType);
                food.InTime = CommonsUtil.currentTimeMillis(new DateTime());
                //根据桌数，算出总需求量
                food.Food_weight_total = goOne(food.Food_weight_avg * tableNumber_noon);
                //商品总重量*单价/桌数=某道菜单桌的价钱
                //保留1位有效数字，四舍五入
                realTimeMoney = realTimeMoney + Math.Round(food.Food_weight_total * food.Food_price / (tableNumber_noon + tableNumber_night), 1, MidpointRounding.AwayFromZero);

                //订单号不为空
                if (!orderNum.Equals("error"))
                {
                    //更新操作里的数据
                    updateXiuGaiList(0, food, 0, orderNum);
                }
                //标记放在哪个集合里面
                food.FromSource = 0;
                //午宴选择的菜品
                noonFoods.Add(food);
                noonFoods.Sort(new FoodComparer());
                string noonFoodsJson = JsonConvert.SerializeObject(noonFoods);
                ExecuteJavascript($"$client.foodsToRight('{noonFoodsJson + "-" + 0}')");
            }
            else if (index == "1")
            {
                food.Diy_type = Convert.ToInt32(diyType);
                food.InTime = CommonsUtil.currentTimeMillis(new DateTime());
                //根据桌数，算出总需求量
                food.Food_weight_total = goOne(food.Food_weight_avg * tableNumber_night);
                //商品总重量*单价/桌数=某道菜单桌的价钱
                //保留1位有效数字，四舍五入
                realTimeMoney = realTimeMoney + Math.Round(food.Food_weight_total * food.Food_price / (tableNumber_noon + tableNumber_night), 1, MidpointRounding.AwayFromZero);

                //订单号不为空
                if (!orderNum.Equals("error"))
                {
                    //更新操作里的数据
                    updateXiuGaiList(1, food, 0, orderNum);
                }
                //标记放在哪个集合里面
                food.FromSource = 1;
                //晚宴选择的菜品
                nightFoods.Add(food);
                nightFoods.Sort(new FoodComparer());
                string nightFoodsJson = JsonConvert.SerializeObject(nightFoods);
                ExecuteJavascript($"$client.foodsToRight('{nightFoodsJson + "-" + 1}')");
            }
            else if (index == "2")
            {
                food.Diy_type = food.Food_type;
                food.InTime = CommonsUtil.currentTimeMillis(new DateTime());
                //选择的配料   

                //订单号不为空
                if (!orderNum.Equals("error"))
                {
                    //更新操作里的数据
                    updateXiuGaiList(2, food, 0, orderNum);
                }
                //标记放在哪个集合里面
                food.FromSource = 2;
                peiLiao.Add(food);
                peiLiao.Sort(new FoodComparer());
                string peiLiaoJson = JsonConvert.SerializeObject(peiLiao);
                ExecuteJavascript($"$client.foodsToRight('{peiLiaoJson + "-" + 2}')");
            }
            ExecuteJavascript($"$client.updateRealTimeMoney('{realTimeMoney}')");
        }

        /// <summary>
        /// 删除已选择的菜品
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void removeFoodToRight(object sender, CfrV8HandlerExecuteEventArgs e)
        {
            string param = "";
            if (e.Arguments != null && e.Arguments.Length > 0)
            {
                param = e.Arguments.FirstOrDefault(p => p.IsString).StringValue;
            }
            //food的ID
            string id = param.Split('-')[1];
            string type = param.Split('-')[2];
            //删除到的列表编号
            string index = param.Split('-')[3];
            //订单号
            string orderNum = param.Split('-')[4];
            int int_id = Convert.ToInt32(id);

            if (index == "0")
            {
                //删除某个已选择的菜品
                for (int i = 0; i < noonFoods.Count(); i++)
                {
                    if (int_id == noonFoods[i].Id)
                    {
                        //商品总重量*单价/桌数=某道菜单桌的价钱
                        //保留1位有效数字，四舍五入
                        realTimeMoney = realTimeMoney - Math.Round(noonFoods[i].Food_weight_total * noonFoods[i].Food_price / (tableNumber_noon + tableNumber_night), 1, MidpointRounding.AwayFromZero);

                        //订单号不为空
                        if (!orderNum.Equals("error"))
                        {
                            //更新操作里的数据
                            updateXiuGaiList(0, noonFoods[i], 1, orderNum);
                        }
                        
                        noonFoods.RemoveAt(i);
                        break;
                    }
                }
                string noonFoodsJson = JsonConvert.SerializeObject(noonFoods);
                ExecuteJavascript($"$client.foodsToRight('{noonFoodsJson + "-" + 0}')");
            }
            else if (index == "1")
            {
                //删除某个已选择的菜品
                for (int i = 0; i < nightFoods.Count(); i++)
                {
                    if (int_id == nightFoods[i].Id)
                    {
                        //商品总重量*单价/桌数=某道菜单桌的价钱
                        //保留1位有效数字，四舍五入
                        realTimeMoney = realTimeMoney - Math.Round(nightFoods[i].Food_weight_total * nightFoods[i].Food_price / (tableNumber_noon + tableNumber_night), 1, MidpointRounding.AwayFromZero);
                        //更新操作里的数据

                        //订单号不为空
                        if (!orderNum.Equals("error"))
                        {
                            //更新操作里的数据
                            updateXiuGaiList(1, nightFoods[i], 1, orderNum);
                        }
                        
                        nightFoods.RemoveAt(i);
                        break;
                    }
                }
                //序列化成json格式
                string nightFoodsJson = JsonConvert.SerializeObject(nightFoods);
                //ExecuteJavascript($"$client.nightFoodsToRight('{nightFoodsJson}')");
                ExecuteJavascript($"$client.foodsToRight('{nightFoodsJson + "-" + 1}')");
            }
            else if (index == "2")
            {
                //删除某个已选择的菜品
                for (int i = 0; i < peiLiao.Count(); i++)
                {
                    if (int_id == peiLiao[i].Id)
                    {
                        //重量大于0是才算入单桌价钱
                        if (peiLiao[i].Food_weight_total > 0)//重量大于0，减去
                        {
                            //商品总重量*单价/桌数=某道菜单桌的价钱
                            //保留1位有效数字，四舍五入
                            realTimeMoney = realTimeMoney - Math.Round(peiLiao[i].Food_weight_total * peiLiao[i].Food_price / (tableNumber_night+ tableNumber_noon), 1, MidpointRounding.AwayFromZero);
                        }

                        //订单号不为空
                        if (!orderNum.Equals("error"))
                        {
                            //更新操作里的数据
                            updateXiuGaiList(2, peiLiao[i], 1, orderNum);
                        }
                        
                        peiLiao.RemoveAt(i);
                        break;
                    }
                }
                string peiLiaoJson = JsonConvert.SerializeObject(peiLiao);
                //ExecuteJavascript($"$client.peiLiaoToRight('{peiLiaoJson}')");
                ExecuteJavascript($"$client.foodsToRight('{peiLiaoJson + "-" + 2}')");
            }
            ExecuteJavascript($"$client.updateRealTimeMoney('{realTimeMoney}')");
        }

        /// <summary>
        /// 后台取午/晚宴选了哪些菜品，在左侧导航栏将选择的菜品勾选出来
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void getSelectMenu(object sender, CfrV8HandlerExecuteEventArgs e)
        {
            string param = "";
            if (e.Arguments != null && e.Arguments.Length > 0)
            {
                param = e.Arguments.FirstOrDefault(p => p.IsString).StringValue;
            }
            if (param == "0")
            {
                string noonFoodsJson = JsonConvert.SerializeObject(noonFoods);
                ExecuteJavascript($"$client.foodsToRight('{noonFoodsJson + "-" + 0}')");
            }
            else
            {
                string nightFoodsJson = JsonConvert.SerializeObject(nightFoods);
                ExecuteJavascript($"$client.foodsToRight('{nightFoodsJson + "-" + 1}')");
            }
        }

        /// <summary>
        /// 重量发生改变
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void weightChange(object sender, CfrV8HandlerExecuteEventArgs e)
        {
            string param = "";
            if (e.Arguments != null && e.Arguments.Length > 0)
            {
                param = e.Arguments.FirstOrDefault(p => p.IsString).StringValue;
            }
            //food的ID
            string id = param.Split('-')[1];
            string type = param.Split('-')[2];
            //修改菜品的容器编号
            string index = param.Split('-')[3];
            string weight = param.Split('-')[4];
            string orderNum = param.Split('-')[5];
            int int_id = Convert.ToInt32(id);
            double d_weight = Convert.ToDouble(weight);
            //午宴
            if (index == "0")
            {
                //重量发生改变
                for (int i = 0; i < noonFoods.Count(); i++)
                {
                    if (int_id == noonFoods[i].Id)
                    {
                        //先减去原来这个才的钱
                        realTimeMoney = realTimeMoney - Math.Round(noonFoods[i].Food_weight_total * noonFoods[i].Food_price / (tableNumber_noon + tableNumber_night), 1, MidpointRounding.AwayFromZero);
                        //修改重量
                        noonFoods[i].Food_weight_total = d_weight;
                        //加上现在的钱
                        realTimeMoney = realTimeMoney + Math.Round(noonFoods[i].Food_weight_total * noonFoods[i].Food_price / (tableNumber_noon + tableNumber_night), 1, MidpointRounding.AwayFromZero);
                        
                        //订单号不为空
                        if (!orderNum.Equals("error"))
                        {
                            //更新操作里的数据
                            updateXiuGaiList(0, noonFoods[i], 2, orderNum);
                        }
                        
                        break;
                    }
                }
            }
            //晚宴
            else if (index == "1")
            {
                //重量发生改变
                for (int i = 0; i < nightFoods.Count(); i++)
                {
                    if (int_id == nightFoods[i].Id)
                    {
                        //先减去原来这个才的钱
                        realTimeMoney = realTimeMoney - Math.Round(nightFoods[i].Food_weight_total * nightFoods[i].Food_price / (tableNumber_noon + tableNumber_night), 1, MidpointRounding.AwayFromZero);
                        //修改重量
                        nightFoods[i].Food_weight_total = d_weight;
                        //加上现在的钱
                        realTimeMoney = realTimeMoney + Math.Round(nightFoods[i].Food_weight_total * nightFoods[i].Food_price / (tableNumber_noon + tableNumber_night), 1, MidpointRounding.AwayFromZero);

                        //订单号不为空
                        if (!orderNum.Equals("error"))
                        {
                            //更新操作里的数据
                            updateXiuGaiList(1, nightFoods[i], 2, orderNum);
                        }

                        break;
                    }
                }
            }
            //配料
            else if (index == "2")
            {
                //重量发生改变
                for (int i = 0; i < peiLiao.Count(); i++)
                {
                    if (int_id == peiLiao[i].Id)
                    {
                        //先减去原来这个才的钱
                        realTimeMoney = realTimeMoney - Math.Round(peiLiao[i].Food_weight_total * peiLiao[i].Food_price / (tableNumber_noon + tableNumber_night), 1, MidpointRounding.AwayFromZero);
                        //修改重量
                        peiLiao[i].Food_weight_total = d_weight;
                        //加上现在的钱
                        realTimeMoney = realTimeMoney + Math.Round(peiLiao[i].Food_weight_total * peiLiao[i].Food_price / (tableNumber_noon + tableNumber_night), 1, MidpointRounding.AwayFromZero);

                        //订单号不为空
                        if (!orderNum.Equals("error"))
                        {
                            //更新操作里的数据
                            updateXiuGaiList(2, peiLiao[i], 2, orderNum);
                        }

                        break;
                    }
                }
            }
            ExecuteJavascript($"$client.updateRealTimeMoney('{realTimeMoney}')");
        }

        /// <summary>
        /// 桌数变化
        /// </summary>
        private void tableNumChange(object sender, CfrV8HandlerExecuteEventArgs e)
        {
            string param = "";
            if (e.Arguments != null && e.Arguments.Length > 0)
            {
                param = e.Arguments.FirstOrDefault(p => p.IsString).StringValue;
            }
            //取出桌数
            string tableNumStr = param.Split('-')[0];
            int tableNum = Convert.ToInt32(tableNumStr);
            string index = param.Split('-')[1];
            string orderNum = param.Split('-')[2];
            string noonOrNight = param.Split('-')[3];
            realTimeMoney = 0;
            if (noonOrNight.Equals("noon"))
            {
                tableNumber_noon = tableNum;

            }
            else
            {
                tableNumber_night = tableNum;
            }
            
            //更新午宴菜品总重量
            for (int i = 0; i < noonFoods.Count(); i++)
            {
                noonFoods[i].Food_weight_total = goOne(noonFoods[i].Food_weight_avg * tableNumber_noon);
                //顺带算总价
                realTimeMoney = realTimeMoney + Math.Round(noonFoods[i].Food_weight_total * noonFoods[i].Food_price / (tableNumber_noon+ tableNumber_night), 1, MidpointRounding.AwayFromZero);

                //订单号不为空
                if (!orderNum.Equals("error"))
                {
                    //更新操作里的数据
                    updateXiuGaiList(0, noonFoods[i], 2, orderNum);
                }
            }
            //更新晚宴菜品总重量
            for (int i = 0; i < nightFoods.Count(); i++)
            {
                nightFoods[i].Food_weight_total = goOne(nightFoods[i].Food_weight_avg * tableNumber_night);
                //订单号不为空
                if (!orderNum.Equals("error"))
                {
                    //更新操作里的数据
                    updateXiuGaiList(1, nightFoods[i], 2, orderNum);
                }
                //顺带算总价
                realTimeMoney = realTimeMoney + Math.Round(nightFoods[i].Food_weight_total * nightFoods[i].Food_price / (tableNumber_noon + tableNumber_night), 1, MidpointRounding.AwayFromZero);
            }
            //配料算总计
            for (int i = 0; i < peiLiao.Count(); i++)
            {
                realTimeMoney = realTimeMoney + Math.Round(peiLiao[i].Food_weight_total * peiLiao[i].Food_price / (tableNumber_noon + tableNumber_night), 1, MidpointRounding.AwayFromZero);
            }
            //判断当前显示的是午宴还是晚宴（当前显示的实时刷新）
            if (index.Equals("0"))
            {
                string noonFoodsJson = JsonConvert.SerializeObject(noonFoods);
                ExecuteJavascript($"$client.foodsToRight('{noonFoodsJson + "-" + 0}')");
            }
            else
            {
                string nightFoodsJson = JsonConvert.SerializeObject(nightFoods);
                ExecuteJavascript($"$client.foodsToRight('{nightFoodsJson + "-" + 1}')");
            }
            ExecuteJavascript($"$client.updateRealTimeMoney('{realTimeMoney}')");
        }

        /// <summary>
        /// 保存开账儿的菜
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void printMenu(object sender, CfrV8HandlerExecuteEventArgs e)
        {
            var json = "";
            if (e.Arguments != null && e.Arguments.Length > 0)
            {
                json = e.Arguments.FirstOrDefault(p => p.IsString).StringValue;
            }

            JObject msg = (JObject)JsonConvert.DeserializeObject(json);
            //前台获取的客户信息
            string orderNum = msg["OrderNum"].ToString();
            string name = msg["Shopper_Name"].ToString();
            string data = msg["DateToEat"].ToString();

            
            //判断是否是新的订单
            if (orderNum != null && orderNum != "")
            {
                //更新
                bool isSuccess = foodListService.updateKaiZhang(name, data, orderNum, tableNumber_noon+"/"+ tableNumber_night, addOrDelFoods);
                if (!isSuccess)
                {
                    //保存失败，反回到前台提示用户
                    //MessageBox.Show("修改失败");
                    ExecuteJavascript($"$client.printError('{"修改失败"}')");
                    return;
                }
            }
            else
            {
                Random rad = new Random();//实例化随机数产生器rad；
                int value = rad.Next(100000, 1000000);//用rad生成大于等于1000，小于等于9999的随机数；
                //生产orderNumber
                orderNum = DateTime.Now.ToString("yyyyMMddHHmmssfff") + value;
                //新增
                bool isSuccess = foodListService.insertKaiZhang(name, data,orderNum, tableNumber_noon + "/" + tableNumber_night, noonFoods,nightFoods, peiLiao);
                if (!isSuccess)
                {
                    //保存失败，反回到前台提示用户
                    //MessageBox.Show("保存失败");
                    ExecuteJavascript($"$client.printError('{"保存失败"}')");
                    return;
                }
            }
            //生成Excel
            //exportExcel(orderNum);
            //刷新orderNum
            ExecuteJavascript($"$client.updateOrderNum('{orderNum}')");
            
            //刷新开账列表
            addListOfAccounts(0, pageCount, 2);
            //清空结算菜单，右边所选的东西
            ExecuteJavascript($"$client.clearRightListOfAccounts()");
            //刷新结算菜单
            addListOfAccounts(0, pageCount, 1);
            //保存前的操作清空
            addOrDelFoods.Clear();
            
        }

        /// <summary>
        /// 后台清空所有开账的有关信息
        /// </summary>
        private void clearKaiZhangInfos()
        {
            noonFoods.Clear();
            nightFoods.Clear();
            peiLiao.Clear();
            addOrDelFoods.Clear();
            tableNumber_noon = 0;
            tableNumber_night = 0;
            realTimeMoney = 0;
        }

        /// <summary>
        /// //根据orderNum获取开账的详细信息
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void getKaiZhangInfos(object sender, CfrV8HandlerExecuteEventArgs e)
        {
            string orderNum = "";
            if (e.Arguments != null && e.Arguments.Length > 0)
            {
                orderNum = e.Arguments.FirstOrDefault(p => p.IsString).StringValue;
            }
            if (!orderNum.Equals(string.Empty))
            {
                //后台清空所有开账的有关信息
                clearKaiZhangInfos();
                //封装中午、晚上、配料，桌数，单桌估价
                string tableNumber = foodListService.getTableNumByOrderNum(orderNum);
                int tableNum = 0;
                if (tableNumber.Split('/').Length<2)
                {
                    tableNum = Convert.ToInt32(tableNumber.Split('/')[0]);
                }
                else
                {
                    tableNumber_noon = Convert.ToInt32(tableNumber.Split('/')[0]);
                    tableNumber_night = Convert.ToInt32(tableNumber.Split('/')[1]);
                    tableNum = tableNumber_noon + tableNumber_night;
                }
                
                realTimeMoney = foodListService.getFoodListInfos(noonFoods,nightFoods,peiLiao, tableNum, orderNum);
                noonFoods.Sort(new FoodComparer());
                //午宴序列化成json
                string noonFoodsJson = JsonConvert.SerializeObject(noonFoods);
                ExecuteJavascript($"$client.foodsToRight('{noonFoodsJson + "-" + 0}')");
                peiLiao.Sort(new FoodComparer());
                //配料序列化
                string peiLiaoJson = JsonConvert.SerializeObject(peiLiao);
                ExecuteJavascript($"$client.foodsToRight('{peiLiaoJson + "-" + 2}')");
                nightFoods.Sort(new FoodComparer());
                //单桌估计显示给用户
                ExecuteJavascript($"$client.updateRealTimeMoney('{realTimeMoney}')");
            }
        }

        /// <summary>
        /// 点击某个菜单分组则到后台取相应的分组的东西（开账用）
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void getMoreKZShopper(object sender, CfrV8HandlerExecuteEventArgs e)
        {
            string shopperCountStr = "";
            if (e.Arguments != null && e.Arguments.Length > 0)
            {
                shopperCountStr = e.Arguments.FirstOrDefault(p => p.IsString).StringValue;
            }
            int pageStare = Convert.ToInt32(shopperCountStr);
            List<Shopper> shoppers = shopperService.getShopper(pageStare, pageCount,2);
            string moreShoppers = JsonConvert.SerializeObject(shoppers);
            ExecuteJavascript($"$client.addMoreKZShoppersToList('{moreShoppers}')");
        }

       private string getTypeInfo(int type)
        {
            if (type == 1)
            {
                return "冷盘";
            }
            else if (type == 2)
            {
                return "热炒";
            }
            else if (type == 3)
            {
                return "大菜";
            }
            else if (type == 4)
            {
                return "点心";
            }
            else if (type == 5)
            {
                return "配料";
            }
            else if (type == 6)
            {
                return "蔬菜";
            }
            else
            {
                return "水果";
            }
        }

        /// <summary>
        /// 写excel时获取小标题
        /// </summary>
        /// <param name="food"></param>
        /// <returns></returns>
        private string getStartStr(Foods food)
        {
            string result = string.Empty;
            if (food.FromSource == 0)
            {
                result = "午宴"+ getTypeInfo(food.Diy_type);
            }else if (food.FromSource == 1)
            {
                result = "晚宴" + getTypeInfo(food.Diy_type);
            }
            else
            {
                result = getTypeInfo(food.Diy_type) + ":";
            }
            return result;
        }

        /// <summary>
        /// 开账，写成excel
        /// </summary>
        /// <param name="orderNum"></param>
        private void exportExcel(object sender, CfrV8HandlerExecuteEventArgs e)
        {
            string orderNum = "";
            if (e.Arguments != null && e.Arguments.Length > 0)
            {
                orderNum = e.Arguments.FirstOrDefault(p => p.IsString).StringValue;
            }
            try
            {
                //自动获取桌面路径，拼接文件夹名称
                string path = System.Environment.GetFolderPath(System.Environment.SpecialFolder.Desktop)+ "\\菜单&账单\\开账\\";
                //判断文件夹是都存在，不存在创建
                if (!Directory.Exists(path))
                {
                    DirectoryInfo directoryInfo = new DirectoryInfo(path);
                    directoryInfo.Create();
                }

                HSSFWorkbook workbook = new HSSFWorkbook();
                ISheet sheet = workbook.CreateSheet("mySheet");
                //页眉中间
                sheet.Header.Center = @"&22 姚军南北货批发";
                //页脚右侧
                sheet.Footer.Right = "手机：13813789012  手机：13646281358";
                //页脚左侧
                sheet.Footer.Left = "地址：林梓金盛农贸市场姚军南北货批发";
                //样式1，垂直居中，自动换行
                ICellStyle style1 = workbook.CreateCellStyle();
                style1.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.CENTER;//【Center】垂直居中  
                style1.WrapText = true;
                //设置字体16号
                IFont font16 = workbook.CreateFont();
                font16.FontHeightInPoints = 16;
                //样式2，水平垂直居中，自动换行
                ICellStyle style2 = workbook.CreateCellStyle();
                style2.Alignment = NPOI.SS.UserModel.HorizontalAlignment.CENTER_SELECTION;//【Center】水平居中  
                style2.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.CENTER;//【Center】垂直居中  
                style2.SetFont(font16);//HEAD 样式
                style2.WrapText = true;
                //设置字体14号加粗
                IFont font14 = workbook.CreateFont();
                font14.FontHeightInPoints = 14;
                font14.Boldweight = (short)NPOI.SS.UserModel.FontBoldWeight.BOLD;
                //样式1，垂直居中，自动换行，14号字加粗
                ICellStyle style3 = workbook.CreateCellStyle();
                style3.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.CENTER;//【Center】垂直居中  
                style3.SetFont(font14);//HEAD 样式
                style3.WrapText = true;
                //字体，12号字
                IFont font = workbook.CreateFont();
                font.FontHeightInPoints = 12;
                //样式1和样式2都是用
                style1.SetFont(font);
                //创建行的集合
                Dictionary<int, IRow> rows = new Dictionary<int, IRow>();
                //创建第0行
                IRow row0 = sheet.CreateRow(0);
                //设置行高
                row0.Height = 30 * 20;
                //放入行的集合
                rows.Add(0, row0);
                //算上第0行，这里一共创建了60行
                for (int i=1;i<60;i++)
                {
                    rows.Add(i, sheet.CreateRow(i));
                }
                //根据订单号获取顾客信息
                Shopper s = getShopper(orderNum);
                //文件名
                string excelPath = path + s.Shopper_Name + "-" + s.DateToEat + "请客(菜单).xls";
                FileInfo file = new FileInfo(excelPath);
                if (file.Exists)     //判断文件是否已经存在,如果存在就删除!  
                {
                    //存在则判断有没有打开
                    if (CommonsUtil.FileIsUsed(excelPath))
                    {
                        //打开着弹出框提醒
                        MessageBox.Show("文件在被另一个程序使用，请先将其关闭");
                        return;
                    }
                    else
                    {
                        //没有打开，删除
                        file.Delete();
                    }
                }
                //一页显示42行
                int pageTotal = 42;
                //封装顾客信息，准备写到第一行
                string noon = s.Shopper_tableNum.Split('/')[0];
                string night = s.Shopper_tableNum.Split('/')[1];
                string shopperInfo = "姓名：" + s.Shopper_Name + "   午宴：" + noon + "桌" + "   晚宴："+ night+ "   " + s.DateToEat + "请客";
                //合并单元格，CellRangeAddress有4个参数：起始行号，终止行号， 起始列号，终止列号
                CellRangeAddress cellRangeAddress = new CellRangeAddress(0, 0, 0, 7);
                //合并的单元格添加到sheet中
                sheet.AddMergedRegion(cellRangeAddress);
                //第0行第0列，写入用户信息
                rows[0].CreateCell(0).SetCellValue(shopperInfo);  //在第1行中创建单元格
                //用的样式2
                rows[0].GetCell(0).CellStyle = style2;
                string[] str = new string[2];
                str[0] = "菜名";
                str[1] = "数量";
                //从0开始第一行放入  菜名 数量
                addCellAndSetValue(rows[1], 0, str, style1);
                
                //将所有选择的菜放到同一个集合中，之前已经按照冷盘，热炒等排序过，所以直接用
                List<Foods> foods = new List<Foods>();
                foods.AddRange(noonFoods);
                foods.AddRange(nightFoods);
                foods.AddRange(peiLiao);
                if (foods.Count()>0)
                {
                    //从0开始第2行放入 午宴冷盘或午宴。。晚宴冷盘。。配料等其中一个
                    rows[2].CreateCell(0).SetCellValue(getStartStr(foods[0]));
                    //使用样式
                    rows[2].GetCell(0).CellStyle = style3;
                }
                else
                {
                    MessageBox.Show("啥都没有，不能写入");
                    return;
                }

                //行
                int hang = 3;
                //基础列
                int jiLie = 0;
                //开始列
                int kaishiLie = 0;

                //用作开始列判断用，只进一次@A(标记)
                int count1 = 0;
                //用作开始列判断用，每新开一列进入一次@A(标记)
                int count2 = 0;

                for (int i = 0; i < foods.Count; i++)
                {
                    //第三竖列从第6列开始（从0开始算）
                    int pageBegin = 6;
                    //总行数/每列的数据数 = 基础列
                    jiLie = hang / pageTotal;
                    if (jiLie == 0)
                    {
                        //基础列为0，那么开始列也为0，只赋值1次
                        //@A
                        if (count1 == 0)
                        {
                            kaishiLie = 0;
                        }
                        count1++;
                    }
                    else if (jiLie != 0)
                    {
                        //基础列不为0时
                        if (hang % pageTotal == 0)//某一列已经到了列尾，开始下一列，每新开一列重新赋值为0
                        {
                            count2 = 0;
                        }
                        if (count2 == 0 && pageBegin == kaishiLie)//如果已经是第三列，则进入下一页，开始列+2=新的开始列
                        {
                            kaishiLie += 2;
                        }
                        else if (count2 == 0 && pageBegin != kaishiLie)//在同一页，开始列+3=新列的开始列
                        {
                            kaishiLie += 3;
                        }
                        count2++;
                    }

                    if (hang % pageTotal == 0 && hang < pageTotal * 3)//如果在第一页，第一行用作写客户信息，要空出来
                    {
                        //空出第一列
                        hang++;
                        addCellAndSetValue(rows[hang % pageTotal], kaishiLie, str, style1);
                        hang++;
                    }
                    else if (hang % pageTotal == 0 && hang >= pageTotal * 3)//出第一页往后的，顶头写
                    {
                        addCellAndSetValue(rows[hang % pageTotal], kaishiLie, str, style1);
                        hang++;
                    }
                    string[] str1 = new string[2];

                    str1[0] = foods[i].Food_name;
                    if (foods[i].Food_weight_total == 0)
                    {
                        str1[1] = "(自备)";
                    }
                    else
                    {
                        str1[1] = foods[i].Food_weight_total + foods[i].Unit;
                    }
                   
                    addCellAndSetValue(rows[hang % pageTotal], kaishiLie, str1, style1);
                    hang++;
                    if ((i + 1) < foods.Count)
                    {
                        //如果上一个与下一个的种类不同
                        if (foods[i].Diy_type != foods[i + 1].Diy_type)
                        {
                            //与上一行空一行(如果正好到最低下就不空一格)
                            if (hang % pageTotal != 0)
                            {
                                hang++;
                            }
                            
                            //判断是否要换列（与上面同样）
                            jiLie = hang / pageTotal;
                            if (jiLie == 0)
                            {
                                if (count1 == 0)
                                {
                                    kaishiLie = 0;
                                }
                                count1++;
                            }
                            else if (jiLie != 0)
                            {
                                if (hang % pageTotal == 0)
                                {
                                    count2 = 0;
                                }
                                if (count2 == 0 && pageBegin == kaishiLie)//如果已经是第三列，则进入下一页，开始列+2=新的开始列
                                {
                                    kaishiLie += 2;
                                }
                                else if (count2 == 0 && pageBegin != kaishiLie)//在同一页，开始列+3=新列的开始列
                                {
                                    kaishiLie += 3;
                                }
                                count2++;
                            }
                            //判断是否是第一页
                            if (hang % pageTotal == 0 && hang < pageTotal * 3)
                            {
                                hang++;
                                addCellAndSetValue(rows[hang % pageTotal], kaishiLie, str, style1);
                                hang++;
                            }
                            else if (hang % pageTotal == 0 && hang >= pageTotal * 3)
                            {
                                addCellAndSetValue(rows[hang % pageTotal], kaishiLie, str, style1);
                                hang++;
                            }
                            str1[0] = getStartStr(foods[i+1]);
                            str1[1] = "";
                            
                            addCellAndSetValue(rows[hang % pageTotal], kaishiLie, str1, style3);


                            hang++;
                        }
                    }

                }
                int count = 0;
                if ((kaishiLie + 2) <= 8)
                {
                    count = 8;
                }
                else
                {
                    count = kaishiLie + 2;
                }
                //设置列宽
                for (int i = 0; i < count; i++)
                {
                    if (i == 2 || i==5 || i == 10 || i == 13)
                    {
                        sheet.SetColumnWidth(i, 5 * 256);
                    }else
                    {
                        sheet.SetColumnWidth(i, 13 * 256);
                    }
                    
                }

                using (FileStream fs = File.OpenWrite(excelPath)) //打开一个xls文件，如果没有则自行创建，如果存在myxls.xls文件则在创建是不要打开该文件！
                {
                    workbook.Write(fs);   //向打开的这个xls文件中写入mySheet表并保存。
                                    //MessageBox.Show("发货单写入完毕");
                }
                System.Threading.Thread.Sleep(1000);
            }
            finally
            {
                ExecuteJavascript($"$client.hideWatting()");
            }
        }

        /// <summary>
        /// 获取详细信息
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void getMainDishById(object sender, CfrV8HandlerExecuteEventArgs e)
        {
            string idstr = "";
            if (e.Arguments != null && e.Arguments.Length > 0)
            {
                idstr = e.Arguments.FirstOrDefault(p => p.IsString).StringValue;
            }
            int id = Convert.ToInt32(idstr.Split('-')[1]);

            Dishes dish = dishService.getDishesById(id);

            string dishJson = JsonConvert.SerializeObject(dish);
            ExecuteJavascript($"$client.addMainDishToRight('{dishJson}')");
        }

        private string getTypeHTMLid(int type)
        {
            if (type == 1)
            {
                return "cf-cf_xg";
            }
            else if (type == 2)
            {
                return "hf-hf_xg";
            }
            else if (type == 3)
            {
                return "mf-mf_xg";
            }
            else if (type == 4)
            {
                return "sgdx-sgdx_xg";
            }
            else if (type == 5)
            {
                return "pl-pl_xg";
            }
            else if (type == 6)
            {
                return "sc-sc_xg";
            }
            else
            {
                return "sg-sg_xg";
            }
        }

        /// <summary>
        /// 菜品添加到数据库
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void addFoodToDB(object sender, CfrV8HandlerExecuteEventArgs e)
        {
            string jsonStr = "";
            if (e.Arguments != null && e.Arguments.Length > 0)
            {
                jsonStr = e.Arguments.FirstOrDefault(p => p.IsString).StringValue;
            }
            JObject msg = (JObject)JsonConvert.DeserializeObject(jsonStr);

            string name = msg["name"].ToString();
            int mainId = Convert.ToInt32(msg["mainId"].ToString());
            int foodKind = Convert.ToInt32(msg["foodKind"].ToString());
            double unitPrice = Convert.ToDouble(msg["unitPrice"].ToString());
            double weightAvg = Convert.ToDouble(msg["weightAvg"].ToString());
            Foods food = foodsService.getFoodsByNameAndKind(name, foodKind, mainId);

            if (food != null)//名字相同，类型相同，主料相同
            {
                foodsService.updateFood(name, foodKind, mainId, unitPrice,weightAvg);
                //刷新菜品
                //getOneKindFoods(getTypeHTMLid(foodKind).Split('-')[0]);
                //this.getOneKindFood_XG(getTypeHTMLid(foodKind).Split('-')[1]);
                ExecuteJavascript($"$client.clearModifyPage('{"2-"+ foodKind}')");
            }
            else
            {
                //添加菜品
                foodsService.insertFood(name, foodKind, mainId, unitPrice, weightAvg);
                //刷新菜品
                //getOneKindFoods(getTypeHTMLid(foodKind).Split('-')[0]);
                //this.getOneKindFood_XG(getTypeHTMLid(foodKind).Split('-')[1]);
                ExecuteJavascript($"$client.clearModifyPage('{"2-" + foodKind}')");
            }
            
        }

        /// <summary>
        /// 取出要修改的商品
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dishShowToModifyPage(object sender, CfrV8HandlerExecuteEventArgs e)
        {
            string idStr = "";
            if (e.Arguments != null && e.Arguments.Length > 0)
            {
                idStr = e.Arguments.FirstOrDefault(p => p.IsString).StringValue;
            }
            int id = Convert.ToInt32(idStr);

            Dishes dish = dishService.getDishesById(id);

            string dishJson = JsonConvert.SerializeObject(dish);
            ExecuteJavascript($"$client.showDishToModifyPage('{dishJson}')");
            //根据Id查找菜品里面，有没有用该商品做主料的
            List<Foods> foods = foodListService.getFoodsByMainId(id);
            string foodsJson = JsonConvert.SerializeObject(foods);
            ExecuteJavascript($"$client.dishContactShow('{foodsJson}')");

        }

        /// <summary>
        /// 修改的商品
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void updateDishToDB(object sender, CfrV8HandlerExecuteEventArgs e)
        {
            string jsonStr = "";
            if (e.Arguments != null && e.Arguments.Length > 0)
            {
                jsonStr = e.Arguments.FirstOrDefault(p => p.IsString).StringValue;
            }
            JObject msg = (JObject)JsonConvert.DeserializeObject(jsonStr);

            string name = msg["name"].ToString();
            int kind = Convert.ToInt32(msg["kind"].ToString());
            int id = Convert.ToInt32(msg["id"].ToString());
            string unit = msg["unit"].ToString();

            dishService.updatDish(id, kind, unit,name);

            ExecuteJavascript($"$client.clearModifyPage('{"1-no"}')");

        }

        /// <summary>
        /// 取出要修改的菜品
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void foodShowToModifyPage(object sender, CfrV8HandlerExecuteEventArgs e)
        {
            string idStr = "";
            if (e.Arguments != null && e.Arguments.Length > 0)
            {
                idStr = e.Arguments.FirstOrDefault(p => p.IsString).StringValue;
            }
            int id = Convert.ToInt32(idStr);

            Foods food = foodsService.getFoodsInfoByID(id);

            string foodJson = JsonConvert.SerializeObject(food);
            ExecuteJavascript($"$client.showFoodToModifyPage('{foodJson}')");

        }

        /// <summary>
        /// 修改的菜品
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void updateFoodToDB(object sender, CfrV8HandlerExecuteEventArgs e)
        {
            string jsonStr = "";
            if (e.Arguments != null && e.Arguments.Length > 0)
            {
                jsonStr = e.Arguments.FirstOrDefault(p => p.IsString).StringValue;
            }
            JObject msg = (JObject)JsonConvert.DeserializeObject(jsonStr);

            string name = msg["name"].ToString();
            int mainId = Convert.ToInt32(msg["mainId"].ToString());
            int foodKind = Convert.ToInt32(msg["foodKind"].ToString());
            double unitPrice = Convert.ToDouble(msg["unitPrice"].ToString());
            double weightAvg = Convert.ToDouble(msg["weightAvg"].ToString());
            int id = Convert.ToInt32(msg["id"].ToString());

            foodsService.updateFood(name, foodKind, mainId, unitPrice, weightAvg,id);

            ExecuteJavascript($"$client.clearModifyPage('{"2-" + foodKind}')");

        }

        /// <summary>
        /// 删除DB中的菜品
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void removeLeftFood(object sender, CfrV8HandlerExecuteEventArgs e)
        {
            var str = "";
            if (e.Arguments != null && e.Arguments.Length > 0)
            {
                str = e.Arguments.FirstOrDefault(p => p.IsString).StringValue;
            }
            //更改状态为0（0删除）
            foodsService.updatFoodById(Convert.ToInt32(str.Split('-')[0]));
            ExecuteJavascript($"$client.clearModifyPage('{"2-" + str.Split('-')[1]}')");
        }

        /// <summary>
        /// 搜索菜品
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void searchFoods(object sender, CfrV8HandlerExecuteEventArgs e)
        {
            var str = "";
            if (e.Arguments != null && e.Arguments.Length > 0)
            {
                str = e.Arguments.FirstOrDefault(p => p.IsString).StringValue;
            }
            //模糊查询操作
            List<Foods> foods = foodsService.getFoodByLike(str.ToUpper());
            string foodsJson = JsonConvert.SerializeObject(foods);
            ExecuteJavascript($"$client.searchFoodsResult('{foodsJson}')");

        }
    }
}
