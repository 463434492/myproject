/*
Navicat MySQL Data Transfer

Source Server         : 192.168.31.52
Source Server Version : 50725
Source Host           : 192.168.31.52:3306
Source Database       : menu

Target Server Type    : MYSQL
Target Server Version : 50725
File Encoding         : 65001

Date: 2020-09-17 22:56:22
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for commodity
-- ----------------------------
DROP TABLE IF EXISTS `commodity`;
CREATE TABLE `commodity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL COMMENT '商品名称',
  `unitId` int(11) DEFAULT NULL COMMENT '默认单位',
  `initial` varchar(10) DEFAULT NULL COMMENT '首字母',
  `status` int(11) DEFAULT '1' COMMENT '状态：0删除，1正常',
  PRIMARY KEY (`id`),
  KEY `idx_name_initial` (`name`,`initial`)
) ENGINE=InnoDB AUTO_INCREMENT=539 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of commodity
-- ----------------------------
INSERT INTO `commodity` VALUES ('1', '牛肉', '1', 'NR', '1');
INSERT INTO `commodity` VALUES ('2', '羊肉', '1', 'YR', '1');
INSERT INTO `commodity` VALUES ('3', '开心果', '2', 'KXG', '1');
INSERT INTO `commodity` VALUES ('4', '海蜇头', '1', 'HZT', '1');
INSERT INTO `commodity` VALUES ('5', '海蜇丝', '1', 'HZS', '1');
INSERT INTO `commodity` VALUES ('6', '杏仁', '2', 'XR', '1');
INSERT INTO `commodity` VALUES ('7', '腰果', '1', 'YG', '1');
INSERT INTO `commodity` VALUES ('8', '黄桃', '3', 'HT', '1');
INSERT INTO `commodity` VALUES ('9', '和田红枣', '1', 'HTHZ', '1');
INSERT INTO `commodity` VALUES ('10', '京藕', '3', 'JO', '1');
INSERT INTO `commodity` VALUES ('11', '金针菇', '5', 'JZG', '1');
INSERT INTO `commodity` VALUES ('12', '脆笋片', '5', 'CSP', '1');
INSERT INTO `commodity` VALUES ('13', '龙田杨', '12', 'LTY', '1');
INSERT INTO `commodity` VALUES ('14', '雪花排条', '5', 'XHPT', '1');
INSERT INTO `commodity` VALUES ('15', '风香鸭', '1', 'FXY', '1');
INSERT INTO `commodity` VALUES ('16', '麻油鸭', '1', 'MYY', '1');
INSERT INTO `commodity` VALUES ('17', '酱鸭', '1', 'JY', '1');
INSERT INTO `commodity` VALUES ('18', '舌头', '1', 'ST', '1');
INSERT INTO `commodity` VALUES ('19', '鸭肫', '1', 'YZ', '1');
INSERT INTO `commodity` VALUES ('20', '凤爪', '1', 'FZ', '1');
INSERT INTO `commodity` VALUES ('21', '蚕豆子', '1', 'CDZ', '1');
INSERT INTO `commodity` VALUES ('22', '若候', '1', 'RH', '1');
INSERT INTO `commodity` VALUES ('23', '鱼排', '5', 'YP', '1');
INSERT INTO `commodity` VALUES ('24', '罗汉笋', '2', 'LHS', '1');
INSERT INTO `commodity` VALUES ('25', '螺丝虾', '1', 'LSX', '1');
INSERT INTO `commodity` VALUES ('26', '白虾', '1', 'BX', '1');
INSERT INTO `commodity` VALUES ('27', '万年青', '2', 'WNQ', '1');
INSERT INTO `commodity` VALUES ('28', '金瓜丝', '2', 'JGS', '1');
INSERT INTO `commodity` VALUES ('29', '咸鱼', '1', 'XY', '1');
INSERT INTO `commodity` VALUES ('30', '小黄鱼', '1', 'XHY', '1');
INSERT INTO `commodity` VALUES ('31', '小鲳鱼', '1', 'XCY', '1');
INSERT INTO `commodity` VALUES ('32', '草鸡蛋', '1', 'CJD', '1');
INSERT INTO `commodity` VALUES ('33', '牛肚', '1', 'ND', '1');
INSERT INTO `commodity` VALUES ('34', '金钱肚', '1', 'JQD', '1');
INSERT INTO `commodity` VALUES ('35', '扎蹄', '1', 'ZT', '1');
INSERT INTO `commodity` VALUES ('36', '牛百叶', '1', 'NBX', '1');
INSERT INTO `commodity` VALUES ('37', '牛板肚', '1', 'NBD', '1');
INSERT INTO `commodity` VALUES ('38', '鸭舌', '4', 'YS', '1');
INSERT INTO `commodity` VALUES ('39', '鹌鹑鸟', '6', 'ACN', '1');
INSERT INTO `commodity` VALUES ('40', '黄秋葵', '2', 'HQK', '1');
INSERT INTO `commodity` VALUES ('41', '蛋黄火腿', '2', 'DHHT', '1');
INSERT INTO `commodity` VALUES ('42', '爆鱼', '1', 'BY', '1');
INSERT INTO `commodity` VALUES ('43', '碧根果', '2', 'BGG', '1');
INSERT INTO `commodity` VALUES ('44', '翅中', '1', 'CZ', '1');
INSERT INTO `commodity` VALUES ('45', '绿茶饼', '2', 'LCB', '1');
INSERT INTO `commodity` VALUES ('46', '咸肉', '1', 'XR', '1');
INSERT INTO `commodity` VALUES ('47', '目鱼大烤', '2', 'MYDK', '1');
INSERT INTO `commodity` VALUES ('48', '咸鸭腿', '1', 'XYT', '1');
INSERT INTO `commodity` VALUES ('49', '带鱼', '1', 'DY', '1');
INSERT INTO `commodity` VALUES ('50', '香酥银鱼', '5', 'XSYY', '1');
INSERT INTO `commodity` VALUES ('51', '达仔鱼', '2', 'DZY', '1');
INSERT INTO `commodity` VALUES ('52', '公子鱼', '3', 'GZY', '1');
INSERT INTO `commodity` VALUES ('53', '米兰虾饼', '2', 'MLXB', '1');
INSERT INTO `commodity` VALUES ('54', '海裙菜', '2', 'HQC', '1');
INSERT INTO `commodity` VALUES ('55', '白斩鸡', '1', 'BZJ', '1');
INSERT INTO `commodity` VALUES ('56', '猪肚', '1', 'ZD', '1');
INSERT INTO `commodity` VALUES ('57', '大肠', '1', 'DC', '1');
INSERT INTO `commodity` VALUES ('58', '腰子', '1', 'YZ', '1');
INSERT INTO `commodity` VALUES ('59', '猪肝', '1', 'ZG', '1');
INSERT INTO `commodity` VALUES ('60', '虾仁', '1', 'XR', '1');
INSERT INTO `commodity` VALUES ('61', '长鱼', '1', 'CY', '1');
INSERT INTO `commodity` VALUES ('62', '墨鱼片', '1', 'MYP', '1');
INSERT INTO `commodity` VALUES ('63', '蹄筋', '1', 'TJ', '1');
INSERT INTO `commodity` VALUES ('64', '鱼肚', '1', 'YD', '1');
INSERT INTO `commodity` VALUES ('65', '文蛤', '1', 'WH', '1');
INSERT INTO `commodity` VALUES ('66', '对虾', '1', 'DX', '1');
INSERT INTO `commodity` VALUES ('67', '鸡丁', '1', 'JZ', '1');
INSERT INTO `commodity` VALUES ('68', '扇子骨', '2', 'SZG', '1');
INSERT INTO `commodity` VALUES ('69', '扇软骨', '2', 'SRG', '1');
INSERT INTO `commodity` VALUES ('70', '小鸡腿', '4', 'XJT', '1');
INSERT INTO `commodity` VALUES ('71', '鸽子蛋', '4', 'GZD', '1');
INSERT INTO `commodity` VALUES ('72', '牛排', '1', 'NP', '1');
INSERT INTO `commodity` VALUES ('73', '米线虾', '2', 'MXX', '1');
INSERT INTO `commodity` VALUES ('74', '青蟹', '1', 'QX', '1');
INSERT INTO `commodity` VALUES ('75', '鱼头', '1', 'YT', '1');
INSERT INTO `commodity` VALUES ('76', '湄公鱼', '1', 'MGY', '1');
INSERT INTO `commodity` VALUES ('77', '五花肉', '1', 'WHR', '1');
INSERT INTO `commodity` VALUES ('78', '牛柳', '1', 'NL', '1');
INSERT INTO `commodity` VALUES ('79', '酱鸡腿', '1', 'JJT', '1');
INSERT INTO `commodity` VALUES ('80', '排骨饭', '2', 'PGF', '1');
INSERT INTO `commodity` VALUES ('81', '竹筒肉', '2', 'ZTR', '1');
INSERT INTO `commodity` VALUES ('82', '笑口虾仁', '2', 'XKXR', '1');
INSERT INTO `commodity` VALUES ('83', '香蒲八宝', '2', 'XPBB', '1');
INSERT INTO `commodity` VALUES ('84', '红腰豆', '3', 'HYD', '1');
INSERT INTO `commodity` VALUES ('85', '刀鱼饺', '2', 'DYJ', '1');
INSERT INTO `commodity` VALUES ('86', '走油肉', '1', 'ZYR', '1');
INSERT INTO `commodity` VALUES ('87', '蹄子肉', '1', 'TZR', '1');
INSERT INTO `commodity` VALUES ('88', '稻草扣肉', '5', 'DCKR', '1');
INSERT INTO `commodity` VALUES ('89', '圆蹄', '1', 'YT', '1');
INSERT INTO `commodity` VALUES ('90', '东坡肉', '1', 'DPR', '1');
INSERT INTO `commodity` VALUES ('91', '肉丸', '1', 'RW', '1');
INSERT INTO `commodity` VALUES ('92', '肥牛卷', '2', 'FNJ', '1');
INSERT INTO `commodity` VALUES ('93', '龙利鱼', '1', 'LLY', '1');
INSERT INTO `commodity` VALUES ('94', '黄鱼', '1', 'HY', '1');
INSERT INTO `commodity` VALUES ('95', '鱼皮', '1', 'YP', '1');
INSERT INTO `commodity` VALUES ('96', '桂鱼', '1', 'GY', '1');
INSERT INTO `commodity` VALUES ('97', '鲈鱼', '1', 'LY', '1');
INSERT INTO `commodity` VALUES ('98', '白条鱼', '1', 'BTY', '1');
INSERT INTO `commodity` VALUES ('99', '草鲢鱼', '1', 'CLY', '1');
INSERT INTO `commodity` VALUES ('100', '河鲀鱼', '1', 'HTY', '1');
INSERT INTO `commodity` VALUES ('101', '河蟹', '1', 'HX', '1');
INSERT INTO `commodity` VALUES ('102', '梭子蟹', '1', 'SZX', '1');
INSERT INTO `commodity` VALUES ('103', '斑节虾', '1', 'BJX', '1');
INSERT INTO `commodity` VALUES ('104', '三文鱼', '8', 'SWY', '1');
INSERT INTO `commodity` VALUES ('105', '凤凰传奇', '2', 'FHZQ', '1');
INSERT INTO `commodity` VALUES ('106', '火鸡腿', '2', 'HJT', '1');
INSERT INTO `commodity` VALUES ('107', '竹报平安', '2', 'ZBPA', '1');
INSERT INTO `commodity` VALUES ('108', '甲鱼', '1', 'JY', '1');
INSERT INTO `commodity` VALUES ('109', '燕饺', '1', 'YJ', '1');
INSERT INTO `commodity` VALUES ('110', '米粉排骨', '1', 'MFPG', '1');
INSERT INTO `commodity` VALUES ('111', '大明虾', '4', 'DMX', '1');
INSERT INTO `commodity` VALUES ('112', '鱼翅', '1', 'YC', '1');
INSERT INTO `commodity` VALUES ('113', '牛鞭', '1', 'NB', '1');
INSERT INTO `commodity` VALUES ('114', '中华鲟', '1', 'ZHX', '1');
INSERT INTO `commodity` VALUES ('115', '老母鸡', '1', 'LMJ', '1');
INSERT INTO `commodity` VALUES ('116', '咸肉', '1', 'XR', '1');
INSERT INTO `commodity` VALUES ('117', '蚌', '1', 'B', '1');
INSERT INTO `commodity` VALUES ('118', '紫菜', '2', 'ZC', '1');
INSERT INTO `commodity` VALUES ('119', '鲍鱼', '6', 'BY', '1');
INSERT INTO `commodity` VALUES ('120', '扇贝', '4', 'SB', '1');
INSERT INTO `commodity` VALUES ('121', '排骨', '1', 'PG', '1');
INSERT INTO `commodity` VALUES ('122', '鳗鱼', '1', 'MY', '1');
INSERT INTO `commodity` VALUES ('123', '牛排骨', '1', 'NPG', '1');
INSERT INTO `commodity` VALUES ('124', '金芋紫薯', '5', 'JYZS', '1');
INSERT INTO `commodity` VALUES ('125', '香酥饼', '4', 'XSB', '1');
INSERT INTO `commodity` VALUES ('126', '鳕鱼排', '4', 'XYP', '1');
INSERT INTO `commodity` VALUES ('127', '百年好合', '2', 'BNHG', '1');
INSERT INTO `commodity` VALUES ('128', '步步糕', '2', 'BBG', '1');
INSERT INTO `commodity` VALUES ('129', '小米糕', '2', 'XMG', '1');
INSERT INTO `commodity` VALUES ('130', '黄桥烧饼', '4', 'HQSB', '1');
INSERT INTO `commodity` VALUES ('131', '金瓜卷', '2', 'JGJ', '1');
INSERT INTO `commodity` VALUES ('132', '水晶包', '4', 'SJB', '1');
INSERT INTO `commodity` VALUES ('133', '鸦片鱼', '1', 'YPY', '1');
INSERT INTO `commodity` VALUES ('134', '奶黄包', '2', 'NHB', '1');
INSERT INTO `commodity` VALUES ('135', '小刀切', '2', 'XDQ', '1');
INSERT INTO `commodity` VALUES ('136', '鲳鳊鱼', '1', 'CBY', '1');
INSERT INTO `commodity` VALUES ('137', '金色年华', '2', 'JSNH', '1');
INSERT INTO `commodity` VALUES ('138', '肉松卷', '2', 'RSJ', '1');
INSERT INTO `commodity` VALUES ('139', '紫薯玫瑰', '2', 'ZSMG', '1');
INSERT INTO `commodity` VALUES ('140', '芝麻球', '2', 'ZMQ', '1');
INSERT INTO `commodity` VALUES ('141', '鮰鱼', '1', 'HY', '1');
INSERT INTO `commodity` VALUES ('142', '杂粮饼', '2', 'ZLB', '1');
INSERT INTO `commodity` VALUES ('143', '椒盐', '3', 'JY', '1');
INSERT INTO `commodity` VALUES ('144', '金优醋', '3', 'JYC', '1');
INSERT INTO `commodity` VALUES ('145', '红糖', '2', 'HT', '1');
INSERT INTO `commodity` VALUES ('146', '白糖', '2', 'BT', '1');
INSERT INTO `commodity` VALUES ('147', '剁椒', '3', 'DJ', '1');
INSERT INTO `commodity` VALUES ('148', '耗油', '3', 'HY', '1');
INSERT INTO `commodity` VALUES ('149', '蒸鱼之油', '3', 'ZYZY', '1');
INSERT INTO `commodity` VALUES ('150', '色拉油', '10', 'SLY', '1');
INSERT INTO `commodity` VALUES ('151', '沙拉酱', '3', 'SLJ', '1');
INSERT INTO `commodity` VALUES ('152', '味精', '1', 'WJ', '1');
INSERT INTO `commodity` VALUES ('153', '鸡精', '1', 'JJ', '1');
INSERT INTO `commodity` VALUES ('154', '中萃', '2', 'ZC', '1');
INSERT INTO `commodity` VALUES ('155', '味极鲜', '3', 'WJX', '1');
INSERT INTO `commodity` VALUES ('156', '六月鲜', '3', 'LYX', '1');
INSERT INTO `commodity` VALUES ('157', '鲜上鲜', '3', 'XSX', '1');
INSERT INTO `commodity` VALUES ('158', '麻油', '3', 'MY', '1');
INSERT INTO `commodity` VALUES ('159', '鸡汁', '3', 'JZ', '1');
INSERT INTO `commodity` VALUES ('160', '排骨酱', '3', 'PGJ', '1');
INSERT INTO `commodity` VALUES ('161', '牛肉酱', '3', 'NRJ', '1');
INSERT INTO `commodity` VALUES ('162', '豆瓣酱', '3', 'DBJ', '1');
INSERT INTO `commodity` VALUES ('163', '啤酒鸭料', '3', 'PJYL', '1');
INSERT INTO `commodity` VALUES ('164', '川香辣酱', '3', 'CXLJ', '1');
INSERT INTO `commodity` VALUES ('165', '甜面酱', '3', 'TMJ', '1');
INSERT INTO `commodity` VALUES ('166', '黄豆酱', '3', 'HDJ', '1');
INSERT INTO `commodity` VALUES ('167', '丘比沙拉', '3', 'QBSL', '1');
INSERT INTO `commodity` VALUES ('168', '蓝莓酱', '3', 'LMJ', '1');
INSERT INTO `commodity` VALUES ('169', '餐巾纸', '2', 'CJZ', '1');
INSERT INTO `commodity` VALUES ('170', '桌围', '2', 'ZW', '1');
INSERT INTO `commodity` VALUES ('171', '号簿', '11', 'HB', '1');
INSERT INTO `commodity` VALUES ('172', '水煮鱼料', '2', 'SZYL', '1');
INSERT INTO `commodity` VALUES ('173', '酸菜鱼料', '2', 'SCYL', '1');
INSERT INTO `commodity` VALUES ('174', '粉丝', '2', 'FS', '1');
INSERT INTO `commodity` VALUES ('175', '鸟蛋', '1', 'ND', '1');
INSERT INTO `commodity` VALUES ('176', '鸡蛋', '1', 'JD', '1');
INSERT INTO `commodity` VALUES ('177', '进口生粉', '2', 'JKSF', '1');
INSERT INTO `commodity` VALUES ('178', '普通生粉', '2', 'PTSF', '1');
INSERT INTO `commodity` VALUES ('179', '番薯粉', '1', 'PSF', '1');
INSERT INTO `commodity` VALUES ('180', '海带', '1', 'HD', '1');
INSERT INTO `commodity` VALUES ('181', '蜜枣', '1', 'MZ', '1');
INSERT INTO `commodity` VALUES ('182', '香菇', '1', 'XG', '1');
INSERT INTO `commodity` VALUES ('183', '豆腐皮 ', '1', 'DFP ', '1');
INSERT INTO `commodity` VALUES ('184', '方肉', '4', 'FR', '1');
INSERT INTO `commodity` VALUES ('185', '腐竹', '1', 'FZ', '1');
INSERT INTO `commodity` VALUES ('186', '百合', '7', 'BG', '1');
INSERT INTO `commodity` VALUES ('187', '大海参', '1', 'DHC', '1');
INSERT INTO `commodity` VALUES ('188', '基围虾', '1', 'JWX', '1');
INSERT INTO `commodity` VALUES ('189', '鸡脚爪', '1', 'JJZ', '1');
INSERT INTO `commodity` VALUES ('190', '三黄鸡', '6', 'SHJ', '1');
INSERT INTO `commodity` VALUES ('191', '澳龙', '6', 'AL', '1');
INSERT INTO `commodity` VALUES ('192', '鲜豆腐皮', '9', 'XDFP', '1');
INSERT INTO `commodity` VALUES ('193', '喜多多', '3', 'XDD', '1');
INSERT INTO `commodity` VALUES ('194', '花生汤', '3', 'HST', '1');
INSERT INTO `commodity` VALUES ('195', '冰激凌', '2', 'BJL', '1');
INSERT INTO `commodity` VALUES ('196', '粗粮卷', '4', 'CLJ', '1');
INSERT INTO `commodity` VALUES ('197', '榨菜', '2', 'ZC', '1');
INSERT INTO `commodity` VALUES ('198', '冬笋', '1', 'DS', '1');
INSERT INTO `commodity` VALUES ('199', '杂烩', '1', 'ZH', '1');
INSERT INTO `commodity` VALUES ('200', '烧鸡公', '2', 'SJG', '1');
INSERT INTO `commodity` VALUES ('201', '肉松', '2', 'RS', '1');
INSERT INTO `commodity` VALUES ('202', '松子', '1', 'SZ', '1');
INSERT INTO `commodity` VALUES ('203', '火锅底料', '2', 'HGDL', '1');
INSERT INTO `commodity` VALUES ('204', '豆腐', '4', 'DF', '1');
INSERT INTO `commodity` VALUES ('205', '茶干', '1', 'CG', '1');
INSERT INTO `commodity` VALUES ('206', '鲫鱼', '1', 'JY', '1');
INSERT INTO `commodity` VALUES ('207', '莲子糕', '2', 'LZG', '1');
INSERT INTO `commodity` VALUES ('208', '西瓜', '1', 'XG', '1');
INSERT INTO `commodity` VALUES ('209', '黄酒', '2', 'HJ', '1');
INSERT INTO `commodity` VALUES ('210', '鱼腐', '1', 'YF', '1');
INSERT INTO `commodity` VALUES ('211', '蟹黄鱼圆', '2', 'XHYY', '1');
INSERT INTO `commodity` VALUES ('212', '哈密瓜', '1', 'HMG', '1');
INSERT INTO `commodity` VALUES ('213', '桂圆', '1', 'GY', '1');
INSERT INTO `commodity` VALUES ('214', '荔枝', '1', 'LZ', '1');
INSERT INTO `commodity` VALUES ('215', '葡萄', '1', 'PT', '1');
INSERT INTO `commodity` VALUES ('216', '江糟', '3', 'JZ', '1');
INSERT INTO `commodity` VALUES ('217', '酒酿', '3', 'JN', '1');
INSERT INTO `commodity` VALUES ('218', '白煤', '1', 'BM', '1');
INSERT INTO `commodity` VALUES ('219', '仔排骨', '1', 'ZPG', '1');
INSERT INTO `commodity` VALUES ('220', '吉士粉', '3', 'JSF', '1');
INSERT INTO `commodity` VALUES ('221', '雪芽', '3', 'XY', '1');
INSERT INTO `commodity` VALUES ('222', '锅巴', '2', 'GB', '1');
INSERT INTO `commodity` VALUES ('223', '伴侣', '8', 'BL', '1');
INSERT INTO `commodity` VALUES ('224', '咸蛋黄', '5', 'XDH', '1');
INSERT INTO `commodity` VALUES ('225', '银鱼', '1', 'YY', '1');
INSERT INTO `commodity` VALUES ('226', '土豆粉', '1', 'TDF', '1');
INSERT INTO `commodity` VALUES ('227', '蒜头', '1', 'ST', '1');
INSERT INTO `commodity` VALUES ('228', '蔬菜', '8', 'SC', '1');
INSERT INTO `commodity` VALUES ('229', '梅干菜', '2', 'MGC', '1');
INSERT INTO `commodity` VALUES ('230', '绞工', '8', 'JG', '1');
INSERT INTO `commodity` VALUES ('231', '虾糕', '1', 'XG', '1');
INSERT INTO `commodity` VALUES ('232', '金榜鱿鱼', '2', 'JBYY', '1');
INSERT INTO `commodity` VALUES ('233', '蛏', '2', 'C', '1');
INSERT INTO `commodity` VALUES ('234', '榨豆瓣', '2', 'ZDB', '1');
INSERT INTO `commodity` VALUES ('235', '包肉', '1', 'BR', '1');
INSERT INTO `commodity` VALUES ('236', '千页豆付', '2', 'QYDF', '1');
INSERT INTO `commodity` VALUES ('237', '面包糠', '2', 'MBK', '1');
INSERT INTO `commodity` VALUES ('238', '笋丝', '2', 'SS', '1');
INSERT INTO `commodity` VALUES ('239', '小炒鲜', '3', 'XCX', '1');
INSERT INTO `commodity` VALUES ('240', '老干妈', '3', 'LGM', '1');
INSERT INTO `commodity` VALUES ('241', 'Q牛肚', '2', 'QND', '1');
INSERT INTO `commodity` VALUES ('242', '白果', '2', 'BG', '1');
INSERT INTO `commodity` VALUES ('243', '榨安头', '1', 'ZAT', '1');
INSERT INTO `commodity` VALUES ('244', '肚肺', '4', 'DF', '1');
INSERT INTO `commodity` VALUES ('245', '大川', '3', 'DC', '1');
INSERT INTO `commodity` VALUES ('246', '野菜锅巴', '2', 'YCGB', '1');
INSERT INTO `commodity` VALUES ('247', '肴水肉', '1', 'YSR', '1');
INSERT INTO `commodity` VALUES ('248', '大对虾', '1', 'DDX', '1');
INSERT INTO `commodity` VALUES ('249', '大花', '4', 'DH', '1');
INSERT INTO `commodity` VALUES ('250', '海苔卷', '2', 'HTJ', '1');
INSERT INTO `commodity` VALUES ('251', '日本豆腐', '4', 'RBDF', '1');
INSERT INTO `commodity` VALUES ('252', '葱花肉排', '2', 'CHRP', '1');
INSERT INTO `commodity` VALUES ('253', '牛角花', '2', 'NJH', '1');
INSERT INTO `commodity` VALUES ('254', '野山菌', '2', 'YSJ', '1');
INSERT INTO `commodity` VALUES ('255', '竹尖', '4', 'ZJ', '1');
INSERT INTO `commodity` VALUES ('256', '老抽', '3', 'LC', '1');
INSERT INTO `commodity` VALUES ('257', '蝴蝶鱼', '4', 'HDY', '1');
INSERT INTO `commodity` VALUES ('258', '寸骨', '4', 'CG', '1');
INSERT INTO `commodity` VALUES ('259', '鸡脯', '1', 'JP', '1');
INSERT INTO `commodity` VALUES ('260', '咸蹄', '6', 'XT', '1');
INSERT INTO `commodity` VALUES ('261', '鸡子', '1', 'JZ', '1');
INSERT INTO `commodity` VALUES ('262', '红糖发糕', '2', 'HTFG', '1');
INSERT INTO `commodity` VALUES ('263', '五香', '7', 'WX', '1');
INSERT INTO `commodity` VALUES ('264', '大川', '3', 'DC', '1');
INSERT INTO `commodity` VALUES ('265', '水饺', '1', 'SJ', '1');
INSERT INTO `commodity` VALUES ('266', '银耳', '7', 'YE', '1');
INSERT INTO `commodity` VALUES ('267', '木耳', '7', 'ME', '1');
INSERT INTO `commodity` VALUES ('268', '大虎皮参', '1', 'DHPC', '1');
INSERT INTO `commodity` VALUES ('269', '汤圆', '2', 'TY', '1');
INSERT INTO `commodity` VALUES ('270', '桂花酱', '3', 'GHJ', '1');
INSERT INTO `commodity` VALUES ('271', '固体酒精', '4', 'GTJJ', '1');
INSERT INTO `commodity` VALUES ('272', '果珍', '2', 'GZ', '1');
INSERT INTO `commodity` VALUES ('273', '锡纸', '2', 'XZ', '1');
INSERT INTO `commodity` VALUES ('274', '利蒲玉头', '1', 'LPYT', '1');
INSERT INTO `commodity` VALUES ('275', '猪肉皮', '1', 'ZRP', '1');
INSERT INTO `commodity` VALUES ('276', '水面', '1', 'SM', '1');
INSERT INTO `commodity` VALUES ('277', '肉片', '1', 'RP', '1');
INSERT INTO `commodity` VALUES ('278', '野山椒', '3', 'YSJ', '1');
INSERT INTO `commodity` VALUES ('279', '香酥鸭', '6', 'XSY', '1');
INSERT INTO `commodity` VALUES ('280', '鱿鱼须', '1', 'YYX', '1');
INSERT INTO `commodity` VALUES ('281', '好腰果', '2', 'HYG', '1');
INSERT INTO `commodity` VALUES ('282', '无根耳', '1', 'MGE', '1');
INSERT INTO `commodity` VALUES ('283', '鸭煲', '2', 'YB', '1');
INSERT INTO `commodity` VALUES ('284', '保鲜膜', '4', 'BXM', '1');
INSERT INTO `commodity` VALUES ('285', '红薯干', '1', 'HSG', '1');
INSERT INTO `commodity` VALUES ('286', '多宝鱼', '1', 'DBY', '1');
INSERT INTO `commodity` VALUES ('287', '黑鱼', '1', 'HY', '1');
INSERT INTO `commodity` VALUES ('288', '提子', '1', 'TZ', '1');
INSERT INTO `commodity` VALUES ('289', '玉米肉饺', '4', 'YMRJ', '1');
INSERT INTO `commodity` VALUES ('290', '核桃包', '2', 'HTB', '1');
INSERT INTO `commodity` VALUES ('291', '油条虾', '5', 'YTX', '1');
INSERT INTO `commodity` VALUES ('292', '招财包', '2', 'ZCB', '1');
INSERT INTO `commodity` VALUES ('293', '薯条', '1', 'ST', '1');
INSERT INTO `commodity` VALUES ('294', '尖红椒', '7', 'JHJ', '1');
INSERT INTO `commodity` VALUES ('295', '红绿樱桃', '3', 'HLYT', '1');
INSERT INTO `commodity` VALUES ('296', '冰糖', '1', 'BT', '1');
INSERT INTO `commodity` VALUES ('297', '皮蛋', '4', 'PD', '1');
INSERT INTO `commodity` VALUES ('298', '发菜', '5', 'FC', '1');
INSERT INTO `commodity` VALUES ('299', '海蛰头', '2', 'HZT', '1');
INSERT INTO `commodity` VALUES ('300', '生羊肉', '1', 'SYR', '1');
INSERT INTO `commodity` VALUES ('301', '保鲜袋', '2', 'BXD', '1');
INSERT INTO `commodity` VALUES ('302', '芝麻', '1', 'ZM', '1');
INSERT INTO `commodity` VALUES ('303', '马高鱼', '1', 'MGY', '1');
INSERT INTO `commodity` VALUES ('304', '竹签', '4', 'ZQ', '1');
INSERT INTO `commodity` VALUES ('305', '牛蛙', '1', 'NW', '1');
INSERT INTO `commodity` VALUES ('306', '春卷', '1', 'CJ', '1');
INSERT INTO `commodity` VALUES ('307', '窝窝头', '2', 'WWT', '1');
INSERT INTO `commodity` VALUES ('308', '虫草', '7', 'CC', '1');
INSERT INTO `commodity` VALUES ('309', '卤水', '3', 'LS', '1');
INSERT INTO `commodity` VALUES ('310', '鳊鱼', '1', 'BY', '1');
INSERT INTO `commodity` VALUES ('311', '面粉', '1', 'MF', '1');
INSERT INTO `commodity` VALUES ('312', '孜然粉', '2', 'ZRF', '1');
INSERT INTO `commodity` VALUES ('313', '红油', '3', 'HY', '1');
INSERT INTO `commodity` VALUES ('314', '黑椒汁', '3', 'HJZ', '1');
INSERT INTO `commodity` VALUES ('315', '乌骨鸡', '1', 'WGJ', '1');
INSERT INTO `commodity` VALUES ('316', '莲子', '1', 'LZ', '1');
INSERT INTO `commodity` VALUES ('317', '牛腩', '1', 'NN', '1');
INSERT INTO `commodity` VALUES ('318', '大竹筒肉', '2', 'DZTR', '1');
INSERT INTO `commodity` VALUES ('319', '大竹蛏', '1', 'DZC', '1');
INSERT INTO `commodity` VALUES ('320', '海狮子头', '2', 'HSZT', '1');
INSERT INTO `commodity` VALUES ('321', '沙糖桔', '1', 'STJ', '1');
INSERT INTO `commodity` VALUES ('322', '虾米', '7', 'XM', '1');
INSERT INTO `commodity` VALUES ('323', '鲢鱼', '1', 'LY', '1');
INSERT INTO `commodity` VALUES ('324', '油渣', '1', 'YZ', '1');
INSERT INTO `commodity` VALUES ('325', '水煮笋片', '2', 'SZSP', '1');
INSERT INTO `commodity` VALUES ('326', '百页', '1', 'BY', '1');
INSERT INTO `commodity` VALUES ('327', '霜火果', '2', 'SHG', '1');
INSERT INTO `commodity` VALUES ('328', '羊葱', '1', 'YC', '1');
INSERT INTO `commodity` VALUES ('329', '花边土豆', '10', 'HBTD', '1');
INSERT INTO `commodity` VALUES ('330', '黄金饺', '2', 'HJJ', '1');
INSERT INTO `commodity` VALUES ('331', '香肠', '1', 'XC', '1');
INSERT INTO `commodity` VALUES ('332', '野鸡蛋', '4', 'YJD', '1');
INSERT INTO `commodity` VALUES ('333', '栗子', '3', 'LZ', '1');
INSERT INTO `commodity` VALUES ('334', '猪爪', '1', 'ZZ', '1');
INSERT INTO `commodity` VALUES ('335', '醉料', '3', 'ZL', '1');
INSERT INTO `commodity` VALUES ('336', '咸鹅', '1', 'XE', '1');
INSERT INTO `commodity` VALUES ('337', '藕粉圆子', '2', 'OFYZ', '1');
INSERT INTO `commodity` VALUES ('338', '牛筋', '1', 'NJ', '1');
INSERT INTO `commodity` VALUES ('339', '炼乳', '5', 'LR', '1');
INSERT INTO `commodity` VALUES ('340', '五香粉', '1', 'WXF', '1');
INSERT INTO `commodity` VALUES ('341', '苹果', '1', 'PG', '1');
INSERT INTO `commodity` VALUES ('342', '火龙果', '1', 'HLG', '1');
INSERT INTO `commodity` VALUES ('343', '菠萝', '6', 'BL', '1');
INSERT INTO `commodity` VALUES ('344', '鳕鱼', '1', 'XY', '1');
INSERT INTO `commodity` VALUES ('345', '蔬菜酥', '2', 'SCS', '1');
INSERT INTO `commodity` VALUES ('346', '馒夹', '2', 'MG', '1');
INSERT INTO `commodity` VALUES ('347', '竹针', '6', 'ZZ', '1');
INSERT INTO `commodity` VALUES ('348', '花架子', '8', 'HJZ', '1');
INSERT INTO `commodity` VALUES ('349', '片皮鸭', '8', 'PPY', '1');
INSERT INTO `commodity` VALUES ('350', '烤鸭', '4', 'KY', '1');
INSERT INTO `commodity` VALUES ('351', '冬笋', '1', 'DS', '1');
INSERT INTO `commodity` VALUES ('352', '蟹钳肉', '2', 'XQR', '1');
INSERT INTO `commodity` VALUES ('353', '鱼饼', '1', 'YB', '1');
INSERT INTO `commodity` VALUES ('354', '猪头肉', '1', 'ZTR', '1');
INSERT INTO `commodity` VALUES ('355', '大红枣', '3', 'DHZ', '1');
INSERT INTO `commodity` VALUES ('356', '豉鱼', '1', 'CY', '1');
INSERT INTO `commodity` VALUES ('357', '片粉', '1', 'PF', '1');
INSERT INTO `commodity` VALUES ('358', '精肉渣', '1', 'JRZ', '1');
INSERT INTO `commodity` VALUES ('359', '呅哈', '1', 'WH', '1');
INSERT INTO `commodity` VALUES ('360', '牛健', '2', 'NJ', '1');
INSERT INTO `commodity` VALUES ('361', '番茄沙司', '3', 'FQSS', '1');
INSERT INTO `commodity` VALUES ('362', '板油', '1', 'BY', '1');
INSERT INTO `commodity` VALUES ('363', '雪花鲳', '1', 'XHC', '1');
INSERT INTO `commodity` VALUES ('364', '耳片', '1', 'EP', '1');
INSERT INTO `commodity` VALUES ('365', '肉皮', '1', 'RP', '1');
INSERT INTO `commodity` VALUES ('366', '玉米粒', '3', 'YML', '1');
INSERT INTO `commodity` VALUES ('367', '龙虾料', '2', 'LXL', '1');
INSERT INTO `commodity` VALUES ('368', '鹅柳丝', '2', 'ELS', '1');
INSERT INTO `commodity` VALUES ('369', '西红柿', '1', 'XHS', '1');
INSERT INTO `commodity` VALUES ('370', '肉丝', '1', 'RS', '1');
INSERT INTO `commodity` VALUES ('371', '剁椒鱼头', '6', 'DJYT', '1');
INSERT INTO `commodity` VALUES ('372', '瓶红枣', '3', 'PHZ', '1');
INSERT INTO `commodity` VALUES ('373', '豆瓣', '2', 'DB', '1');
INSERT INTO `commodity` VALUES ('374', '酱鸭腿', '1', 'JYT', '1');
INSERT INTO `commodity` VALUES ('375', '大代鱼', '2', 'DDY', '1');
INSERT INTO `commodity` VALUES ('376', '梨', '1', 'L', '1');
INSERT INTO `commodity` VALUES ('377', '雪菜', '1', 'XC', '1');
INSERT INTO `commodity` VALUES ('379', '芥末', '4', 'JM', '1');
INSERT INTO `commodity` VALUES ('380', '小花', '4', 'XH', '1');
INSERT INTO `commodity` VALUES ('381', '橙子', '1', 'CZ', '1');
INSERT INTO `commodity` VALUES ('382', '雪花藕合', '5', 'XHOG', '1');
INSERT INTO `commodity` VALUES ('383', '红鲳鱼', '1', 'HCY', '1');
INSERT INTO `commodity` VALUES ('384', '泡椒猪尾', '2', 'PJZW', '1');
INSERT INTO `commodity` VALUES ('385', '鱼豆付', '1', 'YDF', '1');
INSERT INTO `commodity` VALUES ('386', '青菜包', '4', 'QCB', '1');
INSERT INTO `commodity` VALUES ('387', '剁椒猪尾', '2', 'DJZW', '1');
INSERT INTO `commodity` VALUES ('388', '虾皮', '7', 'XP', '1');
INSERT INTO `commodity` VALUES ('389', '糖蒜头', '2', 'TST', '1');
INSERT INTO `commodity` VALUES ('390', '泡椒', '3', 'PJ', '1');
INSERT INTO `commodity` VALUES ('391', '中虾', '1', 'ZX', '1');
INSERT INTO `commodity` VALUES ('392', '苇叶', '4', 'WX', '1');
INSERT INTO `commodity` VALUES ('393', '满天星', '4', 'MTX', '1');
INSERT INTO `commodity` VALUES ('394', '稻香扣肉', '5', 'DXKR', '1');
INSERT INTO `commodity` VALUES ('395', '香芋酥', '2', 'XYS', '1');
INSERT INTO `commodity` VALUES ('396', '盐水鸭', '2', 'YSY', '1');
INSERT INTO `commodity` VALUES ('397', '鸭腿', '1', 'YT', '1');
INSERT INTO `commodity` VALUES ('398', '生抽', '3', 'SC', '1');
INSERT INTO `commodity` VALUES ('399', '夹心肉', '1', 'JXR', '1');
INSERT INTO `commodity` VALUES ('400', '年糕', '2', 'NG', '1');
INSERT INTO `commodity` VALUES ('401', '黑枣', '1', 'HZ', '1');
INSERT INTO `commodity` VALUES ('402', '西米', '2', 'XM', '1');
INSERT INTO `commodity` VALUES ('403', '发财糕', '2', 'FCG', '1');
INSERT INTO `commodity` VALUES ('404', '蒸蒸日上', '2', 'ZZRS', '1');
INSERT INTO `commodity` VALUES ('405', '盐', '2', 'Y', '1');
INSERT INTO `commodity` VALUES ('406', '牛腱', '2', 'NJ', '1');
INSERT INTO `commodity` VALUES ('407', '果木牛', '2', 'GMN', '1');
INSERT INTO `commodity` VALUES ('408', '乳鸽', '6', 'RG', '1');
INSERT INTO `commodity` VALUES ('409', '河虾', '1', 'HX', '1');
INSERT INTO `commodity` VALUES ('410', '飘香鱼排', '2', 'PXYP', '1');
INSERT INTO `commodity` VALUES ('411', '鲍鱼汁', '3', 'BYZ', '1');
INSERT INTO `commodity` VALUES ('412', '干锅酱', '3', 'GGJ', '1');
INSERT INTO `commodity` VALUES ('413', '五香', '7', 'WX', '1');
INSERT INTO `commodity` VALUES ('414', '范妈香菜', '3', 'FMXC', '1');
INSERT INTO `commodity` VALUES ('415', '脆枣', '2', 'CZ', '1');
INSERT INTO `commodity` VALUES ('416', '石斑鱼', '1', 'SBY', '1');
INSERT INTO `commodity` VALUES ('417', '盐水肉', '1', 'YSR', '1');
INSERT INTO `commodity` VALUES ('418', '蔬菜肉丸', '2', 'SCRW', '1');
INSERT INTO `commodity` VALUES ('419', '齐菜圆子', '2', 'QCYZ', '0');
INSERT INTO `commodity` VALUES ('420', '水米糕', '5', 'SMG', '1');
INSERT INTO `commodity` VALUES ('421', '野菜肉丸', '2', 'YCRW', '1');
INSERT INTO `commodity` VALUES ('422', '玉米扁', '1', 'YMB', '1');
INSERT INTO `commodity` VALUES ('423', '腊肠', '1', 'XC', '1');
INSERT INTO `commodity` VALUES ('424', '冰玉糕', '2', 'BYG', '1');
INSERT INTO `commodity` VALUES ('425', '蛋饺', '5', 'DJ', '1');
INSERT INTO `commodity` VALUES ('426', '冰鱼', '1', 'BY', '1');
INSERT INTO `commodity` VALUES ('427', '啤酒鸭', '6', 'PJY', '1');
INSERT INTO `commodity` VALUES ('428', '白切肉', '1', 'BQR', '1');
INSERT INTO `commodity` VALUES ('429', '腰果', '1', 'YG', '1');
INSERT INTO `commodity` VALUES ('430', '粉皮', '1', 'FP', '1');
INSERT INTO `commodity` VALUES ('431', '迷你薯', '2', 'MNS', '1');
INSERT INTO `commodity` VALUES ('432', '尖子蟹', '1', 'JZX', '1');
INSERT INTO `commodity` VALUES ('433', '艾草糕', '2', 'ACG', '1');
INSERT INTO `commodity` VALUES ('434', '肉渣', '2', 'RZ', '1');
INSERT INTO `commodity` VALUES ('435', '泥螺', '1', 'NL', '1');
INSERT INTO `commodity` VALUES ('436', '玉米', '1', 'YM', '1');
INSERT INTO `commodity` VALUES ('437', '柱候酱', '3', 'ZHJ', '1');
INSERT INTO `commodity` VALUES ('438', '孜然羊腿', '2', 'ZRYT', '1');
INSERT INTO `commodity` VALUES ('439', '手指年糕', '2', 'SZNG', '1');
INSERT INTO `commodity` VALUES ('440', '花边纸', '9', 'HBZ', '1');
INSERT INTO `commodity` VALUES ('441', '花蛤', '1', 'HH', '1');
INSERT INTO `commodity` VALUES ('442', '五谷东肉', '2', 'WGDR', '1');
INSERT INTO `commodity` VALUES ('443', '方面包', '2', 'FMB', '1');
INSERT INTO `commodity` VALUES ('444', '手撕羊排', '2', 'SSYP', '1');
INSERT INTO `commodity` VALUES ('445', '水酵饼', '2', 'SJB', '1');
INSERT INTO `commodity` VALUES ('446', '梅花烤饼', '2', 'MHKB', '1');
INSERT INTO `commodity` VALUES ('447', '混子鱼', '1', 'HZY', '1');
INSERT INTO `commodity` VALUES ('448', '烤鸭饼', '9', 'KYB', '1');
INSERT INTO `commodity` VALUES ('449', '油炸鸡', '6', 'YZJ', '1');
INSERT INTO `commodity` VALUES ('450', '酒酿圆子', '2', 'JNYZ', '1');
INSERT INTO `commodity` VALUES ('451', '朱古力针', '7', 'ZGLZ', '1');
INSERT INTO `commodity` VALUES ('452', '小丸子', '1', 'XWZ', '1');
INSERT INTO `commodity` VALUES ('453', '蟹肉合', '5', 'XRG', '1');
INSERT INTO `commodity` VALUES ('454', '玉米饹', '2', 'YM饹', '1');
INSERT INTO `commodity` VALUES ('455', '冬枣', '1', 'DZ', '1');
INSERT INTO `commodity` VALUES ('456', '枣发糕', '2', 'ZFG', '1');
INSERT INTO `commodity` VALUES ('457', '墨西哥饼', '9', 'MXGB', '1');
INSERT INTO `commodity` VALUES ('458', '笑脸面点', '4', 'XLMD', '1');
INSERT INTO `commodity` VALUES ('459', '苦荞', '2', 'KQ', '1');
INSERT INTO `commodity` VALUES ('460', '蒸鸭', '1', 'ZY', '1');
INSERT INTO `commodity` VALUES ('461', '海鲨鱼', '1', 'HSY', '1');
INSERT INTO `commodity` VALUES ('462', '酸缸头', '2', 'SGT', '1');
INSERT INTO `commodity` VALUES ('463', '螺丝', '1', 'LS', '1');
INSERT INTO `commodity` VALUES ('464', '蟹黄脆', '2', 'XHC', '1');
INSERT INTO `commodity` VALUES ('465', '皮冻', '1', 'PD', '1');
INSERT INTO `commodity` VALUES ('466', '绿壳蛋', '6', 'LKD', '1');
INSERT INTO `commodity` VALUES ('467', '海参扣肉', '2', 'HSKR', '1');
INSERT INTO `commodity` VALUES ('468', '猪尾', '1', 'ZW', '1');
INSERT INTO `commodity` VALUES ('469', '黑椒排', '1', 'HJP', '1');
INSERT INTO `commodity` VALUES ('470', '鲜精', '2', 'XJ', '1');
INSERT INTO `commodity` VALUES ('471', '琵琶腿', '6', 'PPT', '1');
INSERT INTO `commodity` VALUES ('472', '迷你脆块', '6', 'MNCK', '1');
INSERT INTO `commodity` VALUES ('473', '野生茨菇', '1', 'YSCG', '1');
INSERT INTO `commodity` VALUES ('474', '糯米陈', '3', 'NMC', '1');
INSERT INTO `commodity` VALUES ('475', '赛牛花', '2', 'SNH', '1');
INSERT INTO `commodity` VALUES ('476', '雪鱼卷', '2', 'XYJ', '1');
INSERT INTO `commodity` VALUES ('477', '香辣酥', '1', 'XLS', '1');
INSERT INTO `commodity` VALUES ('478', '三本三', '8', 'SBS', '1');
INSERT INTO `commodity` VALUES ('479', '童子鸡', '1', 'TZJ', '1');
INSERT INTO `commodity` VALUES ('480', '方便袋', '2', 'FPD', '1');
INSERT INTO `commodity` VALUES ('481', '蒙心肉', '1', 'MXR', '1');
INSERT INTO `commodity` VALUES ('482', '肉沫', '1', 'RM', '1');
INSERT INTO `commodity` VALUES ('483', '糖醋黄鱼', '5', 'TCHY', '1');
INSERT INTO `commodity` VALUES ('484', '木棉豆腐', '2', 'MMDF', '1');
INSERT INTO `commodity` VALUES ('485', '辣鲜露', '3', 'LXL', '1');
INSERT INTO `commodity` VALUES ('486', '霍香饺', '2', 'HXJ', '1');
INSERT INTO `commodity` VALUES ('487', '丁香鱼', '3', 'DXY', '1');
INSERT INTO `commodity` VALUES ('488', '花椒油', '3', 'HJY', '1');
INSERT INTO `commodity` VALUES ('489', '白醋', '3', 'BC', '1');
INSERT INTO `commodity` VALUES ('490', '果汁', '3', 'GZ', '1');
INSERT INTO `commodity` VALUES ('491', '鸭血', '5', 'YX', '1');
INSERT INTO `commodity` VALUES ('493', '藕饼', '6', 'OB', '1');
INSERT INTO `commodity` VALUES ('494', '黑虎虾', '5', 'HHX', '1');
INSERT INTO `commodity` VALUES ('496', '泡打粉', '2', 'PDF', '1');
INSERT INTO `commodity` VALUES ('497', '荠菜丸子', '2', 'QCWZ', '1');
INSERT INTO `commodity` VALUES ('498', '装饰', '8', 'ZS', '1');
INSERT INTO `commodity` VALUES ('499', '米鱼', '1', 'MY', '1');
INSERT INTO `commodity` VALUES ('500', '核桃仁', '2', 'HTR', '1');
INSERT INTO `commodity` VALUES ('501', '花生芽', '2', 'HSY', '1');
INSERT INTO `commodity` VALUES ('502', '蒜香粒结', '1', 'SXLJ', '1');
INSERT INTO `commodity` VALUES ('503', '毛哥料', '2', 'MGL', '1');
INSERT INTO `commodity` VALUES ('504', '心里美', '1', 'XLM', '1');
INSERT INTO `commodity` VALUES ('505', '盐酥鸡', '1', 'YSJ', '1');
INSERT INTO `commodity` VALUES ('506', '土豪包', '2', 'THB', '1');
INSERT INTO `commodity` VALUES ('507', '夏威夷果', '2', 'XWYG', '1');
INSERT INTO `commodity` VALUES ('508', '槟榔芋', '1', 'BLY', '1');
INSERT INTO `commodity` VALUES ('509', '天芙南瓜', '2', 'TFNG', '1');
INSERT INTO `commodity` VALUES ('510', '蛋皮', '1', 'DP', '1');
INSERT INTO `commodity` VALUES ('512', '虾饼', '2', 'XB', '1');
INSERT INTO `commodity` VALUES ('513', '豆香黄鱼', '3', 'DXHY', '1');
INSERT INTO `commodity` VALUES ('514', '红毛虾', '1', 'HMX', '1');
INSERT INTO `commodity` VALUES ('515', '蟹米酥', '4', 'XMS', '1');
INSERT INTO `commodity` VALUES ('516', '腊鸡腿', '1', 'LJT', '1');
INSERT INTO `commodity` VALUES ('517', '蒜蓉蛏王', '4', 'SRCW', '1');
INSERT INTO `commodity` VALUES ('518', '枸杞子', '7', 'JQZ', '1');
INSERT INTO `commodity` VALUES ('519', '羊排', '2', 'YP', '1');
INSERT INTO `commodity` VALUES ('520', '天夫鳕排', '2', 'TFXP', '1');
INSERT INTO `commodity` VALUES ('521', '黄栀子', '7', 'HZZ', '1');
INSERT INTO `commodity` VALUES ('522', '花生酱', '3', 'HSJ', '1');
INSERT INTO `commodity` VALUES ('523', '牛肉', '1', 'NR', '1');
INSERT INTO `commodity` VALUES ('531', 'vbbb', '3', 'VBBB', '0');
INSERT INTO `commodity` VALUES ('532', 'vvv', '3', 'VVV', '1');
INSERT INTO `commodity` VALUES ('533', 'Iv1', '1', 'IV', '0');
INSERT INTO `commodity` VALUES ('534', 'vkd', '1', 'VKD', '1');
INSERT INTO `commodity` VALUES ('535', 'Iaaa', '4', 'IAAA', '0');
INSERT INTO `commodity` VALUES ('536', 'vv1zzz', '1', 'VVZZZ', '1');
INSERT INTO `commodity` VALUES ('537', '鹌鹑鸟', '6', 'ACN', '0');
INSERT INTO `commodity` VALUES ('538', 'vww', '1', 'VWW', '1');

-- ----------------------------
-- Table structure for orderdetail
-- ----------------------------
DROP TABLE IF EXISTS `orderdetail`;
CREATE TABLE `orderdetail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orderNo` varchar(128) DEFAULT NULL COMMENT '订单号',
  `commodityId` int(11) DEFAULT NULL COMMENT '商品id',
  `price` decimal(10,2) DEFAULT NULL COMMENT '价格',
  `weight` decimal(10,2) DEFAULT NULL COMMENT '重量',
  `unitId` int(11) DEFAULT NULL COMMENT '单位名称id',
  `subtotal` decimal(16,2) DEFAULT NULL,
  `type` int(11) DEFAULT '0' COMMENT '0：订单，1：补单',
  PRIMARY KEY (`id`),
  KEY `idx_orderNo` (`orderNo`)
) ENGINE=InnoDB AUTO_INCREMENT=139 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of orderdetail
-- ----------------------------
INSERT INTO `orderdetail` VALUES ('2', '1234', '2', '70.00', '5.00', '1', '350.00', '1');
INSERT INTO `orderdetail` VALUES ('3', '1234', '3', '30.00', '20.00', '2', '600.00', '0');
INSERT INTO `orderdetail` VALUES ('4', '1234', '191', '1.12', '1.12', '6', '1.25', '0');
INSERT INTO `orderdetail` VALUES ('5', '1234', '52', '15.00', '11.15', '3', '167.25', '0');
INSERT INTO `orderdetail` VALUES ('6', '1234', '271', '0.00', '0.00', '4', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('7', '1234', '412', '20.12', '10.50', '3', '211.26', '0');
INSERT INTO `orderdetail` VALUES ('15', '2020091316260798521000', '424', '10.00', '20.55', '2', '205.50', '0');
INSERT INTO `orderdetail` VALUES ('16', '2020091316260798521000', '296', '10.00', '50.00', '1', '500.00', '0');
INSERT INTO `orderdetail` VALUES ('17', '2020091316260798521000', '426', '20.00', '20.50', '1', '410.00', '0');
INSERT INTO `orderdetail` VALUES ('18', '2020091316260798521000', '235', '0.00', '10.00', '1', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('19', '2020091316260798521000', '362', '0.00', '0.00', '1', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('20', '2020091316260798521000', '508', '0.00', '0.00', '1', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('21', '2020091316260798521000', '128', '0.00', '0.00', '2', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('22', '2020091316260798521000', '103', '0.00', '0.00', '1', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('23', '2020091316260798521000', '42', '0.00', '0.00', '1', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('26', '2020091316260798521000', '98', '0.00', '0.00', '1', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('27', '2020091316260798521000', '242', '0.00', '0.00', '2', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('28', '2020091316260798521000', '218', '0.00', '0.00', '1', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('29', '2020091316260798521000', '146', '0.00', '0.00', '2', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('30', '2020091316260798521000', '26', '0.00', '0.00', '1', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('31', '2020091316260798521000', '489', '0.00', '0.00', '3', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('35', '2020091316260798521000', '195', '11.00', '1.00', '2', '11.00', '1');
INSERT INTO `orderdetail` VALUES ('36', '2020091316260798521000', '362', '1.00', '1.00', '1', '1.00', '1');
INSERT INTO `orderdetail` VALUES ('37', '2020091316260798521000', '508', '1.00', '1.00', '1', '1.00', '1');
INSERT INTO `orderdetail` VALUES ('38', '2020091316260798521000', '128', '1.00', '1.00', '2', '1.00', '1');
INSERT INTO `orderdetail` VALUES ('40', '2020091316260798521000', '506', '1.00', '1.00', '2', '1.00', '1');
INSERT INTO `orderdetail` VALUES ('41', '2020091316260798521000', '520', '1.00', '1.00', '2', '1.00', '1');
INSERT INTO `orderdetail` VALUES ('42', '2020091316260798521000', '509', '1.00', '1.00', '2', '1.00', '1');
INSERT INTO `orderdetail` VALUES ('43', '2020091316260798521000', '288', '1.00', '1.00', '1', '1.00', '1');
INSERT INTO `orderdetail` VALUES ('44', '2020091316260798521000', '269', '1.00', '1.00', '2', '1.00', '1');
INSERT INTO `orderdetail` VALUES ('45', '2020091316260798521000', '479', '1.00', '11.00', '1', '11.00', '1');
INSERT INTO `orderdetail` VALUES ('46', '2020091316260798521000', '165', '1.00', '1.00', '3', '1.00', '1');
INSERT INTO `orderdetail` VALUES ('47', '2020091316260798521000', '389', '1.00', '1.00', '2', '1.00', '1');
INSERT INTO `orderdetail` VALUES ('48', '2020091316260798521000', '483', '1.00', '1.00', '5', '1.00', '1');
INSERT INTO `orderdetail` VALUES ('49', '2020091316260798521000', '87', '1.00', '1.00', '2', '1.00', '1');
INSERT INTO `orderdetail` VALUES ('50', '2020091316260798521000', '63', '1.00', '1.00', '1', '1.00', '1');
INSERT INTO `orderdetail` VALUES ('51', '2020091316260798521000', '392', '1.00', '1.00', '4', '1.00', '1');
INSERT INTO `orderdetail` VALUES ('61', '2020091316260798521000', '77', '0.00', '0.00', '1', '0.00', '1');
INSERT INTO `orderdetail` VALUES ('63', '2020091316260798521000', '236', '111.00', '11.00', '2', '1221.00', '0');
INSERT INTO `orderdetail` VALUES ('64', '2020091316260798521000', '284', '0.00', '0.00', '4', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('65', '2020091316260798521000', '223', '0.00', '0.00', '8', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('66', '2020091316260798521000', '186', '0.00', '0.00', '7', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('67', '2020091316260798521000', '127', '0.00', '0.00', '2', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('68', '2020091316260798521000', '326', '0.00', '0.00', '1', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('69', '2020091316260798521000', '343', '0.00', '0.00', '6', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('70', '2020091316260798521000', '43', '0.00', '0.00', '3', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('71', '2020091316260798521000', '117', '0.00', '0.00', '4', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('72', '2020091316260798521000', '119', '0.00', '0.00', '6', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('73', '2020091316260798521000', '411', '0.00', '0.00', '4', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('74', '2020091316260798521000', '310', '0.00', '0.00', '1', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('75', '2020091316260798521000', '315', '0.00', '0.00', '1', '0.00', '1');
INSERT INTO `orderdetail` VALUES ('76', '2020091316260798521000', '27', '0.00', '0.00', '2', '0.00', '1');
INSERT INTO `orderdetail` VALUES ('77', '2020091316260798521000', '52', '0.00', '0.00', '2', '0.00', '1');
INSERT INTO `orderdetail` VALUES ('78', '2020091316260798521000', '271', '0.00', '0.00', '4', '0.00', '1');
INSERT INTO `orderdetail` VALUES ('79', '2020091316260798521000', '412', '0.00', '0.00', '9', '0.00', '1');
INSERT INTO `orderdetail` VALUES ('80', '2020091316260798521000', '407', '0.00', '0.00', '3', '0.00', '1');
INSERT INTO `orderdetail` VALUES ('81', '2020091316260798521000', '272', '0.00', '0.00', '1', '0.00', '1');
INSERT INTO `orderdetail` VALUES ('82', '2020091316260798521000', '171', '0.00', '0.00', '11', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('83', '2020091316260798521000', '9', '0.00', '0.00', '1', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('84', '2020091316260798521000', '212', '0.00', '0.00', '1', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('85', '2020091316260798521000', '500', '0.00', '0.00', '2', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('86', '2020091316260798521000', '409', '0.00', '0.00', '1', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('87', '2020091316260798521000', '101', '0.00', '0.00', '1', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('88', '2020091316260798521000', '467', '0.00', '0.00', '2', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('89', '2020091316260798521000', '180', '0.00', '0.00', '1', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('90', '2020091316260798521000', '320', '0.00', '0.00', '2', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('91', '2020091316260798521000', '250', '0.00', '0.00', '2', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('92', '2020091316260798521000', '447', '0.00', '0.00', '1', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('93', '2020091316260798521000', '4', '0.00', '0.00', '1', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('94', '2020091316260798521000', '5', '0.00', '0.00', '1', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('100', '2020091316260798521000', '295', '0.00', '0.00', '3', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('101', '2020091316260798521000', '285', '0.00', '0.00', '1', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('102', '2020091316260798521000', '383', '0.00', '0.00', '1', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('103', '2020091316260798521000', '148', '0.00', '0.00', '3', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('104', '2020091316260798521000', '488', '0.00', '0.00', '3', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('105', '2020091316260798521000', '194', '0.00', '0.00', '3', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('106', '2020091316260798521000', '501', '0.00', '0.00', '2', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('107', '2020091316260798521000', '166', '0.00', '0.00', '3', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('108', '2020091316260798521000', '8', '0.00', '0.00', '3', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('109', '2020091316260798521000', '141', '0.00', '0.00', '1', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('110', '2020091316260798521000', '440', '0.00', '0.00', '9', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('111', '2020091316260798521000', '401', '0.00', '0.00', '1', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('112', '2020091316260798521000', '469', '0.00', '0.00', '1', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('113', '2020091316260798521000', '314', '0.00', '0.00', '3', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('114', '2020091316260798521000', '287', '0.00', '0.00', '1', '0.00', '0');
INSERT INTO `orderdetail` VALUES ('122', '2020091316260798521000', '10', '0.00', '0.00', '3', '0.00', '1');
INSERT INTO `orderdetail` VALUES ('123', '2020091316260798521000', '220', '0.00', '0.00', '3', '0.00', '1');
INSERT INTO `orderdetail` VALUES ('124', '2020091316260798521000', '188', '0.00', '0.00', '1', '0.00', '1');
INSERT INTO `orderdetail` VALUES ('125', '2020091316260798521000', '399', '0.00', '0.00', '1', '0.00', '1');
INSERT INTO `orderdetail` VALUES ('126', '2020091316260798521000', '432', '0.00', '0.00', '1', '0.00', '1');
INSERT INTO `orderdetail` VALUES ('127', '2020091316260798521000', '294', '0.00', '0.00', '7', '0.00', '1');
INSERT INTO `orderdetail` VALUES ('128', '2020091316260798521000', '143', '0.00', '0.00', '3', '0.00', '1');
INSERT INTO `orderdetail` VALUES ('129', '2020091316260798521000', '216', '0.00', '0.00', '3', '0.00', '1');
INSERT INTO `orderdetail` VALUES ('130', '2020091316260798521000', '108', '0.00', '0.00', '1', '0.00', '1');
INSERT INTO `orderdetail` VALUES ('131', '2020091316260798521000', '358', '0.00', '0.00', '1', '0.00', '1');
INSERT INTO `orderdetail` VALUES ('132', '2020091316260798521000', '379', '0.00', '0.00', '4', '0.00', '1');
INSERT INTO `orderdetail` VALUES ('133', '2020091316260798521000', '177', '0.00', '0.00', '2', '0.00', '1');
INSERT INTO `orderdetail` VALUES ('134', '2020091316260798521000', '217', '0.00', '0.00', '3', '0.00', '1');
INSERT INTO `orderdetail` VALUES ('135', '2020091316260798521000', '450', '0.00', '0.00', '2', '0.00', '1');
INSERT INTO `orderdetail` VALUES ('136', '2020091316260798521000', '79', '0.00', '0.00', '1', '0.00', '1');
INSERT INTO `orderdetail` VALUES ('137', '2020091316260798521000', '17', '0.00', '0.00', '1', '0.00', '1');
INSERT INTO `orderdetail` VALUES ('138', '2020091316260798521000', '374', '0.00', '0.00', '1', '0.00', '1');

-- ----------------------------
-- Table structure for orders
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orderNo` varchar(128) NOT NULL COMMENT '订单号',
  `name` varchar(16) DEFAULT NULL COMMENT '客户名称',
  `addr` varchar(255) DEFAULT NULL COMMENT '地址',
  `phoneNo` varchar(16) DEFAULT NULL COMMENT '电话号码',
  `total` decimal(16,2) DEFAULT NULL,
  `createTime` datetime DEFAULT NULL COMMENT '创建时间',
  `solarCalendar` date DEFAULT NULL COMMENT '阳历',
  `lunarCalendar` varchar(32) DEFAULT NULL COMMENT '阴历',
  `status` int(11) DEFAULT '1' COMMENT '状态：0删除，1正常',
  PRIMARY KEY (`id`),
  KEY `idx_orderNo_name` (`orderNo`,`name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of orders
-- ----------------------------
INSERT INTO `orders` VALUES ('1', '1234', '张三', '林梓8大队', '13913913913', '1329.76', '2020-09-10 21:55:52', '2020-09-25', '庚子年八月初九', '1');
INSERT INTO `orders` VALUES ('6', '2020091316260798521000', '要', 'getshnxzjfo', '18762090189', '2372.50', '2020-09-13 16:26:08', '2020-09-24', '庚子年八月初八', '1');
INSERT INTO `orders` VALUES ('7', '1212fsfd', 'aaa', 'aaa', null, null, '2020-09-17 21:51:32', '2020-09-17', null, '1');
INSERT INTO `orders` VALUES ('8', 'bbb', 'bbb', 'bbb', null, null, '2020-09-17 21:52:16', '2020-09-17', null, '1');
INSERT INTO `orders` VALUES ('9', 'ccc', 'ccc', 'ccc', null, null, '2020-09-17 21:54:57', '2020-09-17', null, '1');
INSERT INTO `orders` VALUES ('10', 'ddd', 'ddd', 'ddd', null, null, '2020-09-01 21:55:01', '2020-09-24', null, '1');
INSERT INTO `orders` VALUES ('11', 'eeee', 'eee', 'eee', null, null, '2020-09-01 21:55:13', '2020-09-17', null, '1');
INSERT INTO `orders` VALUES ('12', 'fff', 'fff', 'fff', null, null, '2020-08-05 21:55:20', '2020-10-01', null, '1');
INSERT INTO `orders` VALUES ('13', 'ggg', 'ggg', 'ggg', null, null, '2020-07-28 21:55:28', null, null, '1');
INSERT INTO `orders` VALUES ('14', 'hhh', 'hhh', 'hhh', null, null, '2020-09-16 21:55:35', null, null, '1');
INSERT INTO `orders` VALUES ('15', 'iii', 'iii', 'iii', null, null, '2020-09-08 21:55:41', null, null, '1');
INSERT INTO `orders` VALUES ('16', 'jjj', 'jjj', 'jjj', null, null, '2020-09-17 21:55:45', null, null, '1');
INSERT INTO `orders` VALUES ('17', 'kkk', 'kkk', 'kkk', null, null, '2020-09-17 21:55:48', null, null, '1');
INSERT INTO `orders` VALUES ('18', 'lll', 'lll', 'lll', null, null, '2020-09-17 21:55:51', null, null, '1');
INSERT INTO `orders` VALUES ('19', 'mmm', 'mmm', 'mmm', null, null, '2020-09-17 21:55:54', null, null, '1');
INSERT INTO `orders` VALUES ('20', 'ooo', 'ooo', 'ooo', null, null, '2020-09-17 21:55:58', null, null, '1');
INSERT INTO `orders` VALUES ('21', 'ppp', 'ppp', 'ppp', null, null, '2020-09-17 21:56:01', null, null, '1');
INSERT INTO `orders` VALUES ('22', 'qqq', 'qqq', 'qqq', null, null, '2020-09-17 21:56:04', null, null, '1');
INSERT INTO `orders` VALUES ('23', 'rrr', 'rrr', 'rrr', null, null, '2020-09-17 21:56:07', null, null, '1');
INSERT INTO `orders` VALUES ('24', 'sss', 'sss', 'sss', null, null, '2020-09-17 21:56:09', null, null, '1');
INSERT INTO `orders` VALUES ('25', 'ttt', 'ttt', 'ttt', null, null, '2020-09-17 21:56:12', null, null, '1');
INSERT INTO `orders` VALUES ('26', 'uuuu', 'uuu', 'uuuu', null, null, '2020-09-17 21:56:14', null, null, '1');
INSERT INTO `orders` VALUES ('27', 'vvv', 'vvv', 'vvv', null, null, '2020-09-17 21:56:17', null, null, '1');
INSERT INTO `orders` VALUES ('28', 'www', 'www', 'www', null, null, '2020-09-17 21:56:20', null, null, '1');
INSERT INTO `orders` VALUES ('29', 'xxx', 'xxx', 'xxx', null, null, '2020-09-17 21:56:23', null, null, '1');
INSERT INTO `orders` VALUES ('30', 'yyy', 'yyy', 'yyy', null, null, '2020-09-17 21:56:26', null, null, '1');
INSERT INTO `orders` VALUES ('31', '2020091721581611521000', '李四', '随便一个地址', '13913789123', '0.00', '2020-09-17 21:58:16', '2020-09-24', '庚子年八月初八', '1');

-- ----------------------------
-- Table structure for unit
-- ----------------------------
DROP TABLE IF EXISTS `unit`;
CREATE TABLE `unit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL COMMENT '单位名称',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of unit
-- ----------------------------
INSERT INTO `unit` VALUES ('1', '斤');
INSERT INTO `unit` VALUES ('2', '袋');
INSERT INTO `unit` VALUES ('3', '瓶');
INSERT INTO `unit` VALUES ('4', '个');
INSERT INTO `unit` VALUES ('5', '盒');
INSERT INTO `unit` VALUES ('6', '只');
INSERT INTO `unit` VALUES ('7', '两');
INSERT INTO `unit` VALUES ('8', '份');
INSERT INTO `unit` VALUES ('9', '张');
INSERT INTO `unit` VALUES ('10', '桶');
INSERT INTO `unit` VALUES ('11', '本');
INSERT INTO `unit` VALUES ('12', '片');

-- ----------------------------
-- Function structure for fristPinyin
-- ----------------------------
DROP FUNCTION IF EXISTS `fristPinyin`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `fristPinyin`(`P_NAME` varchar(255)) RETURNS varchar(255) CHARSET utf8
BEGIN
    DECLARE V_RETURN VARCHAR(255);
    SET V_RETURN = ELT(INTERVAL(CONV(HEX(left(CONVERT(P_NAME USING gbk),
1)),
16,10),

        0xB0A1,0xB0C5,0xB2C1,0xB4EE,0xB6EA,0xB7A2,0xB8C1,0xB9FE,0xBBF7,
        0xBFA6,0xC0AC,0xC2E8,0xC4C3,0xC5B6,0xC5BE,0xC6DA,0xC8BB,
        0xC8F6,0xCBFA,0xCDDA,0xCEF4,0xD1B9,0xD4D1),
   
    'A','B','C','D','E','F','G','H','J','K','L','M','N','O','P','Q','R','S','T','W','X','Y','Z');
    RETURN V_RETURN;
END
;;
DELIMITER ;
